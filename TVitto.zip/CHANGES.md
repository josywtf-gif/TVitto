# TVitto: отключение PiP и фонового воспроизведения

- Полностью удалён вход в Picture-in-Picture: нет PiP callback/параметров и manifest-флага.
- Удалён MediaSessionService, MediaButtonReceiver и связанные foreground permissions.
- Удалена зависимость Media3 Session.
- ExoPlayer используется только экраном PlayerScreen и освобождается после удаления PlayerView из Compose.
- При переходе Activity в background воспроизведение ставится на паузу; при возвращении продолжается с той же позиции.
- Закрытие экрана плеера останавливает, очищает и освобождает ExoPlayer.
- WorkManager, избранное, рейтинг потоков и AFR/tunneling настройки не затрагивались.
