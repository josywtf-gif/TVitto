# TVitto changes

## Favorites and playback shutdown fixes
- Removed the duplicate hard-coded Favorites item from the navigation drawer; Favorites now appears once alongside Recent.
- Added an always-visible heart control to every channel card. Tap it to add/remove the channel from Favorites; the existing long-press menu remains available.
- Closing the player now pauses and stops ExoPlayer, clears its media queue, and stops the MediaSession foreground service. The service remains active during normal background/PiP use and is stopped only on explicit player exit.

## Validation
- Verified the drawer source contains exactly one hard-coded Favorites item.
- Gradle compilation could not be run in this environment because the Gradle 8.9 distribution could not be downloaded (`UnknownHostException: services.gradle.org`).


## Player close crash fix
- Player exit no longer stops/releases the shared ExoPlayer inside the click/back callback while PlayerView is still attached.
- Playback shutdown is deferred until after Compose removes PlayerScreen, then a short settling delay is applied before stopping the MediaSession service.
- MediaSessionService teardown now pauses and releases the shared player in one guarded cleanup path.
- Returning from the player keeps MainActivity alive and displays the channel list.
