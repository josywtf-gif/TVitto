package com.tvitto.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import com.tvitto.app.MainActivity
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Screen { List, Settings, Source, AddPlaylist }

@Composable
fun TVittoRoot(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()

    var session by remember { mutableStateOf<PlaySession?>(null) }
    var returnKey by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf(Screen.List) }
    val hasCustom by vm.hasCustom.collectAsStateWithLifecycle()
    val gridState = rememberLazyGridState()

    // Источник сменился: список другой — возвращаемся к началу и забываем «последний канал».
    LaunchedEffect(state.source) {
        returnKey = null
        gridState.scrollToItem(0)
    }

    val current = session
    DisposableEffect(current != null) {
        MainActivity.playerActive = current != null
        onDispose { MainActivity.playerActive = false }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        when {
            current != null -> PlayerScreen(
                session = current,
                onEvent = { vm.onPlaybackEvent(it) },
                onChannelOpened = { vm.addRecent(it) },
            ) { lastKey ->
                returnKey = lastKey
                vm.onPlayerClosed()
                session = null
            }

            screen == Screen.Settings -> SettingsScreen(
                source = state.source,
                onBack = { screen = Screen.List },
                onRestartChecks = { vm.restartChecks() },
                onChooseSource = { screen = Screen.Source },
            )

            screen == Screen.Source -> SourceScreen(
                current = state.source,
                hasCustom = hasCustom,
                onBack = { screen = Screen.Settings },
                onBuiltin = {
                    vm.selectBuiltin()
                    screen = Screen.List
                },
                onAddCustom = { screen = Screen.AddPlaylist },
            )

            screen == Screen.AddPlaylist -> AddPlaylistScreen(
                hasCustom = hasCustom,
                onBack = { screen = Screen.Source },
                onSubmit = { vm.addCustomPlaylist(it) },
                onUseSaved = {
                    vm.useSavedCustom()
                    screen = Screen.List
                },
                onDone = { screen = Screen.List },
            )

            else -> ChannelListScreen(
                state = state,
                gridState = gridState,
                focusKey = returnKey,
                onOpen = { channel ->
                    vm.onPlayerOpened(channel.key)
                    session = PlaySession(state.channels, channel.key, state.selected)
                },
                onRetryChannel = { vm.retryChannel(it.key) },
                onRetry = { vm.retry() },
                onSelectCategory = { vm.selectCategory(it) },
                onToggleFavorite = { vm.toggleFavorite(it) },
                isFavorite = { vm.isFavorite(it) },
                onOpenSettings = { screen = Screen.Settings },
            )
        }
    }
}
