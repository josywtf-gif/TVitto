# TVitto PiP close playback fix

## Root cause
Closing the PiP window with the system X finishes/removes the Activity task, but the MediaSessionService is a separately started service (`stopWithTask=false`). `onTaskRemoved()` is not a reliable callback for every PiP close path, so the service could keep ExoPlayer alive and continue audio after the PiP window disappeared.

## Changes
- Added `MainActivity.onDestroy()` cleanup guarded by `isFinishing`. When Android finishes the Activity (including PiP X close), it calls `PlaybackEngine.stopAndRelease(applicationContext)`.
- This pauses/stops the shared ExoPlayer, clears its media queue, and stops the started MediaSessionService.
- Configuration recreation is not treated as a user close (`isFinishing == false`). Entering PiP / pressing Home does not destroy the Activity, so background/PiP playback remains available.
- Kept `onTaskRemoved()` as a secondary cleanup path and explicitly removes the service foreground notification.

## Validation
- Source-level checks: MainActivity cleanup is gated by `isFinishing`; the cleanup invokes the existing centralized player/service shutdown; `onTaskRemoved()` remains a fallback.
- Gradle compilation was not run in this environment.
