package com.tvitto.app

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import android.app.PictureInPictureParams
import android.util.Rational
import android.os.Build
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import com.tvitto.app.ui.LocalIsTv
import com.tvitto.app.ui.TVittoRoot
import com.tvitto.app.ui.TVittoTheme
import com.tvitto.app.playback.PlaybackEngine

class MainActivity : ComponentActivity() {
    companion object { @Volatile var playerActive: Boolean = false }
    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        if (playerActive && Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && !isInPictureInPictureMode) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            runCatching { enterPictureInPictureMode(params) }
        }
    }

    /**
     * Закрытие PiP крестиком завершает Activity, но MediaSessionService является
     * отдельным started service и может продолжить воспроизведение после уничтожения
     * Activity. Поэтому при реальном finish Activity принудительно останавливаем
     * общий ExoPlayer и сервис. При повороте/пересоздании Activity isFinishing=false,
     * а при обычном уходе в PiP Activity не уничтожается — воспроизведение сохраняется.
     */
    override fun onDestroy() {
        if (isFinishing) {
            runCatching { PlaybackEngine.stopAndRelease(applicationContext) }
        }
        super.onDestroy()
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uiMode = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val isTv = uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

        setContent {
            TVittoTheme {
                CompositionLocalProvider(LocalIsTv provides isTv) {
                    TVittoRoot()
                }
            }
        }
    }
}
