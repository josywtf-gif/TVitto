# Правила R8 для release-сборки. Библиотеки (Media3, OkHttp, Coil, WorkManager) приносят свои consumer-правила.
-dontwarn org.conscrypt.**
-dontwarn org.bouncycastle.**
-dontwarn org.openjsse.**
