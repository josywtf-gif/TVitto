package com.tvitto.app.data

import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

/**
 * Единая очередь фоновых проверок каналов.
 *
 * - Состояния alive/suspect/dead/unknown, интервалы и правило «dead = минимум две неудачи с разрывом от 10 минут».
 * - inFlight исключает параллельную проверку одного канала; результат принимается только если канал,
 *   его подпись потоков, «эпоха» (результат воспроизведения) и generation не устарели.
 * - Нагрузка регулируется [LoadGovernor]; во время просмотра работает только лёгкая сетевая проверка.
 * - Вторая ступень — проверка содержимого (картинка и звук, [ContentState]): канал показывается только после неё.
 *   Первый провал отправляет канал в самый конец очереди (RETRY), второй скрывает его (BAD) и перепроверяет редко.
 * - Каждый результат сразу уходит на диск атомарной записью ([CheckCache]).
 */
class CheckScheduler(
    private val scope: CoroutineScope,
    private val checker: StreamChecker,
    private val store: CheckCache,
    private val governor: LoadGovernor,
    /**
     * Пассивный режим (свой плейлист): фоновых проверок нет, каналы доступны сразу.
     * Запоминается только рабочий поток, на котором канал реально заиграл.
     */
    private val passive: Boolean = false,
) {
    private class Boost(val at: Long, val immediate: Boolean)

    private class Pick(
        val key: String,
        val channel: Channel,
        val sig: String,
        val epoch: Int,
        val gen: Int,
        /** Поток, на котором канал последний раз был подтверждён (проверяется первым). */
        val prevIdx: Int = -1,
        /** Проверка содержимого, а не доступности. */
        val content: Boolean = false,
        /** Повторная проверка содержимого: пробуем все потоки канала. */
        val allStreams: Boolean = false,
    )

    private val _results = MutableStateFlow<Map<String, CheckResult>>(emptyMap())
    val results: StateFlow<Map<String, CheckResult>> = _results.asStateFlow()

    private val _initialDone = MutableStateFlow(passive)
    val initialDone: StateFlow<Boolean> = _initialDone.asStateFlow()

    /** (выполнено, всего) для явной перепроверки всех каналов; (0, 0), когда её нет. */
    private val _backlog = MutableStateFlow(Pair(0, 0))
    val backlog: StateFlow<Pair<Int, Int>> = _backlog.asStateFlow()

    private val lock = Any()

    // Всё ниже защищено lock.
    private var channels: Map<String, Channel> = emptyMap()
    private var order: List<String> = emptyList()
    private var sigs: Map<String, String> = emptyMap()
    private val inFlight = HashSet<String>()
    private val boosts = LinkedHashMap<String, Boost>()
    private val bulk = HashSet<String>()
    private var bulkTotal = 0
    private var recentKeys: List<String> = emptyList()
    private var activeKey: String? = null
    private var neighborKeys: List<String> = emptyList()
    private val epochs = HashMap<String, Int>()

    /** Каналы, чья проверка без ExoPlayer оказалась неубедительной: до указанного времени или до закрытия плеера не трогаем. */
    private val deferred = HashMap<String, Long>()
    private var nextSlotAt = 0L

    /** Проверка содержимого неубедительна (плеер занят, плохая сеть): до указанного времени не трогаем. */
    private val contentDeferred = HashMap<String, Long>()
    private val contentInconclusive = HashMap<String, Int>()
    private var contentInFlight = 0
    private var nextContentAt = 0L

    @Volatile
    private var generation = 0

    private val wakeTick = MutableStateFlow(0)
    private val saveTick = MutableStateFlow(0)
    private var loopJob: Job? = null
    private var saverJob: Job? = null
    private var netJob: Job? = null

    // ---------- жизненный цикл ----------

    fun start() {
        if (passive) {
            if (saverJob?.isActive != true) saverJob = scope.launch(Dispatchers.IO) { runSaver() }
            return
        }
        if (loopJob?.isActive != true) loopJob = scope.launch(Dispatchers.Default) { runLoop() }
        if (saverJob?.isActive != true) saverJob = scope.launch(Dispatchers.IO) { runSaver() }
        if (netJob?.isActive != true) {
            // Сеть вернулась — продолжаем проверки; пропала — loop сам встанет на паузу.
            netJob = scope.launch { governor.online.collect { wake() } }
        }
    }

    fun stop() {
        loopJob?.cancel()
        saverJob?.cancel()
        netJob?.cancel()
    }

    private fun wake() {
        wakeTick.update { it + 1 }
    }

    private fun signalSave() {
        saveTick.update { it + 1 }
    }

    // ---------- список каналов и восстановление ----------

    /** Восстанавливает результаты с диска и применяет их к списку каналов. */
    suspend fun restore(list: List<Channel>) {
        val snap = store.load()
        synchronized(lock) {
            _initialDone.value = snap.initialDone || passive
            _results.value = snap.results
        }
        submitChannels(list)
    }

    /**
     * Новый список каналов (после плейлистов): новые каналы добавляются как unknown, пропавшие убираются,
     * у каналов с изменившимися URL/заголовками результат сохраняется, но они отправляются на перепроверку.
     */
    suspend fun submitChannels(list: List<Channel>) = withContext(Dispatchers.Default) {
        val newSigs = HashMap<String, String>(list.size)
        for (ch in list) newSigs[ch.key] = ch.signature()
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val old = _results.value
            val next = HashMap<String, CheckResult>(list.size)
            for (ch in list) {
                val r = old[ch.key] ?: continue
                val sig = newSigs.getValue(ch.key)
                when {
                    r.idx >= ch.streams.size -> Unit // потоки изменились до неузнаваемости — как новый канал
                    r.sig.isEmpty() || r.sig == sig -> next[ch.key] = r.copy(sig = sig)
                    else -> {
                        // Потоки изменились: прежняя проверка содержимого к ним не относится.
                        next[ch.key] = r.copy(
                            sig = sig,
                            nextCheckAt = 0L,
                            content = ContentState.UNVERIFIED,
                            contentNextAt = 0L,
                            contentFails = 0,
                            contentReason = "",
                        )
                        boosts.putIfAbsent(ch.key, Boost(now, immediate = false))
                    }
                }
            }
            channels = list.associateBy { it.key }
            order = list.map { it.key }
            sigs = newSigs
            boosts.keys.retainAll(channels.keys)
            bulk.retainAll(channels.keys)
            epochs.keys.retainAll(channels.keys)
            deferred.keys.retainAll(channels.keys)
            contentDeferred.keys.retainAll(channels.keys)
            contentInconclusive.keys.retainAll(channels.keys)
            _results.value = next
            updateBacklogLocked()
            maybeFinishInitialLocked()
        }
        wake()
        signalSave()
    }

    fun setRecent(keys: List<String>) {
        synchronized(lock) { recentKeys = keys }
        wake()
    }

    // ---------- действия пользователя ----------

    /** Повторить всё: все каналы в очередь с высоким приоритетом, старые результаты остаются до новых. */
    fun retryAll() {
        if (passive) return
        val now = System.currentTimeMillis()
        synchronized(lock) {
            bulk.clear()
            for (key in order) {
                boosts[key] = Boost(now, immediate = false)
                bulk.add(key)
            }
            bulkTotal = bulk.size
            // Содержимое хороших и скрытых каналов тоже перепроверяется (в конце очереди).
            _results.value = _results.value.mapValues { (_, r) ->
                if (r.content == ContentState.UNVERIFIED) r else r.copy(contentNextAt = 0L)
            }
            contentDeferred.clear()
            updateBacklogLocked()
        }
        wake()
        signalSave()
    }

    /** Проверка одного канала с высоким приоритетом и без ожидания окна лимита нагрузки. */
    fun forceCheck(key: String) {
        if (passive) return
        synchronized(lock) {
            if (channels.containsKey(key)) boosts[key] = Boost(System.currentTimeMillis(), immediate = true)
        }
        wake()
    }

    /** Полный сброс результатов и очереди; список каналов остаётся, первоначальная проверка начинается заново. */
    suspend fun resetAll() {
        synchronized(lock) {
            generation++
            boosts.clear()
            bulk.clear()
            bulkTotal = 0
            epochs.clear()
            deferred.clear()
            contentDeferred.clear()
            contentInconclusive.clear()
            nextSlotAt = 0L
            _results.value = emptyMap()
            _initialDone.value = passive
            updateBacklogLocked()
        }
        saveNow()
        wake()
    }

    /** Дописывает результаты на диск (при смене источника, когда сохранитель уже остановлен). */
    suspend fun flush() = saveNow()

    // ---------- воспроизведение ----------

    fun playbackOpened() {
        governor.playing = true
        wake()
    }

    fun playbackClosed() {
        governor.playing = false
        governor.buffering = false
        synchronized(lock) {
            activeKey = null
            neighborKeys = emptyList()
            nextSlotAt = 0L
            deferred.clear()
            contentDeferred.clear()
        }
        wake() // отложенные проверки возобновляются
    }

    fun onPlayback(event: PlaybackEvent) {
        when (event) {
            is PlaybackEvent.Opened -> {
                synchronized(lock) {
                    activeKey = event.key
                    neighborKeys = event.neighbors
                }
                wake()
            }
            is PlaybackEvent.Buffering -> {
                governor.buffering = event.on
                wake()
            }
            is PlaybackEvent.Ready -> applyPlayback(event.key, event.streamIndex)
            // В пассивном режиме неудача воспроизведения канал не скрывает.
            is PlaybackEvent.Timeout -> if (!passive) applyPlayback(event.key, -1)
            is PlaybackEvent.Failed -> if (!passive) applyPlayback(event.key, -1)
        }
    }

    /** Результат воспроизведения главнее фоновой проверки: «эпоха» канала растёт, и начатые проверки отбрасываются. */
    private fun applyPlayback(key: String, idx: Int) {
        val now = System.currentTimeMillis()
        synchronized(lock) {
            val ch = channels[key] ?: return
            if (idx >= ch.streams.size) return
            epochs[key] = (epochs[key] ?: 0) + 1
            boosts.remove(key)
            bulk.remove(key)
            _results.value = _results.value + (key to nextResult(_results.value[key], idx, now, sigs[key].orEmpty(), fromPlayback = true))
            updateBacklogLocked()
            maybeFinishInitialLocked()
        }
        wake()
        signalSave()
    }

    // ---------- основной цикл ----------

    private suspend fun runLoop() {
        while (currentCoroutineContext().isActive) {
            val seen = wakeTick.value
            val waitMs = step(System.currentTimeMillis())
            if (waitMs > 0L) {
                withTimeoutOrNull(waitMs) { wakeTick.first { it != seen } }
            }
        }
    }

    /** Запускает одну проверку, если можно. Возвращает, сколько ждать до следующей попытки (0 — сразу). */
    private fun step(now: Long): Long {
        val parallel = governor.parallelism()
        val rate = governor.ratePerMin(initial = !_initialDone.value)
        if (parallel <= 0 || rate <= 0) return IDLE_MS
        synchronized(lock) {
            if (inFlight.size >= parallel) return BUSY_MS
            // 1) Проверка доступности: быстрая, идёт первой.
            val pick = pickLocked(now)
            var wait = -1L
            if (pick != null) {
                val immediate = boosts[pick.key]?.immediate == true
                if (immediate || now >= nextSlotAt) {
                    if (!immediate) nextSlotAt = now + 60_000L / rate
                    inFlight.add(pick.key)
                    scope.launch(Dispatchers.Default) { runCheck(pick) }
                    return 0L
                }
                wait = nextSlotAt - now
            }
            // 2) Проверка содержимого: тяжёлая, у неё свой потолок параллельности и не нужен лимит «в минуту».
            if (contentInFlight < governor.contentParallelism() && governor.exoAllowed()) {
                val cp = if (now >= nextContentAt) pickContentLocked(now) else null
                if (cp != null) {
                    nextContentAt = now + governor.contentPacingMs()
                    inFlight.add(cp.key)
                    contentInFlight++
                    scope.launch(Dispatchers.Default) { runContentCheck(cp) }
                    return 0L
                }
            }
            val base = if (wait >= 0L) wait else nextDueDelayLocked(now)
            // Пауза между проверками содержимого: проснуться ровно к её концу.
            return if (nextContentAt > now) minOf(base, nextContentAt - now).coerceAtLeast(200L) else base
        }
    }

    /**
     * Приоритеты. Обычно: принудительные → недавние → unknown → suspect → dead → alive.
     * Во время просмотра: принудительные → активный канал → соседи → unknown → dead → alive
     * (suspect откладываются до закрытия плеера, свежие alive пропускаются).
     */
    private fun pickLocked(now: Long): Pick? {
        val res = _results.value
        val playing = governor.playing
        val act = activeKey
        var bestKey: String? = null
        var bestTier = Int.MAX_VALUE
        var bestSec = Long.MAX_VALUE

        for (key in order) {
            if (key in inFlight) continue
            val r = res[key]
            val st = r?.state ?: CheckState.UNKNOWN
            val due = st == CheckState.UNKNOWN || r == null || r.nextCheckAt <= now
            val boost = boosts[key]
            if (boost == null && (deferred[key] ?: 0L) > now) continue

            var tier: Int
            var sec: Long
            if (boost != null) {
                tier = 0
                sec = boost.at
            } else if (playing) {
                val freshAlive = st == CheckState.ALIVE && !due
                if (key == act && !freshAlive) {
                    tier = 1
                    sec = 0L
                } else if (due && !freshAlive && neighborKeys.contains(key)) {
                    tier = 2
                    sec = neighborKeys.indexOf(key).toLong()
                } else if (st == CheckState.SUSPECT || !due) {
                    continue
                } else {
                    tier = when (st) {
                        CheckState.UNKNOWN -> 3
                        CheckState.DEAD -> 4
                        else -> 5
                    }
                    sec = r?.nextCheckAt ?: 0L
                }
            } else {
                if (!due) continue
                val recentIdx = recentKeys.indexOf(key)
                if (recentIdx >= 0) {
                    tier = 1
                    sec = recentIdx.toLong()
                } else {
                    tier = when (st) {
                        CheckState.UNKNOWN -> 2
                        CheckState.SUSPECT -> 3
                        CheckState.DEAD -> 4
                        CheckState.ALIVE -> 5
                    }
                    sec = r?.nextCheckAt ?: 0L
                }
            }
            if (tier < bestTier || (tier == bestTier && sec < bestSec)) {
                bestKey = key
                bestTier = tier
                bestSec = sec
            }
        }
        val key = bestKey ?: return null
        val ch = channels[key] ?: return null
        val prev = res[key]
        val prevIdx = if (prev != null && prev.state == CheckState.ALIVE) prev.idx else -1
        return Pick(key, ch, sigs[key].orEmpty(), epochs[key] ?: 0, generation, prevIdx = prevIdx)
    }

    /**
     * Очередь проверок содержимого. Порядок: ещё не проверенные (недавние первыми) → повторные проверки
     * после первого провала → плановые перепроверки хороших и скрытых каналов.
     * Повторы и плановые перепроверки ждут, пока не закончатся первые проверки и проверка доступности,
     * то есть выполняются «на последок».
     */
    private fun pickContentLocked(now: Long): Pick? {
        val res = _results.value
        var firstPass: String? = null
        var firstPassRecent = Int.MAX_VALUE
        var retryKey: String? = null
        var laterKey: String? = null
        var laterAt = Long.MAX_VALUE
        var networkPending = false
        var firstPassPending = false

        for (key in order) {
            val r = res[key]
            if (r == null || r.state == CheckState.UNKNOWN) {
                networkPending = true
                continue
            }
            if (r.state != CheckState.ALIVE) continue
            if (key in inFlight) {
                if (r.content == ContentState.UNVERIFIED) firstPassPending = true
                continue
            }
            val blocked = (contentDeferred[key] ?: 0L) > now
            when (r.content) {
                ContentState.UNVERIFIED -> {
                    if (blocked) continue
                    firstPassPending = true
                    val ri = recentKeys.indexOf(key).let { if (it < 0) Int.MAX_VALUE - 1 else it }
                    if (firstPass == null || ri < firstPassRecent) {
                        firstPass = key
                        firstPassRecent = ri
                    }
                }
                ContentState.RETRY -> if (!blocked && r.contentNextAt <= now && retryKey == null) retryKey = key
                ContentState.OK, ContentState.BAD ->
                    if (!blocked && r.contentNextAt <= now && r.contentNextAt < laterAt) {
                        laterKey = key
                        laterAt = r.contentNextAt
                    }
            }
        }
        val key = when {
            firstPass != null -> firstPass
            // «На последок»: пока не закончено первое прохождение, повторы не начинаем.
            firstPassPending || networkPending -> null
            retryKey != null -> retryKey
            else -> laterKey
        } ?: return null
        val ch = channels[key] ?: return null
        val r = res.getValue(key)
        return Pick(
            key = key,
            channel = ch,
            sig = sigs[key].orEmpty(),
            epoch = epochs[key] ?: 0,
            gen = generation,
            prevIdx = r.idx,
            content = true,
            allStreams = r.content != ContentState.UNVERIFIED,
        )
    }

    /** До ближайшей будущей перепроверки (просроченные, но отложенные каналы не считаются). */
    private fun nextDueDelayLocked(now: Long): Long {
        var min = Long.MAX_VALUE
        for ((key, r) in _results.value) {
            if (key in inFlight || !channels.containsKey(key)) continue
            if (r.nextCheckAt > now && r.nextCheckAt < min) min = r.nextCheckAt
            if (r.state == CheckState.ALIVE && r.content != ContentState.UNVERIFIED &&
                r.contentNextAt > now && r.contentNextAt < min
            ) {
                min = r.contentNextAt
            }
        }
        for ((key, until) in contentDeferred) {
            if (channels.containsKey(key) && until > now && until < min) min = until
        }
        if (min == Long.MAX_VALUE) return IDLE_LONG_MS
        return (min - now).coerceIn(500L, IDLE_LONG_MS)
    }

    private suspend fun runCheck(p: Pick) {
        val offlineBefore = governor.offlineEpoch
        var finished = false
        try {
            val idx = try {
                checker.check(p.channel, p.prevIdx)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                StreamChecker.INCONCLUSIVE
            }
            // Неудача при потерянной сети ничего не доказывает: результат не засчитываем, канал остаётся в очереди.
            val lostNetwork = idx < 0 && (governor.offlineEpoch != offlineBefore || !governor.isOnline())
            finish(p, idx, lostNetwork)
            finished = true
        } finally {
            if (!finished) {
                synchronized(lock) { inFlight.remove(p.key) }
            }
            wake()
        }
    }

    private fun finish(p: Pick, idx: Int, lostNetwork: Boolean) {
        val now = System.currentTimeMillis()
        var saved = false
        synchronized(lock) {
            inFlight.remove(p.key)
            val stale = p.gen != generation ||
                (epochs[p.key] ?: 0) != p.epoch ||
                sigs[p.key] != p.sig ||
                !channels.containsKey(p.key)
            if (stale || !lostNetwork) {
                boosts.remove(p.key)
                bulk.remove(p.key)
            }
            if (!stale && !lostNetwork) {
                if (idx == StreamChecker.INCONCLUSIVE) {
                    deferred[p.key] = now + INCONCLUSIVE_DEFER_MS
                } else {
                    _results.value = _results.value + (p.key to nextResult(_results.value[p.key], idx, now, p.sig))
                    saved = true
                }
            }
            updateBacklogLocked()
            maybeFinishInitialLocked()
        }
        if (saved) signalSave()
    }

    private suspend fun runContentCheck(p: Pick) {
        val offlineBefore = governor.offlineEpoch
        var finished = false
        try {
            val verdict = try {
                checker.checkContent(p.channel, p.prevIdx, p.allStreams)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ContentVerdict(ContentKind.INCONCLUSIVE, p.prevIdx)
            }
            val lostNetwork = verdict.kind != ContentKind.OK &&
                (governor.offlineEpoch != offlineBefore || !governor.isOnline())
            finishContent(p, verdict, lostNetwork)
            finished = true
        } finally {
            if (!finished) {
                synchronized(lock) {
                    inFlight.remove(p.key)
                    contentInFlight = (contentInFlight - 1).coerceAtLeast(0)
                }
            }
            wake()
        }
    }

    private fun finishContent(p: Pick, v: ContentVerdict, lostNetwork: Boolean) {
        val now = System.currentTimeMillis()
        var saved = false
        synchronized(lock) {
            inFlight.remove(p.key)
            contentInFlight = (contentInFlight - 1).coerceAtLeast(0)
            val stale = p.gen != generation ||
                (epochs[p.key] ?: 0) != p.epoch ||
                sigs[p.key] != p.sig ||
                !channels.containsKey(p.key)
            val prev = _results.value[p.key]
            if (!stale && !lostNetwork && prev != null && prev.state == CheckState.ALIVE) {
                var kind = v.kind
                if (kind == ContentKind.INCONCLUSIVE) {
                    // Несколько неубедительных проверок подряд — это уже провал (поток не стартует нормально).
                    val n = (contentInconclusive[p.key] ?: 0) + 1
                    if (n >= Config.CONTENT_MAX_INCONCLUSIVE) {
                        contentInconclusive.remove(p.key)
                        kind = ContentKind.FAILED
                    } else {
                        contentInconclusive[p.key] = n
                        contentDeferred[p.key] = now + INCONCLUSIVE_DEFER_MS
                    }
                } else {
                    contentInconclusive.remove(p.key)
                    contentDeferred.remove(p.key)
                }
                if (kind != ContentKind.INCONCLUSIVE) {
                    _results.value = _results.value + (p.key to contentResult(prev, kind, v.idx, now))
                    saved = true
                    maybeFinishInitialLocked()
                }
            }
        }
        if (saved) signalSave()
    }

    /** Применяет вердикт по содержимому: OK показывает канал, первый провал → RETRY, второй → BAD. */
    private fun contentResult(prev: CheckResult, kind: ContentKind, idx: Int, now: Long): CheckResult {
        if (kind == ContentKind.OK) {
            return prev.copy(
                state = CheckState.ALIVE,
                idx = idx,
                wasAlive = true,
                content = ContentState.OK,
                contentAt = now,
                contentNextAt = now + Config.CONTENT_OK_INTERVAL_MS,
                contentFails = 0,
                contentReason = "",
            )
        }
        val reason = when (kind) {
            ContentKind.STATIC -> "static"
            ContentKind.SILENT -> "silent"
            ContentKind.STATIC_SILENT -> "static+silent"
            else -> "failed"
        }
        val fails = prev.contentFails + 1
        // Второй провал подряд (на повторной проверке) — канал скрыт надолго; первый — повтор в конце очереди.
        val confirmed = prev.content == ContentState.RETRY || prev.content == ContentState.BAD
        return prev.copy(
            content = if (confirmed) ContentState.BAD else ContentState.RETRY,
            contentAt = now,
            contentNextAt = now + if (confirmed) Config.CONTENT_BAD_INTERVAL_MS else Config.CONTENT_RETRY_GAP_MS,
            contentFails = fails,
            contentReason = reason,
        )
    }

    // ---------- состояния и интервалы ----------

    private fun nextResult(prev: CheckResult?, idx: Int, now: Long, sig: String, fromPlayback: Boolean = false): CheckResult {
        // Проверка содержимого переживает проверки доступности, но не смену потока (кроме воспроизведения: там смотрят).
        val keepContent = prev != null && (fromPlayback || idx < 0 || prev.idx < 0 || prev.idx == idx)
        val q = if (keepContent) prev else null
        if (idx >= 0) {
            return CheckResult(
                state = CheckState.ALIVE,
                idx = idx,
                checkedAt = now,
                nextCheckAt = now + Config.ALIVE_INTERVAL_MS,
                failStreak = 0,
                firstFailAt = 0L,
                sig = sig,
                wasAlive = true,
                content = q?.content ?: ContentState.UNVERIFIED,
                contentAt = q?.contentAt ?: 0L,
                contentNextAt = q?.contentNextAt ?: 0L,
                contentFails = q?.contentFails ?: 0,
                contentReason = q?.contentReason ?: "",
            )
        }
        val streak = (prev?.failStreak ?: 0) + 1
        val firstFail = if (prev == null || prev.failStreak == 0) now else prev.firstFailAt
        val dead = streak >= Config.DEAD_MIN_FAILS && now - firstFail >= Config.DEAD_MIN_GAP_MS
        val interval = when {
            !dead -> Config.SUSPECT_INTERVAL_MS
            streak <= 2 -> Config.DEAD_INTERVAL_1_MS
            streak == 3 -> Config.DEAD_INTERVAL_2_MS
            else -> Config.DEAD_INTERVAL_3_MS
        }
        return CheckResult(
            state = if (dead) CheckState.DEAD else CheckState.SUSPECT,
            idx = -1,
            checkedAt = now,
            nextCheckAt = now + interval,
            failStreak = streak,
            firstFailAt = firstFail,
            sig = sig,
            wasAlive = prev?.wasAlive == true,
            content = q?.content ?: ContentState.UNVERIFIED,
            contentAt = q?.contentAt ?: 0L,
            contentNextAt = q?.contentNextAt ?: 0L,
            contentFails = q?.contentFails ?: 0,
            contentReason = q?.contentReason ?: "",
        )
    }

    private fun updateBacklogLocked() {
        if (bulk.isEmpty()) {
            bulkTotal = 0
            _backlog.value = Pair(0, 0)
        } else {
            _backlog.value = Pair(bulkTotal - bulk.size, bulkTotal)
        }
    }

    /** Первоначальная проверка завершена, когда у всех каналов есть хотя бы один результат. */
    private fun maybeFinishInitialLocked() {
        if (passive) {
            _initialDone.value = true
            return
        }
        if (_initialDone.value || channels.isEmpty()) return
        val res = _results.value
        // Готово, когда у всех есть результат доступности, а у рабочих — и вердикт по картинке/звуку
        // (неубедительные, отложенные проверки ожидание не держат).
        val now = System.currentTimeMillis()
        val done = channels.keys.all { key ->
            val r = res[key]
            when {
                r == null || r.state == CheckState.UNKNOWN -> false
                r.state == CheckState.ALIVE && r.content == ContentState.UNVERIFIED ->
                    (contentDeferred[key] ?: 0L) > now
                else -> true
            }
        }
        if (done) {
            _initialDone.value = true
            signalSave()
        }
    }

    // ---------- сохранение ----------

    private suspend fun runSaver() {
        var seen = saveTick.value
        while (currentCoroutineContext().isActive) {
            saveTick.first { it != seen }
            seen = saveTick.value
            saveNow()
        }
    }

    private suspend fun saveNow() {
        val snap = synchronized(lock) { CheckCache.Snapshot(_initialDone.value, _results.value) }
        store.save(snap)
    }

    private companion object {
        const val IDLE_MS = 2_000L
        const val BUSY_MS = 1_000L
        const val IDLE_LONG_MS = 60_000L
        const val INCONCLUSIVE_DEFER_MS = 5L * 60_000L
    }
}
