package com.tvitto.app

import android.app.Application
import coil.ImageLoader
import coil.ImageLoaderFactory
import coil.disk.DiskCache
import coil.memory.MemoryCache
import com.tvitto.app.update.Updater
import androidx.work.Constraints
import androidx.work.NetworkType
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.tvitto.app.data.PlaylistRefreshWorker
import java.util.concurrent.TimeUnit

class TVittoApplication : Application(), ImageLoaderFactory {

    override fun onCreate() {
        super.onCreate()
        // Подчищаем недокачанные и уже установленные APK обновлений.
        Thread { Updater.cleanup(this) }.start()
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.UNMETERED)
            .setRequiresCharging(true)
            .build()
        val request = PeriodicWorkRequestBuilder<PlaylistRefreshWorker>(12, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()
        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "tvitto_playlist_refresh",
            ExistingPeriodicWorkPolicy.KEEP,
            request,
        )
    }

    override fun newImageLoader(): ImageLoader =
        ImageLoader.Builder(this)
            .memoryCache {
                MemoryCache.Builder(this)
                    .maxSizePercent(0.20)
                    .build()
            }
            .diskCache {
                DiskCache.Builder()
                    .directory(cacheDir.resolve("logos"))
                    .maxSizeBytes(100L * 1024 * 1024)
                    .build()
            }
            .respectCacheHeaders(false)
            // Без crossfade: анимация появления логотипов нагружает слабые ТВ при прокрутке.
            .crossfade(false)
            .build()
}
