package com.tvitto.app.data

import com.tvitto.app.Config
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

object Net {

    /** Клиент для быстрых проверок доступности каналов. */
    val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(Config.CHECK_TIMEOUT_SEC, TimeUnit.SECONDS)
            .readTimeout(Config.CHECK_TIMEOUT_SEC, TimeUnit.SECONDS)
            .callTimeout(Config.CHECK_TIMEOUT_SEC + 1, TimeUnit.SECONDS)
            .followRedirects(true)
            .followSslRedirects(true)
            .retryOnConnectionFailure(false)
            .build()
    }

    /** Клиент для загрузки плейлистов (они большие, таймауты длиннее). */
    val playlistClient: OkHttpClient by lazy {
        client.newBuilder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(30, TimeUnit.SECONDS)
            .callTimeout(45, TimeUnit.SECONDS)
            .retryOnConnectionFailure(true)
            .build()
    }
}
