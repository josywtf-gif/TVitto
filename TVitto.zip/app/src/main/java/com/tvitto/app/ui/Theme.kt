package com.tvitto.app.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color

val Cyan = Color(0xFF22D3FF)
val Blue = Color(0xFF2F7BFF)
val LogoBg = Color(0xFF0B1118)
val SuspectGray = Color(0xFF8A94A0)

private val DarkColors = darkColorScheme(
    primary = Cyan,
    onPrimary = Color(0xFF00131F),
    secondary = Blue,
    background = Color(0xFF05080D),
    onBackground = Color(0xFFE8F1FA),
    surface = Color(0xFF101720),
    onSurface = Color(0xFFE8F1FA),
    surfaceVariant = Color(0xFF16202B),
    onSurfaceVariant = Color(0xFF9FB3C8),
    error = Color(0xFFFF6B6B),
)

/** true, если приложение запущено на Android TV (управление пультом). */
val LocalIsTv = staticCompositionLocalOf { false }

@Composable
fun TVittoTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColors,
        typography = Typography(),
        content = content,
    )
}
