package com.tvitto.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first

private val Context.recentDataStore by preferencesDataStore(name = "tvitto_recent")

/** «Недавние» в DataStore: key (tvg-id или URL), имя, логотип. Самый свежий — первым. */
class RecentStore(context: Context) {

    private val store = context.applicationContext.recentDataStore
    private val listKey = stringPreferencesKey("recent_v1")

    suspend fun load(): List<RecentEntry> {
        return try {
            val raw = store.data.first()[listKey].orEmpty()
            raw.lineSequence()
                .mapNotNull { line ->
                    val p = line.split('\t')
                    if (p.size < 2 || p[0].isEmpty()) {
                        null
                    } else {
                        RecentEntry(p[0], p[1], p.getOrNull(2)?.takeIf { it.isNotEmpty() })
                    }
                }
                .toList()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun save(list: List<RecentEntry>) {
        val text = list.joinToString("\n") { e ->
            listOf(e.key, e.name, e.logo.orEmpty()).joinToString("\t") { it.replace('\t', ' ').replace('\n', ' ') }
        }
        try {
            store.edit { it[listKey] = text }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // best effort
        }
    }
}
