package com.tvitto.app.data

import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class PlaylistRepository(private val client: OkHttpClient = Net.playlistClient) {

    /** Загружает все встроенные плейлисты, объединяет и убирает дубликаты. */
    suspend fun load(): List<Channel> = coroutineScope {
        val federalText = async { fetchFirstValid(Config.FEDERAL_PLAYLIST) }
        val texts = Config.PLAYLISTS
            .map { mirrors -> async { fetchFirstValid(mirrors) } }
            .awaitAll()
            .filterNotNull()
        val federal = federalText.await()
        if (texts.isEmpty() && federal == null) throw IOException("Не удалось загрузить плейлисты")

        withContext(Dispatchers.Default) {
            // Федеральные — все каналы отдельного плейлиста; одноимённые из общих плейлистов не дублируем.
            val fed = if (federal == null) emptyList() else merge(M3uParser.parse(federal), Categories.FEDERAL, "fed:")
            val fedNames = fed.mapTo(HashSet()) { normName(it.name) }
            val main = merge(texts.flatMap { M3uParser.parse(it) }).filter { normName(it.name) !in fedNames }
            (fed + main).sortedBy { it.name.lowercase() }
        }
    }

    /** Разбирает текст плейлиста (для своего источника) в список каналов. */
    suspend fun parseText(text: String): List<Channel> = withContext(Dispatchers.Default) {
        merge(M3uParser.parse(text))
    }

    /** Скачивает один плейлист по ссылке; null — не удалось или это не плейлист. */
    suspend fun fetchText(url: String): String? = fetchFirstValid(listOf(url))

    private suspend fun fetchFirstValid(urls: List<String>): String? {
        for (url in urls) {
            val text = try {
                runInterruptible(Dispatchers.IO) { fetch(url) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            // Если вернулся HTML (например, страница GitHub) — это не плейлист.
            if (text != null && text.take(512).let { it.contains("#EXTM3U") || it.contains("#EXTINF") }) return text
        }
        return null
    }

    private fun fetch(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", Config.DEFAULT_UA)
            .build()
        return client.newCall(request).execute().use { r ->
            if (r.isSuccessful) r.body?.string() else null
        }
    }

    private class Acc(
        val key: String,
        val name: String,
        var logo: String?,
        var group: String?,
        val streams: MutableList<StreamSource>,
    )

    private val bracketTags = Regex("""\s*\[[^\]]*]""")
    private val qualityTag = Regex("""\s*\(\d{3,4}[pi]\)""")

    private fun cleanName(raw: String): String {
        val cleaned = raw.replace(bracketTags, "").replace(qualityTag, "").trim()
        return cleaned.ifEmpty { raw.trim() }
    }

    /**
     * Дубликаты убираем по URL; потоки с одним tvg-id склеиваем в один канал.
     * Записи без tvg-id с тем же названием, что у уже известного канала, считаем его вторым потоком.
     */
    private fun normName(name: String): String = name.lowercase().filter { it.isLetterOrDigit() }

    private fun merge(
        entries: List<M3uParser.Entry>,
        forceCategory: String? = null,
        keyPrefix: String = "",
    ): List<Channel> {
        val seenUrls = HashSet<String>()
        val byKey = LinkedHashMap<String, Acc>()
        val byName = HashMap<String, Acc>()

        for (e in entries) {
            if (!seenUrls.add(e.stream.url)) continue
            val cleaned = cleanName(e.name)
            val nameKey = normName(cleaned)
            val key = keyPrefix + (e.tvgId ?: e.stream.url)
            val acc = byKey[key] ?: if (e.tvgId == null && nameKey.isNotEmpty()) byName[nameKey] else null
            if (acc == null) {
                val created = Acc(key, cleaned, e.logo, e.group, mutableListOf(e.stream))
                byKey[key] = created
                if (nameKey.isNotEmpty()) byName.putIfAbsent(nameKey, created)
            } else {
                acc.streams.add(e.stream)
                if (acc.logo == null) acc.logo = e.logo
                if (acc.group.isNullOrBlank() || acc.group.equals("undefined", ignoreCase = true)) {
                    acc.group = e.group
                }
            }
        }

        return byKey.values
            .map {
                Channel(
                    key = it.key,
                    name = it.name,
                    logo = it.logo,
                    group = it.group,
                    category = forceCategory ?: Categories.map(it.group, it.name),
                    streams = it.streams.toList(),
                )
            }
            .sortedBy { it.name.lowercase() }
    }
}
