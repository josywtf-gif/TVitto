package com.tvitto.app.data

import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException

class PlaylistRepository(private val client: OkHttpClient = Net.playlistClient) {

    /** Загружает все встроенные плейлисты, объединяет и убирает дубликаты. */
    suspend fun load(): List<Channel> = coroutineScope {
        val texts = Config.PLAYLISTS
            .map { mirrors -> async { fetchFirstValid(mirrors) } }
            .awaitAll()
            .filterNotNull()
        if (texts.isEmpty()) throw IOException("Не удалось загрузить плейлисты")

        withContext(Dispatchers.Default) {
            merge(texts.flatMap { M3uParser.parse(it) })
        }
    }

    private suspend fun fetchFirstValid(urls: List<String>): String? {
        for (url in urls) {
            val text = try {
                runInterruptible(Dispatchers.IO) { fetch(url) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
            // Если вернулся HTML (например, страница GitHub) — это не плейлист.
            if (text != null && text.take(256).contains("#EXTM3U")) return text
        }
        return null
    }

    private fun fetch(url: String): String? {
        val request = Request.Builder()
            .url(url)
            .header("User-Agent", Config.DEFAULT_UA)
            .build()
        return client.newCall(request).execute().use { r ->
            if (r.isSuccessful) r.body?.string() else null
        }
    }

    private class Acc(
        val key: String,
        val name: String,
        var logo: String?,
        var group: String?,
        val streams: MutableList<StreamSource>,
    )

    private val bracketTags = Regex("""\s*\[[^\]]*]""")
    private val qualityTag = Regex("""\s*\(\d{3,4}[pi]\)""")

    private fun cleanName(raw: String): String {
        val cleaned = raw.replace(bracketTags, "").replace(qualityTag, "").trim()
        return cleaned.ifEmpty { raw.trim() }
    }

    /** Дубликаты убираем по URL; потоки с одним tvg-id склеиваем в один канал. */
    private fun merge(entries: List<M3uParser.Entry>): List<Channel> {
        val seenUrls = HashSet<String>()
        val byKey = LinkedHashMap<String, Acc>()

        for (e in entries) {
            if (!seenUrls.add(e.stream.url)) continue
            val key = e.tvgId ?: e.stream.url
            val acc = byKey[key]
            if (acc == null) {
                byKey[key] = Acc(key, cleanName(e.name), e.logo, e.group, mutableListOf(e.stream))
            } else {
                acc.streams.add(e.stream)
                if (acc.logo == null) acc.logo = e.logo
                if (acc.group.isNullOrBlank() || acc.group.equals("undefined", ignoreCase = true)) {
                    acc.group = e.group
                }
            }
        }

        return byKey.values
            .map {
                Channel(
                    key = it.key,
                    name = it.name,
                    logo = it.logo,
                    group = it.group,
                    category = Categories.map(it.group, it.name),
                    streams = it.streams.toList(),
                )
            }
            .sortedBy { it.name.lowercase() }
    }
}
