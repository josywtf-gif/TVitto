package com.tvitto.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.SubcomposeAsyncImage
import coil.request.ImageRequest
import com.tvitto.app.data.Channel
import com.tvitto.app.data.CheckState

@Composable
fun ChannelCard(
    channel: Channel,
    compact: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth().alpha(if (enabled) 1f else 0.46f),
        enabled = enabled,
        focusable = enabled,
        onLongClick = onLongClick,
    ) {
        if (compact) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(72.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Box(
                    modifier = Modifier
                        .size(72.dp)
                        .background(LogoBg),
                    contentAlignment = Alignment.Center,
                ) {
                    ChannelLogo(channel, Modifier.fillMaxSize().padding(10.dp))
                    StateDot(channel)
                }
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 14.dp),
                ) {
                    ChannelTexts(channel)
                }
            }
        } else {
            Column(Modifier.fillMaxWidth()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 10f)
                        .background(LogoBg),
                    contentAlignment = Alignment.Center,
                ) {
                    ChannelLogo(channel, Modifier.fillMaxSize().padding(16.dp))
                    StateDot(channel)
                }
                Column(Modifier.padding(horizontal = 12.dp, vertical = 10.dp)) {
                    ChannelTexts(channel)
                }
            }
        }
    }
}

/** Серый индикатор у сомнительного (suspect) канала. */
@Composable
fun BoxScope.StateDot(channel: Channel) {
    if (channel.state != CheckState.SUSPECT) return
    Box(
        modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(8.dp)
            .size(10.dp)
            .background(SuspectGray, CircleShape),
    )
}

@Composable
private fun ChannelTexts(channel: Channel) {
    val isTv = LocalIsTv.current
    Text(
        text = channel.name,
        color = if (channel.state == CheckState.UNKNOWN) Color(0xFF858B92) else Color.White,
        fontSize = if (isTv) 16.sp else 15.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
    Text(
        text = channel.category,
        color = if (channel.state == CheckState.UNKNOWN) Color(0xFF666D75) else MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = 12.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun ChannelLogo(channel: Channel, modifier: Modifier = Modifier) {
    val logo = channel.logo
    if (logo.isNullOrBlank()) {
        Initials(channel.name, modifier)
        return
    }
    val context = LocalContext.current
    val request = remember(logo) {
        ImageRequest.Builder(context)
            .data(logo)
            .size(256)
            .crossfade(true)
            .build()
    }
    SubcomposeAsyncImage(
        model = request,
        contentDescription = channel.name,
        modifier = modifier,
        contentScale = ContentScale.Fit,
        loading = { Initials(channel.name, Modifier.fillMaxSize()) },
        error = { Initials(channel.name, Modifier.fillMaxSize()) },
    )
}

@Composable
private fun Initials(name: String, modifier: Modifier) {
    val text = name
        .split(' ', '-', '.', '_')
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
        .ifEmpty { "TV" }
    Box(modifier, contentAlignment = Alignment.Center) {
        Text(
            text = text,
            color = Cyan.copy(alpha = 0.85f),
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
