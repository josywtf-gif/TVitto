package com.tvitto.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import coil.request.ImageRequest
import com.tvitto.app.data.Channel
import com.tvitto.app.data.CheckState

/**
 * Строка канала: логотип слева, название и категория справа. Один вид для ТВ и телефона
 * (на ТВ строка крупнее и почти не масштабируется при фокусе — список не «пляшет»).
 */
@Composable
fun ChannelRow(
    channel: Channel,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
) {
    val isTv = LocalIsTv.current
    val rowHeight = if (isTv) 76.dp else 64.dp
    FocusSurface(
        onClick = onClick,
        // alpha-слой создаём только для недоступных строк.
        modifier = modifier.fillMaxWidth().then(if (enabled) Modifier else Modifier.alpha(0.46f)),
        enabled = enabled,
        focusable = enabled,
        onLongClick = onLongClick,
        focusScale = if (isTv) 1.02f else 1f,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(rowHeight),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Box(
                modifier = Modifier
                    .size(rowHeight)
                    .background(LogoBg),
                contentAlignment = Alignment.Center,
            ) {
                ChannelLogo(channel, Modifier.fillMaxSize().padding(if (isTv) 12.dp else 10.dp))
                StateDot(channel)
            }
            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = if (isTv) 20.dp else 14.dp),
            ) {
                ChannelTexts(channel)
            }
        }
    }
}

/** Серый индикатор у сомнительного (suspect) канала. */
@Composable
fun BoxScope.StateDot(channel: Channel) {
    if (channel.state != CheckState.SUSPECT) return
    Box(
        modifier = Modifier
            .align(Alignment.TopEnd)
            .padding(8.dp)
            .size(10.dp)
            .background(SuspectGray, CircleShape),
    )
}

@Composable
private fun ChannelTexts(channel: Channel) {
    val isTv = LocalIsTv.current
    Text(
        text = channel.name,
        color = if (channel.state == CheckState.UNKNOWN) Color(0xFF858B92) else Color.White,
        fontSize = if (isTv) 20.sp else 16.sp,
        fontWeight = FontWeight.SemiBold,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
    Text(
        text = channel.category,
        color = if (channel.state == CheckState.UNKNOWN) Color(0xFF666D75) else MaterialTheme.colorScheme.onSurfaceVariant,
        fontSize = if (isTv) 14.sp else 12.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

@Composable
fun ChannelLogo(channel: Channel, modifier: Modifier = Modifier) {
    val logo = channel.logo
    if (logo.isNullOrBlank()) {
        Initials(channel.name, modifier)
        return
    }
    val context = LocalContext.current
    val request = remember(logo) {
        ImageRequest.Builder(context)
            .data(logo)
            .size(160)
            .build()
    }
    // SubcomposeAsyncImage создаёт SubcomposeLayout на каждую карточку — в сетке с D-pad-скроллом
    // это заметные просадки. Обычный AsyncImage + флаг «загружено» даёт тот же результат дешевле:
    // пока логотип грузится или не загрузился (ошибка), остаются инициалы.
    var loaded by remember(logo) { mutableStateOf(false) }
    Box(modifier) {
        if (!loaded) Initials(channel.name, Modifier.fillMaxSize())
        AsyncImage(
            model = request,
            contentDescription = channel.name,
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Fit,
            onSuccess = { loaded = true },
        )
    }
}

@Composable
private fun Initials(name: String, modifier: Modifier) {
    val text = name
        .split(' ', '-', '.', '_')
        .filter { it.isNotBlank() }
        .take(2)
        .joinToString("") { it.first().uppercase() }
        .ifEmpty { "TV" }
    Box(modifier, contentAlignment = Alignment.Center) {
        Text(
            text = text,
            color = Cyan.copy(alpha = 0.85f),
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
        )
    }
}
