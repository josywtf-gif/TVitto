package com.tvitto.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvitto.app.data.Categories
import com.tvitto.app.data.Channel
import com.tvitto.app.data.CheckState
import com.tvitto.app.data.Phase
import com.tvitto.app.data.Source
import com.tvitto.app.data.UiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch

private enum class ListMode { Shimmer, Error, Empty, Channels }

@Composable
fun ChannelListScreen(
    state: UiState,
    listState: LazyListState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
    onRetryChannel: (Channel) -> Unit,
    onRetry: () -> Unit,
    onSelectCategory: (String) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val isTv = LocalIsTv.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerOpen = drawerState.targetValue == DrawerValue.Open

    val menuFocus = remember { FocusRequester() }
    val drawerFocus = remember { FocusRequester() }

    // Назад закрывает открытое меню.
    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    // TV: при открытии меню фокус на активной категории, при закрытии — на кнопку меню.
    var wasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(drawerOpen) {
        if (isTv) {
            if (drawerOpen) {
                delay(120)
                runCatching { drawerFocus.requestFocus() }
            } else if (wasOpen) {
                delay(120)
                runCatching { menuFocus.requestFocus() }
            }
        }
        wasOpen = drawerOpen
    }

    // При смене категории список прокручивается вверх.
    var lastSelected by remember { mutableStateOf(state.selected) }
    LaunchedEffect(state.selected) {
        if (lastSelected != state.selected) {
            lastSelected = state.selected
            listState.scrollToItem(0)
        }
    }

    val mode = when {
        state.phase == Phase.Error -> ListMode.Error
        state.phase == Phase.Loading -> ListMode.Shimmer
        state.channels.isNotEmpty() -> ListMode.Channels
        state.selected == Categories.RECENT || state.selected == Categories.FAVORITES -> ListMode.Empty
        state.total == 0 -> ListMode.Shimmer
        state.initialDone -> ListMode.Empty
        else -> ListMode.Shimmer
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            CategoryDrawer(
                categories = state.categories,
                counts = state.counts,
                selected = state.selected,
                open = drawerOpen,
                focusRequester = drawerFocus,
                onSelect = { name ->
                    onSelectCategory(name)
                    scope.launch { drawerState.close() }
                },
                onSettings = {
                    scope.launch { drawerState.close() }
                    onOpenSettings()
                },
            )
        },
        modifier = Modifier.onPreviewKeyEvent { event ->
            // Кнопка «Меню» на пульте открывает/закрывает боковое меню.
            if (event.type == KeyEventType.KeyDown && event.key == Key.Menu) {
                scope.launch {
                    if (drawerState.isOpen) drawerState.close() else drawerState.open()
                }
                true
            } else {
                false
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            Header(
                state = state,
                isTv = isTv,
                menuFocus = menuFocus,
                onMenu = { scope.launch { drawerState.open() } },
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                if (isTv) {
                    // На ТВ не анимируем смену списка через Crossfade: это лишняя нагрузка на GPU.
                    ListContent(mode, state, listState, focusKey, onOpen, onRetryChannel, onRetry, onSelectCategory)
                } else {
                    Crossfade(targetState = mode, label = "listMode") { m ->
                        ListContent(m, state, listState, focusKey, onOpen, onRetryChannel, onRetry, onSelectCategory)
                    }
                }
            }
        }
    }
}

@Composable
private fun ListContent(
    mode: ListMode,
    state: UiState,
    listState: LazyListState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
    onRetryChannel: (Channel) -> Unit,
    onRetry: () -> Unit,
    onSelectCategory: (String) -> Unit,
) {
    when (mode) {
        ListMode.Shimmer -> ShimmerList()
        ListMode.Error -> MessageState(
            title = "Ошибка загрузки",
            text = if (state.source == Source.CUSTOM) {
                "Не удалось прочитать свой плейлист. Добавьте его заново: Настройки → Выбор источника."
            } else {
                "Не удалось получить список каналов. Проверьте подключение к интернету."
            },
            button = "Повторить",
            onClick = onRetry,
        )
        ListMode.Empty -> if (state.selected == Categories.RECENT || state.selected == Categories.FAVORITES) {
            val favorites = state.selected == Categories.FAVORITES
            MessageState(
                title = if (favorites) "Избранное пусто" else "Нет недавних каналов",
                text = if (favorites) {
                    "Добавляйте каналы в избранное непосредственно в плеере."
                } else {
                    "Здесь появятся последние 10 просмотренных каналов."
                },
                button = "Все каналы",
                onClick = { onSelectCategory(Categories.ALL) },
            )
        } else {
            MessageState(
                title = "Нет доступных каналов",
                text = "Сейчас ни один канал не отвечает. Попробуйте позже.",
                button = "Повторить",
                onClick = onRetry,
            )
        }
        ListMode.Channels -> ChannelList(state.channels, listState, focusKey, onOpen, onRetryChannel)
    }
}

@Composable
private fun Header(
    state: UiState,
    isTv: Boolean,
    menuFocus: FocusRequester,
    onMenu: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = if (isTv) 48.dp else 18.dp,
                vertical = if (isTv) 20.dp else 12.dp,
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MenuButton(
            onClick = onMenu,
            size = if (isTv) 52.dp else 44.dp,
            modifier = Modifier.focusRequester(menuFocus),
        )
        Spacer(Modifier.width(14.dp))
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White)) { append("TV") }
                withStyle(SpanStyle(color = Cyan)) { append("itto") }
            },
            fontSize = if (isTv) 34.sp else 26.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        if (state.selected != Categories.ALL) {
            Spacer(Modifier.width(12.dp))
            Text(
                text = state.selected,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = if (isTv) 20.sp else 16.sp,
                fontWeight = FontWeight.Medium,
            )
        }
        Spacer(Modifier.weight(1f))
        val checking = state.phase == Phase.Ready && !state.initialDone && state.total > 0
        val backgroundChecking = state.bgTotal > 0
        AnimatedVisibility(
            visible = state.offline || checking || backgroundChecking,
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            val done = if (checking) state.checked else state.bgDone
            val total = if (checking) state.total else state.bgTotal
            Column(
                modifier = Modifier.width(if (isTv) 190.dp else 118.dp),
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.spacedBy(4.dp),
            ) {
                Text(
                    text = if (state.offline) "Нет сети" else "Проверка $done/$total",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = if (isTv) 13.sp else 10.sp,
                    maxLines = 1,
                )
                LinearProgressIndicator(
                    progress = { if (state.offline || total <= 0) 0f else (done.toFloat() / total).coerceIn(0f, 1f) },
                    modifier = Modifier.fillMaxWidth().height(3.dp),
                    color = Cyan,
                    trackColor = Color(0x33FFFFFF),
                )
            }
        }
    }
}

/** Иконка-гамбургер. Фокусируется пультом, тапается пальцем. */
@Composable
private fun MenuButton(onClick: () -> Unit, size: Dp, modifier: Modifier = Modifier) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.size(size),
        shape = RoundedCornerShape(12.dp),
        containerColor = Color(0x22FFFFFF),
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            repeat(3) {
                Box(
                    Modifier
                        .width(20.dp)
                        .height(2.dp)
                        .background(Color.White, RoundedCornerShape(1.dp)),
                )
            }
        }
    }
}

/** Выдвижное меню категорий. Пока закрыто — пункты не получают фокус пульта. */
@Composable
private fun CategoryDrawer(
    categories: List<String>,
    counts: Map<String, Int>,
    selected: String,
    open: Boolean,
    focusRequester: FocusRequester,
    onSelect: (String) -> Unit,
    onSettings: () -> Unit,
) {
    val names = remember(categories) { listOf(Categories.ALL) + categories }
    val isTv = LocalIsTv.current
    // То же правило прокрутки стрелками, что и в меню плеера (линейная, без «ползущего» старта).
    val drawerSpec = remember { TvBringIntoViewSpec(anchor = 0.4f, durationMs = 90) }

    ModalDrawerSheet(
        modifier = Modifier.width(300.dp),
        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
        drawerContainerColor = Color(0xFF0C131B),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 24.dp),
        ) {
            // «Недавнее» визуально отделено от остальных категорий.
            Text(
                text = "Быстрый доступ",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
            Spacer(Modifier.height(12.dp))
            DrawerItem(
                text = Categories.RECENT,
                count = counts[Categories.RECENT],
                selected = Categories.RECENT == selected,
                focusable = open,
                accent = true,
                onClick = { onSelect(Categories.RECENT) },
                modifier = Modifier
                    .padding(horizontal = 4.dp)
                    .then(if (Categories.RECENT == selected) Modifier.focusRequester(focusRequester) else Modifier),
            )
            Spacer(Modifier.height(8.dp))
            DrawerItem(
                text = Categories.FAVORITES,
                count = counts[Categories.FAVORITES],
                selected = Categories.FAVORITES == selected,
                focusable = open,
                accent = true,
                onClick = { onSelect(Categories.FAVORITES) },
                modifier = Modifier.padding(horizontal = 4.dp),
            )
            Spacer(Modifier.height(16.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0x22FFFFFF)),
            )
            Spacer(Modifier.height(16.dp))
            Text(
                text = "Категории",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
            Spacer(Modifier.height(12.dp))

            CompositionLocalProvider(
                LocalBringIntoViewSpec provides (if (isTv) drawerSpec else LocalBringIntoViewSpec.current),
            ) {
            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(names, key = { it }) { name ->
                    DrawerItem(
                        text = name,
                        count = counts[name],
                        selected = name == selected,
                        focusable = open,
                        onClick = { onSelect(name) },
                        modifier = if (name == selected) {
                            Modifier.focusRequester(focusRequester)
                        } else {
                            Modifier
                        },
                    )
                }
            }
            }

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0x22FFFFFF)),
            )
            Spacer(Modifier.height(12.dp))

            DrawerItem(
                text = "Настройки",
                count = null,
                selected = false,
                focusable = open,
                onClick = onSettings,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
    }
}

@Composable
private fun DrawerItem(
    text: String,
    count: Int?,
    selected: Boolean,
    focusable: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    accent: Boolean = false,
) {
    val container = when {
        selected -> Color(0x3322D3FF)
        accent -> Color(0x1A22D3FF)
        else -> Color(0x0DFFFFFF)
    }
    FocusSurface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        containerColor = container,
        focusable = focusable,
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = text,
                modifier = Modifier.weight(1f),
                color = if (selected) Cyan else Color.White,
                fontSize = 17.sp,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
            )
            if (count != null) {
                Spacer(Modifier.width(8.dp))
                Text(
                    text = count.toString(),
                    color = if (selected) Cyan else MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium,
                )
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChannelList(
    channels: List<Channel>,
    listState: LazyListState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
    onRetryChannel: (Channel) -> Unit,
) {
    val isTv = LocalIsTv.current
    val focusRequester = remember { FocusRequester() }
    var focusDone by remember { mutableStateOf(false) }

    // Считаем один раз на изменение списка/ключа, а не на каждую рекомпозицию.
    val targetKey = remember(channels, focusKey) {
        focusKey?.takeIf { k -> channels.any { it.key == k && it.state != CheckState.UNKNOWN } }
            ?: channels.firstOrNull { it.state != CheckState.UNKNOWN }?.key
    }

    // На TV сразу ставим фокус: на первый канал или на тот, что смотрели последним.
    LaunchedEffect(isTv, channels.isNotEmpty()) {
        if (isTv && !focusDone && targetKey != null) {
            val index = channels.indexOfFirst { it.key == targetKey }
            if (index >= 0) {
                // Ждём первую раскладку, чтобы знать высоту области.
                val viewport = snapshotFlow { listState.layoutInfo.viewportSize.height }.first { it > 0 }
                val visible = listState.layoutInfo.visibleItemsInfo.any { it.index == index }
                // Прокручиваем только если канала нет на экране, сразу в «якорную» позицию.
                if (!visible) listState.scrollToItem(index, -(viewport * 0.3f).toInt())
                snapshotFlow { listState.layoutInfo.visibleItemsInfo.any { it.index == index } }.first { it }
                withFrameNanos { }
                runCatching { focusRequester.requestFocus() }
            }
            focusDone = true
        }
    }

    // На ТВ подменяем поведение bringIntoView (см. TvBringIntoViewSpec); на телефоне — стандартное.
    val listSpec = remember { TvBringIntoViewSpec(anchor = 0.3f, durationMs = 120) }
    CompositionLocalProvider(
        LocalBringIntoViewSpec provides (if (isTv) listSpec else LocalBringIntoViewSpec.current),
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                horizontal = if (isTv) 48.dp else 14.dp,
                vertical = if (isTv) 16.dp else 12.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(if (isTv) 10.dp else 8.dp),
        ) {
            // Стабильный key (уникальный ключ канала) + contentType: фокус и позиция переживают обновления списка.
            items(channels, key = { it.key }, contentType = { "channel" }) { channel ->
                ChannelItem(
                    channel = channel,
                    focusRequester = if (channel.key == targetKey) focusRequester else null,
                    onOpen = onOpen,
                    onRetryChannel = onRetryChannel,
                )
            }
        }
    }
}

/**
 * Одна строка списка со своим состоянием меню (долгое нажатие → «Повторить проверку»):
 * меню компонуется только у той строки, где оно открыто, и не заставляет пересобирать остальные.
 */
@Composable
private fun ChannelItem(
    channel: Channel,
    focusRequester: FocusRequester?,
    onOpen: (Channel) -> Unit,
    onRetryChannel: (Channel) -> Unit,
) {
    var menuOpen by remember { mutableStateOf(false) }
    val available = channel.state != CheckState.UNKNOWN
    Box {
        ChannelRow(
            channel = channel,
            onClick = { if (available) onOpen(channel) },
            enabled = available,
            onLongClick = if (available) ({ menuOpen = true }) else null,
            modifier = if (focusRequester != null) Modifier.focusRequester(focusRequester) else Modifier,
        )
        // Добавление и удаление избранного доступно только внутри плеера.
        if (menuOpen) {
            DropdownMenu(expanded = true, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Повторить проверку") },
                    onClick = {
                        menuOpen = false
                        onRetryChannel(channel)
                    },
                )
            }
        }
    }
}

@Composable
private fun ShimmerList() {
    val isTv = LocalIsTv.current
    // Постоянно движущийся градиент на ТВ нагружает GPU даже в ожидании данных.
    val brush = if (isTv) {
        Brush.linearGradient(listOf(Color(0xFF131C26), Color(0xFF1E2B39), Color(0xFF131C26)))
    } else {
        shimmerBrush()
    }
    val rowHeight = if (isTv) 76.dp else 64.dp

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        userScrollEnabled = false,
        contentPadding = PaddingValues(
            horizontal = if (isTv) 48.dp else 14.dp,
            vertical = if (isTv) 16.dp else 12.dp,
        ),
        verticalArrangement = Arrangement.spacedBy(if (isTv) 10.dp else 8.dp),
    ) {
        items(count = 12, contentType = { "shimmer" }) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(rowHeight)
                    .clip(RoundedCornerShape(14.dp))
                    .background(brush),
            )
        }
    }
}
