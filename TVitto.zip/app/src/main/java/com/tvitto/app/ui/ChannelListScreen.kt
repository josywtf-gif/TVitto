package com.tvitto.app.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import com.tvitto.app.data.Categories
import com.tvitto.app.data.Channel
import com.tvitto.app.data.Phase
import com.tvitto.app.data.UiState
import kotlinx.coroutines.delay

private enum class ListMode { Shimmer, Error, Empty, Grid }

/** Телефон 1–2 колонки, планшет 2–3, TV 4–6. */
private fun columnsFor(width: Dp, isTv: Boolean): Int = when {
    isTv -> (width / 190.dp).toInt().coerceIn(4, 6)
    width < 600.dp -> if (width >= 400.dp) 2 else 1
    else -> if (width >= 900.dp) 3 else 2
}

@Composable
fun ChannelListScreen(
    state: UiState,
    gridState: LazyGridState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
    onRetry: () -> Unit,
    onSelectCategory: (String) -> Unit,
) {
    val isTv = LocalIsTv.current

    // При смене категории список прокручивается вверх, а фокус остаётся на вкладке.
    var lastSelected by remember { mutableStateOf(state.selected) }
    LaunchedEffect(state.selected) {
        if (lastSelected != state.selected) {
            lastSelected = state.selected
            gridState.scrollToItem(0)
        }
    }

    val mode = when {
        state.phase == Phase.Error -> ListMode.Error
        state.phase == Phase.Loading -> ListMode.Shimmer
        state.channels.isNotEmpty() -> ListMode.Grid
        state.settled -> ListMode.Empty
        else -> ListMode.Shimmer
    }

    Column(Modifier.fillMaxSize()) {
        Header(state, isTv)
        if (state.categories.isNotEmpty()) {
            CategoryChips(state.categories, state.selected, isTv, onSelectCategory)
        }
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
        ) {
            Crossfade(targetState = mode, label = "listMode") { m ->
                when (m) {
                    ListMode.Shimmer -> ShimmerGrid()
                    ListMode.Error -> MessageState(
                        title = "Ошибка загрузки",
                        text = "Не удалось получить список каналов. Проверьте подключение к интернету.",
                        button = "Повторить",
                        onClick = onRetry,
                    )
                    ListMode.Empty -> MessageState(
                        title = "Нет доступных каналов",
                        text = "Сейчас ни один канал не отвечает. Попробуйте позже.",
                        button = "Повторить",
                        onClick = onRetry,
                    )
                    ListMode.Grid -> ChannelGrid(state.channels, gridState, focusKey, onOpen)
                }
            }
        }
    }
}

@Composable
private fun Header(state: UiState, isTv: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = if (isTv) 48.dp else 18.dp,
                vertical = if (isTv) 20.dp else 12.dp,
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White)) { append("TV") }
                withStyle(SpanStyle(color = Cyan)) { append("itto") }
            },
            fontSize = if (isTv) 34.sp else 26.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Spacer(Modifier.weight(1f))
        AnimatedVisibility(
            visible = state.checking,
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            CheckPill(state.checked, state.total)
        }
    }
}

/** Ненавязчивый индикатор фоновой проверки в углу. */
@Composable
private fun CheckPill(checked: Int, total: Int) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x22FFFFFF))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = Cyan,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "Проверка $checked/$total",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ChannelGrid(
    channels: List<Channel>,
    gridState: LazyGridState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
) {
    val isTv = LocalIsTv.current

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cols = columnsFor(maxWidth, isTv)
        val compact = cols == 1

        val focusRequester = remember { FocusRequester() }
        var focusDone by remember { mutableStateOf(false) }
        val targetKey = focusKey?.takeIf { k -> channels.any { it.key == k } }
            ?: channels.firstOrNull()?.key

        // На TV сразу ставим фокус: на первый канал или на тот, что смотрели последним.
        LaunchedEffect(isTv, channels.isNotEmpty()) {
            if (isTv && !focusDone && targetKey != null) {
                val index = channels.indexOfFirst { it.key == targetKey }
                if (index >= 0) gridState.scrollToItem(index)
                delay(120)
                runCatching { focusRequester.requestFocus() }
                focusDone = true
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                horizontal = if (isTv) 48.dp else 14.dp,
                vertical = 20.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(channels, key = { it.key }) { channel ->
                ChannelCard(
                    channel = channel,
                    compact = compact,
                    onClick = { onOpen(channel) },
                    modifier = if (channel.key == targetKey) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                )
            }
        }
    }
}

/** Вкладки категорий: на TV фокус D-pad, на телефоне тап. Выбор — по нажатию, фокус не прыгает. */
@Composable
private fun CategoryChips(
    categories: List<String>,
    selected: String,
    isTv: Boolean,
    onSelect: (String) -> Unit,
) {
    val names = remember(categories) { listOf(Categories.ALL) + categories }
    LazyRow(
        modifier = Modifier.fillMaxWidth(),
        contentPadding = PaddingValues(
            horizontal = if (isTv) 48.dp else 14.dp,
            vertical = 10.dp,
        ),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        items(names, key = { it }) { name ->
            val isSelected = name == selected
            FocusSurface(
                onClick = { onSelect(name) },
                shape = RoundedCornerShape(50),
                containerColor = if (isSelected) {
                    MaterialTheme.colorScheme.primary
                } else {
                    Color(0x33FFFFFF)
                },
            ) {
                Text(
                    text = name,
                    modifier = Modifier.padding(
                        horizontal = 18.dp,
                        vertical = if (isTv) 10.dp else 8.dp,
                    ),
                    color = if (isSelected) MaterialTheme.colorScheme.onPrimary else Color.White,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = if (isTv) 16.sp else 14.sp,
                )
            }
        }
    }
}

@Composable
private fun ShimmerGrid() {
    val isTv = LocalIsTv.current
    val brush = shimmerBrush()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cols = columnsFor(maxWidth, isTv)
        val compact = cols == 1

        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = false,
            contentPadding = PaddingValues(
                horizontal = if (isTv) 48.dp else 14.dp,
                vertical = 20.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(count = 12) {
                ShimmerCard(brush, compact)
            }
        }
    }
}

@Composable
private fun ShimmerCard(brush: Brush, compact: Boolean) {
    val shape = RoundedCornerShape(14.dp)
    if (compact) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .clip(shape)
                .background(brush),
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(MaterialTheme.colorScheme.surface),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f)
                    .background(brush),
            )
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .padding(horizontal = 12.dp)
                    .fillMaxWidth(0.6f)
                    .height(14.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(brush),
            )
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .padding(horizontal = 12.dp)
                    .fillMaxWidth(0.35f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(brush),
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}
