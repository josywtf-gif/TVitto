package com.tvitto.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyGridState
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.Text
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onPreviewKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvitto.app.data.Categories
import com.tvitto.app.data.Channel
import com.tvitto.app.data.Phase
import com.tvitto.app.data.UiState
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

private enum class ListMode { Shimmer, Error, Empty, Grid }

/** Телефон 1–2 колонки, планшет 2–3, TV 4–6. */
private fun columnsFor(width: Dp, isTv: Boolean): Int = when {
    isTv -> (width / 190.dp).toInt().coerceIn(4, 6)
    width < 600.dp -> if (width >= 400.dp) 2 else 1
    else -> if (width >= 900.dp) 3 else 2
}

@Composable
fun ChannelListScreen(
    state: UiState,
    gridState: LazyGridState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
    onRetry: () -> Unit,
    onSelectCategory: (String) -> Unit,
    onOpenSettings: () -> Unit,
) {
    val isTv = LocalIsTv.current
    val scope = rememberCoroutineScope()
    val drawerState = rememberDrawerState(DrawerValue.Closed)
    val drawerOpen = drawerState.targetValue == DrawerValue.Open

    val menuFocus = remember { FocusRequester() }
    val drawerFocus = remember { FocusRequester() }

    // Назад закрывает открытое меню.
    BackHandler(enabled = drawerState.isOpen) {
        scope.launch { drawerState.close() }
    }

    // TV: при открытии меню фокус на активной категории, при закрытии — на кнопку меню.
    var wasOpen by remember { mutableStateOf(false) }
    LaunchedEffect(drawerOpen) {
        if (isTv) {
            if (drawerOpen) {
                delay(120)
                runCatching { drawerFocus.requestFocus() }
            } else if (wasOpen) {
                delay(120)
                runCatching { menuFocus.requestFocus() }
            }
        }
        wasOpen = drawerOpen
    }

    // При смене категории список прокручивается вверх.
    var lastSelected by remember { mutableStateOf(state.selected) }
    LaunchedEffect(state.selected) {
        if (lastSelected != state.selected) {
            lastSelected = state.selected
            gridState.scrollToItem(0)
        }
    }

    val mode = when {
        state.phase == Phase.Error -> ListMode.Error
        state.phase == Phase.Loading -> ListMode.Shimmer
        state.channels.isNotEmpty() -> ListMode.Grid
        state.selected == Categories.RECENT && state.recentTotal == 0 -> ListMode.Empty
        state.settled -> ListMode.Empty
        else -> ListMode.Shimmer
    }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            CategoryDrawer(
                categories = state.categories,
                selected = state.selected,
                open = drawerOpen,
                focusRequester = drawerFocus,
                onSelect = { name ->
                    onSelectCategory(name)
                    scope.launch { drawerState.close() }
                },
                onSettings = {
                    scope.launch { drawerState.close() }
                    onOpenSettings()
                },
            )
        },
        modifier = Modifier.onPreviewKeyEvent { event ->
            // Кнопка «Меню» на пульте открывает/закрывает боковое меню.
            if (event.type == KeyEventType.KeyDown && event.key == Key.Menu) {
                scope.launch {
                    if (drawerState.isOpen) drawerState.close() else drawerState.open()
                }
                true
            } else {
                false
            }
        },
    ) {
        Column(Modifier.fillMaxSize()) {
            Header(
                state = state,
                isTv = isTv,
                menuFocus = menuFocus,
                onMenu = { scope.launch { drawerState.open() } },
            )
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
            ) {
                Crossfade(targetState = mode, label = "listMode") { m ->
                    when (m) {
                        ListMode.Shimmer -> ShimmerGrid()
                        ListMode.Error -> MessageState(
                            title = "Ошибка загрузки",
                            text = "Не удалось получить список каналов. Проверьте подключение к интернету.",
                            button = "Повторить",
                            onClick = onRetry,
                        )
                        ListMode.Empty -> if (state.selected == Categories.RECENT) {
                            MessageState(
                                title = "Нет недавних каналов",
                                text = "Здесь появятся последние 10 просмотренных каналов.",
                                button = "Все каналы",
                                onClick = { onSelectCategory(Categories.ALL) },
                            )
                        } else {
                            MessageState(
                                title = "Нет доступных каналов",
                                text = "Сейчас ни один канал не отвечает. Попробуйте позже.",
                                button = "Повторить",
                                onClick = onRetry,
                            )
                        }
                        ListMode.Grid -> ChannelGrid(state.channels, gridState, focusKey, onOpen)
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(
    state: UiState,
    isTv: Boolean,
    menuFocus: FocusRequester,
    onMenu: () -> Unit,
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(
                horizontal = if (isTv) 48.dp else 18.dp,
                vertical = if (isTv) 20.dp else 12.dp,
            ),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        MenuButton(
            onClick = onMenu,
            size = if (isTv) 52.dp else 44.dp,
            modifier = Modifier.focusRequester(menuFocus),
        )
        Spacer(Modifier.width(14.dp))
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = Color.White)) { append("TV") }
                withStyle(SpanStyle(color = Cyan)) { append("itto") }
            },
            fontSize = if (isTv) 34.sp else 26.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        if (state.selected != Categories.ALL) {
            Spacer(Modifier.width(12.dp))
            Text(
                text = state.selected,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = if (isTv) 20.sp else 16.sp,
                fontWeight = FontWeight.Medium,
            )
        }
        Spacer(Modifier.weight(1f))
        AnimatedVisibility(
            visible = state.checking,
            enter = fadeIn(),
            exit = fadeOut(),
        ) {
            CheckPill(state.checked, state.total)
        }
    }
}

/** Иконка-гамбургер. Фокусируется пультом, тапается пальцем. */
@Composable
private fun MenuButton(onClick: () -> Unit, size: Dp, modifier: Modifier = Modifier) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.size(size),
        shape = RoundedCornerShape(12.dp),
        containerColor = Color(0x22FFFFFF),
    ) {
        Column(
            modifier = Modifier.align(Alignment.Center),
            verticalArrangement = Arrangement.spacedBy(5.dp),
        ) {
            repeat(3) {
                Box(
                    Modifier
                        .width(20.dp)
                        .height(2.dp)
                        .background(Color.White, RoundedCornerShape(1.dp)),
                )
            }
        }
    }
}

/** Выдвижное меню категорий. Пока закрыто — пункты не получают фокус пульта. */
@Composable
private fun CategoryDrawer(
    categories: List<String>,
    selected: String,
    open: Boolean,
    focusRequester: FocusRequester,
    onSelect: (String) -> Unit,
    onSettings: () -> Unit,
) {
    // «Недавние» — в самом верху списка.
    val names = remember(categories) { listOf(Categories.RECENT, Categories.ALL) + categories }

    ModalDrawerSheet(
        modifier = Modifier.width(300.dp),
        drawerShape = RoundedCornerShape(topEnd = 28.dp, bottomEnd = 28.dp),
        drawerContainerColor = Color(0xFF0C131B),
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp, vertical = 24.dp),
        ) {
            Text(
                text = "Категории",
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.padding(horizontal = 8.dp),
            )
            Spacer(Modifier.height(12.dp))

            LazyColumn(
                modifier = Modifier.weight(1f),
                contentPadding = PaddingValues(vertical = 4.dp, horizontal = 4.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
            ) {
                items(names, key = { it }) { name ->
                    DrawerItem(
                        text = name,
                        selected = name == selected,
                        focusable = open,
                        onClick = { onSelect(name) },
                        modifier = if (name == selected) {
                            Modifier.focusRequester(focusRequester)
                        } else {
                            Modifier
                        },
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Box(
                Modifier
                    .fillMaxWidth()
                    .height(1.dp)
                    .background(Color(0x22FFFFFF)),
            )
            Spacer(Modifier.height(12.dp))

            DrawerItem(
                text = "Настройки",
                selected = false,
                focusable = open,
                onClick = onSettings,
                modifier = Modifier.padding(horizontal = 4.dp),
            )
        }
    }
}

@Composable
private fun DrawerItem(
    text: String,
    selected: Boolean,
    focusable: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        containerColor = if (selected) Color(0x3322D3FF) else Color(0x0DFFFFFF),
        focusable = focusable,
    ) {
        Text(
            text = text,
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 18.dp, vertical = 14.dp),
            color = if (selected) Cyan else Color.White,
            fontSize = 17.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
        )
    }
}

/** Ненавязчивый индикатор фоновой проверки в углу. */
@Composable
private fun CheckPill(checked: Int, total: Int) {
    Row(
        modifier = Modifier
            .clip(RoundedCornerShape(50))
            .background(Color(0x22FFFFFF))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        CircularProgressIndicator(
            modifier = Modifier.size(14.dp),
            strokeWidth = 2.dp,
            color = Cyan,
        )
        Spacer(Modifier.width(8.dp))
        Text(
            text = "Проверка $checked/$total",
            fontSize = 12.sp,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
    }
}

@Composable
private fun ChannelGrid(
    channels: List<Channel>,
    gridState: LazyGridState,
    focusKey: String?,
    onOpen: (Channel) -> Unit,
) {
    val isTv = LocalIsTv.current

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cols = columnsFor(maxWidth, isTv)
        val compact = cols == 1

        val focusRequester = remember { FocusRequester() }
        var focusDone by remember { mutableStateOf(false) }
        val targetKey = focusKey?.takeIf { k -> channels.any { it.key == k } }
            ?: channels.firstOrNull()?.key

        // На TV сразу ставим фокус: на первый канал или на тот, что смотрели последним.
        LaunchedEffect(isTv, channels.isNotEmpty()) {
            if (isTv && !focusDone && targetKey != null) {
                val index = channels.indexOfFirst { it.key == targetKey }
                if (index >= 0) gridState.scrollToItem(index)
                delay(120)
                runCatching { focusRequester.requestFocus() }
                focusDone = true
            }
        }

        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            state = gridState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(
                horizontal = if (isTv) 48.dp else 14.dp,
                vertical = 20.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(channels, key = { it.key }) { channel ->
                ChannelCard(
                    channel = channel,
                    compact = compact,
                    onClick = { onOpen(channel) },
                    modifier = if (channel.key == targetKey) {
                        Modifier.focusRequester(focusRequester)
                    } else {
                        Modifier
                    },
                )
            }
        }
    }
}

@Composable
private fun ShimmerGrid() {
    val isTv = LocalIsTv.current
    val brush = shimmerBrush()

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val cols = columnsFor(maxWidth, isTv)
        val compact = cols == 1

        LazyVerticalGrid(
            columns = GridCells.Fixed(cols),
            modifier = Modifier.fillMaxSize(),
            userScrollEnabled = false,
            contentPadding = PaddingValues(
                horizontal = if (isTv) 48.dp else 14.dp,
                vertical = 20.dp,
            ),
            horizontalArrangement = Arrangement.spacedBy(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            items(count = 12) {
                ShimmerCard(brush, compact)
            }
        }
    }
}

@Composable
private fun ShimmerCard(brush: Brush, compact: Boolean) {
    val shape = RoundedCornerShape(14.dp)
    if (compact) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(72.dp)
                .clip(shape)
                .background(brush),
        )
    } else {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .clip(shape)
                .background(MaterialTheme.colorScheme.surface),
        ) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .aspectRatio(16f / 10f)
                    .background(brush),
            )
            Spacer(Modifier.height(10.dp))
            Box(
                modifier = Modifier
                    .padding(horizontal = 12.dp)
                    .fillMaxWidth(0.6f)
                    .height(14.dp)
                    .clip(RoundedCornerShape(7.dp))
                    .background(brush),
            )
            Spacer(Modifier.height(8.dp))
            Box(
                modifier = Modifier
                    .padding(horizontal = 12.dp)
                    .fillMaxWidth(0.35f)
                    .height(10.dp)
                    .clip(RoundedCornerShape(5.dp))
                    .background(brush),
            )
            Spacer(Modifier.height(12.dp))
        }
    }
}
