package com.tvitto.app.ui

import androidx.compose.animation.core.AnimationSpec
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.BringIntoViewSpec
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithCache
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusProperties
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawOutline
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import kotlinx.coroutines.delay

/**
 * Кликабельная поверхность с явным фокусом для пульта:
 * небольшой масштаб ([focusScale]), голубая обводка с плавной анимацией.
 * На телефоне фокус не появляется — работает обычный тап.
 */
@Composable
fun FocusSurface(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    shape: Shape = RoundedCornerShape(14.dp),
    containerColor: Color = MaterialTheme.colorScheme.surface,
    focusable: Boolean = true,
    enabled: Boolean = true,
    onLongClick: (() -> Unit)? = null,
    focusScale: Float = 1.08f,
    content: @Composable BoxScope.() -> Unit,
) {
    var focused by remember { mutableStateOf(false) }
    // Один прогресс 0..1 на всё (масштаб + обводка). Он читается ТОЛЬКО в фазах layer/draw,
    // поэтому анимация фокуса не вызывает рекомпозицию элемента на каждом кадре.
    val progress by animateFloatAsState(
        targetValue = if (focused) 1f else 0f,
        animationSpec = tween(120),
        label = "focus",
    )

    Box(
        modifier = modifier
            .zIndex(if (focused) 1f else 0f)
            .graphicsLayer {
                val scale = 1f + (focusScale - 1f) * progress
                scaleX = scale
                scaleY = scale
                clip = false
            }
            .focusProperties { this.canFocus = focusable && enabled }
            .onFocusChanged { focused = it.isFocused }
            .clip(shape)
            .background(containerColor)
            .combinedClickable(enabled = enabled, onClick = onClick, onLongClick = onLongClick)
            // Обводка рисуется поверх содержимого и только в фазе draw: раньше Modifier.border
            // читал progress в композиции, и каждый кадр анимации пересобирал элемент.
            .drawWithCache {
                val outline = shape.createOutline(size, layoutDirection, this)
                // Ширина вдвое больше видимой: внешняя половина обрезается clip(shape).
                val stroke = Stroke(width = 4.dp.toPx())
                onDrawWithContent {
                    drawContent()
                    val p = progress
                    if (p > 0f) drawOutline(outline, color = Cyan, alpha = p, style = stroke)
                }
            },
        content = content,
    )
}

@Composable
fun TvButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    focusable: Boolean = true,
    primary: Boolean = false,
) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(50),
        containerColor = if (primary) MaterialTheme.colorScheme.primary else Color(0x33FFFFFF),
        focusable = focusable,
    ) {
        Text(
            text = text,
            modifier = Modifier.padding(horizontal = 22.dp, vertical = 12.dp),
            color = if (primary) MaterialTheme.colorScheme.onPrimary else Color.White,
            fontWeight = FontWeight.SemiBold,
            fontSize = 16.sp,
        )
    }
}

@Composable
fun shimmerBrush(): Brush {
    val transition = rememberInfiniteTransition(label = "shimmer")
    val x by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1300, easing = LinearEasing)),
        label = "shimmerX",
    )
    val base = Color(0xFF131C26)
    val light = Color(0xFF1E2B39)
    return Brush.linearGradient(
        colors = listOf(base, light, base),
        start = Offset(x * 1400f - 500f, 0f),
        end = Offset(x * 1400f, 360f),
    )
}

@Composable
fun MessageState(
    title: String,
    text: String,
    button: String,
    onClick: () -> Unit,
) {
    val isTv = LocalIsTv.current
    val focusRequester = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        if (isTv) {
            delay(150)
            runCatching { focusRequester.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.headlineSmall,
            color = Color.White,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(10.dp))
        Text(
            text = text,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
        Spacer(Modifier.height(24.dp))
        TvButton(
            text = button,
            onClick = onClick,
            modifier = Modifier.focusRequester(focusRequester),
            primary = true,
        )
    }
}

/**
 * ТВ: прокрутка при смене фокуса стрелками. Стандартная пружина перезапускается на каждом нажатии
 * (особенно при удержании) — отсюда «рывки». Здесь элемент с фокусом выравнивается по якорю
 * ([anchor] — доля высоты области) короткой tween-анимацией: каждое ↑/↓ = ровно один шаг на элемент,
 * а если элемент уже на якоре, прокрутки нет вовсе.
 *
 * ВАЖНО: easing линейный. У FastOutSlowIn старт почти нулевой скорости, а при удержании стрелки
 * анимация перезапускается на каждом нажатии (раньше, чем успевает разогнаться) — список «ползёт»
 * очень медленно, а после отпускания кнопки доезжает рывком. Линейная анимация держит постоянную
 * скорость при любых перезапусках.
 *
 * МЁРТВАЯ ЗОНА ([deadZone], доля высоты элемента). Карточка при фокусе увеличивается на 8%
 * (graphicsLayer scale в [FocusSurface]). Compose пересчитывает границы сфокусированного элемента
 * на каждом кадре анимации, поэтому его верхняя граница и «якорь» смещаются на 10–20 px, и без мёртвой
 * зоны список подруливал на эти пиксели вверх-вниз — «дёргался» при ←/→ внутри одной строки.
 * Реальный переход на соседнюю строку сдвигает элемент минимум на высоту карточки + отступ,
 * что заметно больше [deadZone], поэтому вертикальная навигация работает как раньше.
 */
@OptIn(ExperimentalFoundationApi::class)
class TvBringIntoViewSpec(
    private val anchor: Float,
    durationMs: Int,
    private val deadZone: Float = 0.2f,
) : BringIntoViewSpec {
    override val scrollAnimationSpec: AnimationSpec<Float> =
        tween(durationMillis = durationMs, easing = LinearEasing)

    override fun calculateScrollDistance(offset: Float, size: Float, containerSize: Float): Float {
        val anchorTop = ((containerSize - size) * anchor).coerceAtLeast(0f)
        val delta = offset - anchorTop
        // Элемент уже (почти) на якоре — не трогаем список.
        return if (kotlin.math.abs(delta) < maxOf(1f, size * deadZone)) 0f else delta
    }
}
