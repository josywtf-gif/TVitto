package com.tvitto.app.data

import java.io.BufferedInputStream
import java.io.Closeable
import java.io.IOException
import java.io.InputStream
import java.net.Inet4Address
import java.net.NetworkInterface
import java.net.ServerSocket
import java.net.Socket
import java.util.Collections
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * Крошечный HTTP-сервер для ТВ: отдаёт страницу с полем «Добавить плейлист» и принимает POST /add.
 * Работает только пока открыт экран добавления плейлиста; без внешних зависимостей.
 *
 * Защита: принимаются только POST с заголовком X-TVitto (браузер не отправит его с чужой страницы
 * без CORS-preflight, на который сервер не отвечает), размер тела ограничен.
 */
class PlaylistServer(
    /** Вызывается на потоке сервера (не на главном). Возвращает ответ для страницы. */
    private val handler: (String) -> Reply,
) : Closeable {

    data class Reply(val ok: Boolean, val message: String)

    @Volatile
    private var socket: ServerSocket? = null
    private var pool: ExecutorService? = null
    private val submitLock = Any()

    /** Запускает сервер и возвращает порт. Бросает IOException, если не удалось занять порт. */
    @Synchronized
    fun start(): Int {
        socket?.let { return it.localPort }
        val ss = bind()
        val executor = Executors.newCachedThreadPool { r -> Thread(r, "tvitto-http-worker").apply { isDaemon = true } }
        socket = ss
        pool = executor
        Thread({
            while (!ss.isClosed) {
                try {
                    val client = ss.accept()
                    executor.execute { handle(client) }
                } catch (e: IOException) {
                    if (ss.isClosed) break
                } catch (e: RuntimeException) {
                    if (ss.isClosed) break
                }
            }
        }, "tvitto-http-accept").apply { isDaemon = true }.start()
        return ss.localPort
    }

    @Synchronized
    override fun close() {
        try {
            socket?.close()
        } catch (e: IOException) {
            // ignore
        }
        socket = null
        pool?.shutdownNow()
        pool = null
    }

    private fun bind(): ServerSocket {
        for (port in PREFERRED_PORTS) {
            try {
                return ServerSocket(port)
            } catch (e: IOException) {
                // порт занят — пробуем следующий
            }
        }
        return ServerSocket(0)
    }

    // ---------- обработка запроса ----------

    private fun handle(client: Socket) {
        try {
            client.soTimeout = READ_TIMEOUT_MS
            val input = BufferedInputStream(client.getInputStream())
            val output = client.getOutputStream()

            val requestLine = readLine(input) ?: return
            val parts = requestLine.split(' ')
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val path = parts[1].substringBefore('?')

            val headers = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: return
                if (line.isEmpty()) break
                val idx = line.indexOf(':')
                if (idx > 0) headers[line.substring(0, idx).trim().lowercase()] = line.substring(idx + 1).trim()
                if (headers.size > 64) return
            }

            when {
                method == "GET" && (path == "/" || path == "/index.html") ->
                    respond(output, 200, "text/html; charset=utf-8", PAGE.toByteArray(Charsets.UTF_8))

                method == "POST" && path == "/add" -> {
                    if (headers["x-tvitto"] != "1") {
                        respond(output, 403, "application/json; charset=utf-8", json(false, "Запрещено"))
                        return
                    }
                    val length = headers["content-length"]?.toLongOrNull()
                    if (length == null || length < 0) {
                        respond(output, 411, "application/json; charset=utf-8", json(false, "Нет длины данных"))
                        return
                    }
                    if (length > MAX_BODY) {
                        respond(output, 413, "application/json; charset=utf-8", json(false, "Слишком большой плейлист"))
                        return
                    }
                    val body = readBody(input, length.toInt())
                    val reply = synchronized(submitLock) {
                        try {
                            handler(String(body, Charsets.UTF_8))
                        } catch (e: Exception) {
                            Reply(false, "Не удалось добавить плейлист")
                        }
                    }
                    respond(output, 200, "application/json; charset=utf-8", json(reply.ok, reply.message))
                }

                method == "GET" && path == "/favicon.ico" -> respond(output, 204, "text/plain", ByteArray(0))

                else -> respond(output, 404, "text/plain; charset=utf-8", "Not found".toByteArray())
            }
        } catch (e: Exception) {
            // оборванное соединение / таймаут — просто закрываем
        } finally {
            try {
                client.close()
            } catch (e: IOException) {
                // ignore
            }
        }
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) break
            if (b != '\r'.code) sb.append(b.toChar())
            if (sb.length > MAX_LINE) return null
        }
        return sb.toString()
    }

    private fun readBody(input: InputStream, length: Int): ByteArray {
        val buf = ByteArray(length)
        var read = 0
        while (read < length) {
            val n = input.read(buf, read, length - read)
            if (n < 0) throw IOException("unexpected end of body")
            read += n
        }
        return buf
    }

    private fun respond(out: java.io.OutputStream, code: Int, type: String, body: ByteArray) {
        val status = when (code) {
            200 -> "OK"
            204 -> "No Content"
            403 -> "Forbidden"
            404 -> "Not Found"
            411 -> "Length Required"
            413 -> "Payload Too Large"
            else -> "Error"
        }
        val head = "HTTP/1.1 $code $status\r\n" +
            "Content-Type: $type\r\n" +
            "Content-Length: ${body.size}\r\n" +
            "Cache-Control: no-store\r\n" +
            "Connection: close\r\n\r\n"
        out.write(head.toByteArray(Charsets.US_ASCII))
        out.write(body)
        out.flush()
    }

    private fun json(ok: Boolean, message: String): ByteArray {
        val escaped = buildString {
            for (c in message) {
                when (c) {
                    '"' -> append("\\\"")
                    '\\' -> append("\\\\")
                    '\n' -> append("\\n")
                    '\r' -> Unit
                    else -> append(c)
                }
            }
        }
        return "{\"ok\":$ok,\"message\":\"$escaped\"}".toByteArray(Charsets.UTF_8)
    }

    private companion object {
        val PREFERRED_PORTS = intArrayOf(8088, 8089, 8090, 8888)
        const val READ_TIMEOUT_MS = 15_000
        const val MAX_LINE = 8 * 1024
        const val MAX_BODY = 20L * 1024 * 1024

        // Без символа доллара в JS: страница лежит в строке Kotlin.
        val PAGE = """
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>TVitto — добавить плейлист</title>
<style>
  :root { color-scheme: dark; }
  body { margin:0; padding:20px; background:#05080d; color:#e8f1fa; font:16px/1.4 system-ui,sans-serif; }
  h1 { font-size:22px; margin:0 0 4px; } h1 span { color:#22d3ff; }
  p { color:#9fb3c8; margin:6px 0 16px; }
  label { display:block; font-weight:600; margin-bottom:8px; }
  textarea { width:100%; box-sizing:border-box; min-height:220px; padding:12px; border-radius:12px;
             border:1px solid #2a3a4c; background:#101720; color:#e8f1fa; font:14px/1.4 monospace; }
  button { margin-top:14px; width:100%; padding:14px; border:0; border-radius:12px;
           background:#22d3ff; color:#00131f; font-size:17px; font-weight:700; }
  button:disabled { opacity:.5; }
  #status { margin-top:14px; min-height:24px; font-weight:600; }
  .ok { color:#5be37d; } .err { color:#ff6b6b; }
</style>
</head>
<body>
<h1>TV<span>itto</span></h1>
<p>Вставьте ссылку на плейлист (.m3u) или его содержимое. Плейлист сохранится на телевизоре и сразу применится.</p>
<label for="pl">Добавить плейлист</label>
<textarea id="pl" placeholder="https://example.com/list.m3u  или  #EXTM3U ..." autocomplete="off" autocapitalize="off" spellcheck="false"></textarea>
<button id="send">Добавить</button>
<div id="status"></div>
<script>
  var btn = document.getElementById('send');
  var box = document.getElementById('pl');
  var st = document.getElementById('status');
  btn.onclick = function () {
    var v = box.value.trim();
    if (!v) { st.className = 'err'; st.textContent = 'Введите ссылку или содержимое плейлиста'; return; }
    btn.disabled = true; st.className = ''; st.textContent = 'Отправляем…';
    fetch('/add', { method: 'POST', headers: { 'Content-Type': 'text/plain;charset=utf-8', 'X-TVitto': '1' }, body: v })
      .then(function (r) { return r.json(); })
      .then(function (j) { st.className = j.ok ? 'ok' : 'err'; st.textContent = j.message; if (j.ok) box.value = ''; })
      .catch(function () { st.className = 'err'; st.textContent = 'Нет связи с телевизором'; })
      .then(function () { btn.disabled = false; });
  };
</script>
</body>
</html>
""".trimIndent()
    }
}

/** Локальный IPv4-адрес устройства в домашней сети (Wi-Fi / Ethernet), либо null. */
object LocalNet {
    fun localIpv4(): String? {
        return try {
            var best: String? = null
            var bestScore = Int.MAX_VALUE
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return null
            for (ni in Collections.list(interfaces)) {
                if (!ni.isUp || ni.isLoopback) continue
                val name = ni.name.lowercase()
                val score = if (name.startsWith("wlan") || name.startsWith("eth")) 0 else 1
                for (addr in Collections.list(ni.inetAddresses)) {
                    if (addr is Inet4Address && !addr.isLoopbackAddress && addr.isSiteLocalAddress) {
                        val host = addr.hostAddress ?: continue
                        if (score < bestScore) {
                            best = host
                            bestScore = score
                        }
                    }
                }
            }
            best
        } catch (e: Exception) {
            null
        }
    }
}
