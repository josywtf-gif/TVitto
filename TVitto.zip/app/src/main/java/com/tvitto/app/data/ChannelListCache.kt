package com.tvitto.app.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/**
 * Кэш списка каналов (после объединения плейлистов) в файле.
 * Вместе с [CheckCache] позволяет показать рабочие каналы сразу при запуске, без сети.
 */
class ChannelListCache(context: Context) {

    private val dir = context.applicationContext.filesDir
    private val file = File(dir, "channels_cache_v1.json")

    suspend fun load(): List<Channel> = withContext(Dispatchers.IO) {
        try {
            if (!file.exists()) return@withContext emptyList()
            val arr = JSONArray(file.readText())
            val out = ArrayList<Channel>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val streamsJson = o.getJSONArray("s")
                val streams = ArrayList<StreamSource>(streamsJson.length())
                for (j in 0 until streamsJson.length()) {
                    val s = streamsJson.getJSONObject(j)
                    streams.add(
                        StreamSource(
                            url = s.getString("u"),
                            referrer = s.optString("r").ifEmpty { null },
                            userAgent = s.optString("a").ifEmpty { null },
                        ),
                    )
                }
                if (streams.isEmpty()) continue
                out.add(
                    Channel(
                        key = o.getString("k"),
                        name = o.getString("n"),
                        logo = o.optString("l").ifEmpty { null },
                        group = o.optString("g").ifEmpty { null },
                        category = o.getString("c"),
                        streams = streams,
                    ),
                )
            }
            out
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
    }

    suspend fun save(list: List<Channel>) = withContext(Dispatchers.IO) {
        try {
            val arr = JSONArray()
            for (ch in list) {
                val streams = JSONArray()
                for (s in ch.streams) {
                    streams.put(
                        JSONObject().apply {
                            put("u", s.url)
                            s.referrer?.let { put("r", it) }
                            s.userAgent?.let { put("a", it) }
                        },
                    )
                }
                arr.put(
                    JSONObject().apply {
                        put("k", ch.key)
                        put("n", ch.name)
                        ch.logo?.let { put("l", it) }
                        ch.group?.let { put("g", it) }
                        put("c", ch.category)
                        put("s", streams)
                    },
                )
            }
            // Пишем во временный файл и переименовываем — кэш не остаётся «рваным».
            val tmp = File(dir, file.name + ".tmp")
            tmp.writeText(arr.toString())
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // кэш — best effort
        }
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        try {
            file.delete()
        } catch (e: Exception) {
            // ignore
        }
    }
}
