package com.tvitto.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.DialogProperties
import com.tvitto.app.BuildConfig
import com.tvitto.app.update.ReleaseInfo
import com.tvitto.app.update.UpdateCheck
import com.tvitto.app.update.Updater
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.io.File

private sealed interface UpdateUi {
    data object Idle : UpdateUi
    data object Checking : UpdateUi
    data class Available(val release: ReleaseInfo) : UpdateUi
    data class Downloading(val release: ReleaseInfo, val progress: Float) : UpdateUi
    data class NeedPermission(val file: File) : UpdateUi
}

@Composable
fun SettingsScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val isTv = LocalIsTv.current
    val scope = rememberCoroutineScope()

    var ui by remember { mutableStateOf<UpdateUi>(UpdateUi.Idle) }
    var status by remember { mutableStateOf<String?>(null) }
    var downloadJob by remember { mutableStateOf<Job?>(null) }
    val checkFocus = remember { FocusRequester() }

    BackHandler {
        downloadJob?.cancel()
        onBack()
    }

    LaunchedEffect(Unit) {
        if (isTv) {
            delay(150)
            runCatching { checkFocus.requestFocus() }
        }
    }

    fun tryInstall(file: File) {
        if (!Updater.canInstall(context)) {
            Updater.openInstallSettings(context)
            ui = UpdateUi.NeedPermission(file)
            return
        }
        try {
            Updater.install(context, file)
            ui = UpdateUi.Idle
            status = "Установка запущена"
        } catch (e: Exception) {
            ui = UpdateUi.Idle
            status = "Не удалось запустить установку"
        }
    }

    fun startDownload(release: ReleaseInfo) {
        ui = UpdateUi.Downloading(release, 0f)
        downloadJob = scope.launch {
            try {
                val file = Updater.download(context, release) { p ->
                    if (ui is UpdateUi.Downloading) ui = UpdateUi.Downloading(release, p)
                }
                tryInstall(file)
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ui = UpdateUi.Idle
                status = "Не удалось скачать обновление"
            }
        }
    }

    fun cancelDownload() {
        downloadJob?.cancel()
        ui = UpdateUi.Idle
    }

    fun checkForUpdates() {
        if (ui is UpdateUi.Checking || ui is UpdateUi.Downloading) return
        status = null
        ui = UpdateUi.Checking
        scope.launch {
            when (val result = Updater.check()) {
                UpdateCheck.UpToDate -> {
                    status = "У вас последняя версия"
                    ui = UpdateUi.Idle
                }
                UpdateCheck.Failed -> {
                    status = "Не удалось проверить обновления"
                    ui = UpdateUi.Idle
                }
                is UpdateCheck.Available -> ui = UpdateUi.Available(result.release)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = if (isTv) 48.dp else 20.dp, vertical = 20.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            TvButton(
                text = "← Назад",
                onClick = {
                    downloadJob?.cancel()
                    onBack()
                },
            )
            Spacer(Modifier.width(18.dp))
            Text(
                text = "Настройки",
                color = Color.White,
                fontSize = if (isTv) 30.sp else 24.sp,
                fontWeight = FontWeight.ExtraBold,
            )
        }

        Spacer(Modifier.height(32.dp))

        Text(
            text = "TVitto · версия ${BuildConfig.VERSION_NAME}",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 16.sp,
        )
        Spacer(Modifier.height(16.dp))

        TvButton(
            text = if (ui is UpdateUi.Checking) "Проверка…" else "Проверить обновления",
            onClick = { checkForUpdates() },
            modifier = Modifier.focusRequester(checkFocus),
            primary = true,
        )

        status?.let {
            Spacer(Modifier.height(14.dp))
            Text(text = it, color = Color.White, fontSize = 16.sp)
        }
    }

    when (val state = ui) {
        is UpdateUi.Available -> UpdateDialog(
            title = "Доступно обновление v${state.release.version}",
            text = "Скачать и установить новую версию?",
            confirm = "Обновить",
            onConfirm = { startDownload(state.release) },
            dismiss = "Отмена",
            onDismiss = { ui = UpdateUi.Idle },
        )

        is UpdateUi.Downloading -> UpdateDialog(
            title = "Загрузка обновления",
            text = "v${state.release.version}",
            confirm = null,
            onConfirm = {},
            dismiss = "Отмена",
            onDismiss = { cancelDownload() },
            cancelable = false,
            extra = {
                Spacer(Modifier.height(16.dp))
                if (state.progress < 0f) {
                    LinearProgressIndicator(color = Cyan)
                } else {
                    LinearProgressIndicator(progress = { state.progress }, color = Cyan)
                    Spacer(Modifier.height(8.dp))
                    Text("${(state.progress * 100).toInt()}%", color = Color.White)
                }
            },
        )

        is UpdateUi.NeedPermission -> UpdateDialog(
            title = "Нужно разрешение",
            text = "Разрешите TVitto устанавливать приложения в настройках, затем нажмите «Установить».",
            confirm = "Установить",
            onConfirm = { tryInstall(state.file) },
            dismiss = "Отмена",
            onDismiss = { ui = UpdateUi.Idle },
        )

        UpdateUi.Idle, UpdateUi.Checking -> Unit
    }
}

@Composable
private fun UpdateDialog(
    title: String,
    text: String,
    confirm: String?,
    onConfirm: () -> Unit,
    dismiss: String,
    onDismiss: () -> Unit,
    cancelable: Boolean = true,
    extra: @Composable () -> Unit = {},
) {
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { focus.requestFocus() }
    }

    AlertDialog(
        onDismissRequest = { if (cancelable) onDismiss() },
        properties = DialogProperties(
            dismissOnBackPress = cancelable,
            dismissOnClickOutside = cancelable,
        ),
        containerColor = Color(0xFF101720),
        titleContentColor = Color.White,
        textContentColor = MaterialTheme.colorScheme.onSurfaceVariant,
        title = { Text(title, fontWeight = FontWeight.Bold) },
        text = {
            Column {
                Text(text)
                extra()
            }
        },
        confirmButton = {
            if (confirm != null) {
                TvButton(
                    text = confirm,
                    onClick = onConfirm,
                    modifier = Modifier.focusRequester(focus),
                    primary = true,
                )
            }
        },
        dismissButton = {
            TvButton(
                text = dismiss,
                onClick = onDismiss,
                modifier = if (confirm == null) Modifier.focusRequester(focus) else Modifier,
            )
        },
    )
}
