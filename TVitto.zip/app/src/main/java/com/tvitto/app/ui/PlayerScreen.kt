package com.tvitto.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.provider.Settings
import android.view.LayoutInflater
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.LocalBringIntoViewSpec
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.tvitto.app.Config
import com.tvitto.app.R
import com.tvitto.app.data.Channel
import com.tvitto.app.data.PlaybackEvent
import com.tvitto.app.data.StreamRatingStore
import com.tvitto.app.data.buildMediaSource
import com.tvitto.app.playback.PlaybackEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * Снимок списка каналов на момент открытия плеера (на время просмотра он не меняется):
 * каналы той категории, из которой запущен плеер, и её название.
 */
@Immutable
class PlaySession(val channels: List<Channel>, val startKey: String, val title: String)

/** Сколько показывать overlay с названием после переключения канала. */
private const val ZAP_OVERLAY_MS = 2500L

/** Обычное время показа overlay (по тапу/OK). */
private const val DEFAULT_OVERLAY_MS = 4000L

/** Минимальный свайп по горизонтали для переключения канала, px. */
private const val SWIPE_THRESHOLD_PX = 120f

/**
 * Пауза после последнего переключения канала, прежде чем реально запускать поток.
 * Пока пользователь листает (в т.ч. удерживает стрелку), поток не пересоздаётся на каждом шаге:
 * стартует только тот канал, на котором остановились.
 */
private const val ZAP_SETTLE_MS = 280L

/** Затемнение видео на ТВ при ↑/↓: сила (0..1) и длительность плавного перехода. */
private const val DIM_ALPHA = 0.6f
private const val DIM_ANIM_MS = 350

/** Затемнять ли видео и пока открыто боковое меню каналов (только ТВ). */
private const val DIM_WHEN_MENU_OPEN = true

/**
 * Запасной вариант, если на конкретной приставке SurfaceView не даёт корректно наложить
 * полупрозрачный слой поверх видео: PlayerView на TextureView (см. res/layout/player_view_texture.xml).
 * По умолчанию выключено: SurfaceView быстрее и экономнее по GPU.
 */
private const val USE_TEXTURE_VIEW = false

@Composable
fun PlayerScreen(
    session: PlaySession,
    onEvent: (PlaybackEvent) -> Unit,
    onChannelOpened: (Channel) -> Unit,
    onExit: (lastKey: String) -> Unit,
) {
    val context = LocalContext.current
    val view = LocalView.current
    val isTv = LocalIsTv.current
    val gesturePrefs = remember { context.getSharedPreferences("gesture_settings", Context.MODE_PRIVATE) }
    val brightnessGestureEnabled = remember { mutableStateOf(gesturePrefs.getBoolean("brightness_left", true)) }
    val volumeGestureEnabled = remember { mutableStateOf(gesturePrefs.getBoolean("volume_right", true)) }
    val playerPrefs = remember { context.getSharedPreferences("player_settings", Context.MODE_PRIVATE) }
    var stretchImage by remember { mutableStateOf(playerPrefs.getBoolean("stretch_fullscreen", false)) }
    val lifecycleOwner = LocalLifecycleOwner.current
    val channels = session.channels
    val latestEvent by rememberUpdatedState(onEvent)
    val latestOpened by rememberUpdatedState(onChannelOpened)

    var index by remember {
        mutableIntStateOf(channels.indexOfFirst { it.key == session.startKey }.coerceAtLeast(0))
    }
    var attempt by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(true) }
    var ready by remember { mutableStateOf(false) }
    var failedNow by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(true) }
    var menuOpen by remember { mutableStateOf(false) }
    // ТВ: overlay показан именно по ↑/↓ — только в этом случае видео затемняется (при ←/→ нет).
    var dimRequested by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    var hideAfterMs by remember { mutableStateOf(DEFAULT_OVERLAY_MS) }
    var adjustmentType by remember { mutableStateOf<String?>(null) }
    var adjustmentValue by remember { mutableStateOf(0f) }
    var adjustmentTick by remember { mutableIntStateOf(0) }

    val channel = channels[index]

    fun showOverlay(durationMs: Long = DEFAULT_OVERLAY_MS) {
        hideAfterMs = durationMs
        overlay = true
        tick++
    }

    fun exit() {
        onExit(channels[index].key)
    }

    /** Порядок потоков с учётом накопленной статистики качества. */
    val streamOrder = remember(index, channel.streams, channel.active) {
        StreamRatingStore.rankedIndices(context, channel)
    }

    /** Индекс потока канала, который сейчас пробуем (индекс в исходном списке). */
    fun streamIndex(): Int = streamOrder.getOrElse(attempt) { channel.active.coerceIn(channel.streams.indices) }

    var currentStream by remember { mutableStateOf<com.tvitto.app.data.StreamSource?>(null) }
    var playingSince by remember { mutableStateOf(0L) }
    var bufferingSince by remember { mutableStateOf(0L) }

    fun flushPlaybackSegment() {
        val now = android.os.SystemClock.elapsedRealtime()
        currentStream?.let { stream ->
            if (playingSince > 0L) StreamRatingStore.addPlayback(context, stream, now - playingSince)
            if (bufferingSince > 0L) StreamRatingStore.addBuffering(context, stream, now - bufferingSince)
        }
        playingSince = 0L
        bufferingSince = 0L
    }

    /** Переключение на канал по индексу без выхода из плеера. */
    fun switchTo(target: Int) {
        if (target in channels.indices && target != index) {
            index = target
            attempt = 0
            failedNow = false
            buffering = true
        }
        showOverlay(ZAP_OVERLAY_MS)
    }

    /**
     * Переключение по текущему списку (та же категория и порядок, что в списке).
     * Список НЕ зацикливается: на первом/последнем канале переключение за границу
     * ничего не меняет, только показывает overlay.
     */
    fun zap(delta: Int) = switchTo(index + delta)

    /** Поток не стартовал/упал: пробуем следующий поток этого же канала, иначе сообщаем об ошибке. */
    fun streamFailed(timeout: Boolean) {
        currentStream?.let { StreamRatingStore.addFailure(context, it) }
        flushPlaybackSegment()
        val total = channels[index].streams.size
        if (attempt + 1 < total) {
            attempt += 1
        } else {
            failedNow = true
            buffering = false
            val key = channels[index].key
            latestEvent(if (timeout) PlaybackEvent.Timeout(key) else PlaybackEvent.Failed(key))
        }
    }

    /** Для какого канала/попытки реально запущен поток в плеере: [index, attempt]. */
    val started = remember { intArrayOf(-1, -1) }
    var currentStreamIndex by remember { mutableIntStateOf(-1) }
    val failLatest by rememberUpdatedState<(Boolean) -> Unit>({ timeout -> streamFailed(timeout) })
    val currentSelection by rememberUpdatedState(index to attempt)

    // Player принадлежит только экрану просмотра; фонового сервиса нет.
    val exo = remember { PlaybackEngine.get(context) }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                val isBuffering = playbackState == Player.STATE_BUFFERING
                val now = android.os.SystemClock.elapsedRealtime()
                if (isBuffering) {
                    if (playingSince > 0L) {
                        currentStream?.let { StreamRatingStore.addPlayback(context, it, now - playingSince) }
                        playingSince = 0L
                    }
                    if (bufferingSince == 0L) bufferingSince = now
                } else if (playbackState == Player.STATE_READY) {
                    if (bufferingSince > 0L) {
                        currentStream?.let { StreamRatingStore.addBuffering(context, it, now - bufferingSince) }
                        bufferingSince = 0L
                    }
                    if (playingSince == 0L) playingSince = now
                }
                buffering = isBuffering
                latestEvent(PlaybackEvent.Buffering(isBuffering))
                if (playbackState == Player.STATE_READY) {
                    // Игнорируем запоздалый READY предыдущего канала: поток ещё не перезапущен под текущий index/attempt.
                    val activeChannel = channels.getOrNull(started[0])
                    if (activeChannel != null && started[0] == currentSelection.first &&
                        started[1] == currentSelection.second && started[1] >= 0) {
                        ready = true
                        failedNow = false
                        latestEvent(PlaybackEvent.Ready(activeChannel.key, currentStreamIndex))
                    }
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                // Ошибка старого потока, пока уже выбран другой канал, не должна сжигать попытки нового.
                if (started[0] != currentSelection.first || started[1] != currentSelection.second) return
                failLatest(false)
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            flushPlaybackSegment()
        }
    }

    // Запуск потока при смене канала или повторной попытке.
    //  • Пока пользователь листает, эффект перезапускается и отменяет предыдущую паузу —
    //    поток создаётся один раз, для канала, на котором остановились (нет шторма prepare()).
    //  • Тяжёлая сборка MediaSource идёт на Dispatchers.Default, а не в UI-потоке.
    //  • setMediaSource(resetPosition = true) заменяет плейлист без промежуточного stop()/IDLE.
    LaunchedEffect(index, attempt) {
        ready = false
        val firstStart = started[0] == -1
        if (attempt == 0 && !firstStart) delay(ZAP_SETTLE_MS)

        val ch = channels[index]
        if (attempt == 0) {
            // Планировщик проверок должен знать активный канал и соседей (i-1, i+1, i+2),
            // а «Недавнее» — каждый реально открытый канал. Только для «осевшего» канала,
            // иначе при листании мы бы писали DataStore и дёргали планировщик на каждый шаг.
            val neighbors = listOf(index - 1, index + 1, index + 2)
                .filter { it in channels.indices }
                .map { channels[it].key }
            latestEvent(PlaybackEvent.Opened(ch.key, neighbors))
            latestOpened(ch)
        }

        val selectedStreamIndex = streamOrder.getOrElse(attempt) { ch.active.coerceIn(ch.streams.indices) }
        val stream = ch.streams[selectedStreamIndex]
        currentStreamIndex = selectedStreamIndex
        flushPlaybackSegment()
        currentStream = stream
        val source = withContext(Dispatchers.Default) { buildMediaSource(context, stream, ch.name) }
        exo.setMediaSource(source, true)
        exo.prepare()
        exo.playWhenReady = true
        started[0] = index
        started[1] = attempt
    }

    // Таймаут запуска потока: следующий поток канала или итоговая ошибка (suspect у планировщика).
    LaunchedEffect(index, attempt, ready, failedNow) {
        if (!ready && !failedNow) {
            delay(Config.PLAYBACK_START_TIMEOUT_MS)
            streamFailed(timeout = true)
        }
    }

    // Долгая буферизация уже идущего потока — тоже повод усомниться в канале.
    LaunchedEffect(index, attempt, ready, buffering) {
        if (ready && buffering) {
            delay(Config.PLAYBACK_STALL_TIMEOUT_MS)
            latestEvent(PlaybackEvent.Timeout(channels[index].key))
        }
    }

    // Автоскрытие overlay: 4 с по тапу/OK, 2.5 с после переключения канала. С открытым меню не скрываем.
    LaunchedEffect(overlay, tick, menuOpen) {
        if (overlay && !menuOpen) {
            delay(hideAfterMs)
            overlay = false
        }
    }

    // Индикатор громкости/яркости скрывается автоматически после жеста.
    LaunchedEffect(adjustmentTick, adjustmentType) {
        if (adjustmentType != null) {
            delay(1400)
            adjustmentType = null
        }
    }

    // Фоновое воспроизведение отключено: при уходе Activity с экрана ставим эфир на паузу.
    // При возвращении в приложение продолжаем тот же канал с текущей позиции.
    DisposableEffect(lifecycleOwner, exo) {
        var resumeOnForeground = false
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> {
                    resumeOnForeground = exo.isPlaying || exo.playWhenReady
                    exo.pause()
                }
                Lifecycle.Event.ON_START -> {
                    if (resumeOnForeground) {
                        resumeOnForeground = false
                        exo.play()
                    }
                }
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Полноэкранный режим на время просмотра.
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        val previousBrightness = window?.attributes?.screenBrightness ?: -1f
        window?.let { WindowCompat.setDecorFitsSystemWindows(it, false) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.statusBars() or WindowInsetsCompat.Type.navigationBars())
        onDispose {
            controller?.show(WindowInsetsCompat.Type.systemBars())
            window?.let { WindowCompat.setDecorFitsSystemWindows(it, true) }
            window?.let { w ->
                val attrs = w.attributes
                attrs.screenBrightness = previousBrightness
                w.attributes = attrs
            }
        }
    }

    // Ландшафт при открытии (обе стороны по датчику, даже при заблокированном повороте);
    // при выходе возвращаем прежнюю ориентацию. Activity не пересоздаётся, поток не прерывается.
    DisposableEffect(isTv) {
        val activity = context.findActivity()
        val previous = activity?.requestedOrientation ?: ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        if (!isTv) activity?.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        onDispose { activity?.requestedOrientation = previous }
    }

    BackHandler {
        if (menuOpen) menuOpen = false else exit()
    }

    // Стабильный обработчик выбора: иначе новая лямбда на каждую рекомпозицию плеера
    // (буферизация, таймеры overlay) пересоздаёт все видимые пункты меню.
    val switchToLatest by rememberUpdatedState<(Int) -> Unit>({ switchTo(it) })
    val onPick = remember { { i: Int -> switchToLatest(i) } }

    val rootFocus = remember { FocusRequester() }
    val errorFocus = remember { FocusRequester() }
    val menuFocus = remember { FocusRequester() }

    fun applyFocus() {
        if (failedNow) {
            runCatching { errorFocus.requestFocus() }
        } else if (menuOpen) {
            if (isTv) runCatching { menuFocus.requestFocus() }
        } else {
            runCatching { rootFocus.requestFocus() }
        }
    }

    LaunchedEffect(failedNow, menuOpen) {
        delay(80)
        applyFocus()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) {
                    false
                } else if (event.key == Key.Menu) {
                    menuOpen = !menuOpen
                    showOverlay()
                    true
                } else if (menuOpen) {
                    false
                } else {
                    when (event.key) {
                        // KEYCODE_DPAD_LEFT / KEYCODE_DPAD_RIGHT и кнопки канала на пульте.
                        Key.DirectionLeft, Key.ChannelUp, Key.PageUp -> {
                            zap(-1)
                            true
                        }
                        Key.DirectionRight, Key.ChannelDown, Key.PageDown -> {
                            zap(1)
                            true
                        }
                        // Первое нажатие OK показывает overlay, второе открывает меню каналов.
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter -> {
                            if (overlay) menuOpen = true else showOverlay()
                            true
                        }
                        // ↓ — включить постоянное затемнение, ↑ — вернуть исходную яркость.
                        // Состояние не зависит от overlay и не сбрасывается его автоскрытием.
                        Key.DirectionDown -> {
                            if (isTv) dimRequested = true
                            showOverlay()
                            true
                        }
                        Key.DirectionUp -> {
                            if (isTv) dimRequested = false
                            showOverlay()
                            true
                        }
                        else -> false
                    }
                }
            }
            .focusRequester(rootFocus)
            .focusable()
            .pointerInput(Unit) {
                detectTapGestures {
                    if (menuOpen) {
                        menuOpen = false
                    } else if (overlay) {
                        overlay = false
                    } else {
                        showOverlay()
                    }
                }
            }
            // Свайп вправо — предыдущий канал, влево — следующий.
            .pointerInput(Unit) {
                var total = 0f
                detectHorizontalDragGestures(
                    onDragStart = { total = 0f },
                    onDragCancel = { total = 0f },
                    onDragEnd = {
                        if (!menuOpen) {
                            if (total > SWIPE_THRESHOLD_PX) {
                                zap(-1)
                            } else if (total < -SWIPE_THRESHOLD_PX) {
                                zap(1)
                            }
                        }
                        total = 0f
                    },
                ) { _, dragAmount -> total += dragAmount }
            }
            // Вертикальный свайп по бокам экрана: слева яркость, справа громкость.
            .pointerInput(isTv, menuOpen, brightnessGestureEnabled.value, volumeGestureEnabled.value) {
                if (!isTv && (brightnessGestureEnabled.value || volumeGestureEnabled.value)) {
                    var side = 0 // -1 brightness, +1 volume
                    var startValue = 0f
                    var accumulated = 0f
                    var maxVolume = 1
                    val audio = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    detectVerticalDragGestures(
                        onDragStart = { offset ->
                            side = if (offset.x < size.width / 2f) -1 else 1
                            if ((side < 0 && !brightnessGestureEnabled.value) ||
                                (side > 0 && !volumeGestureEnabled.value)) {
                                side = 0
                            }
                            accumulated = 0f
                            if (side < 0) {
                                val current = context.findActivity()?.window?.attributes?.screenBrightness ?: -1f
                                startValue = if (current in 0f..1f) current else {
                                    (Settings.System.getInt(context.contentResolver, Settings.System.SCREEN_BRIGHTNESS, 128) / 255f)
                                        .coerceIn(0f, 1f)
                                }
                            } else {
                                maxVolume = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                                startValue = audio.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat()
                            }
                        },
                        onVerticalDrag = { change, dragAmount ->
                            change.consume()
                            if (!menuOpen && side != 0) {
                                accumulated += dragAmount
                                if (side < 0) {
                                    val value = (startValue - accumulated / size.height * 1.25f).coerceIn(0f, 1f)
                                    context.findActivity()?.window?.let { window ->
                                        val attrs = window.attributes
                                        attrs.screenBrightness = value
                                        window.attributes = attrs
                                    }
                                    adjustmentValue = value
                                    adjustmentType = "Яркость"
                                } else {
                                    val value = (startValue - accumulated / size.height * maxVolume * 1.5f)
                                        .toInt().coerceIn(0, maxVolume)
                                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, value, 0)
                                    adjustmentValue = value.toFloat() / maxVolume
                                    adjustmentType = "Громкость"
                                }
                                adjustmentTick++
                            }
                        },
                    )
                }
            },
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                createPlayerView(ctx).apply {
                    useController = false
                    resizeMode = if (stretchImage) {
                        AspectRatioFrameLayout.RESIZE_MODE_FILL
                    } else {
                        AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    // При смене потока держим последний кадр до первого кадра нового канала:
                    // без чёрной вспышки шторки на каждом переключении.
                    setKeepContentOnPlayerReset(true)
                    keepScreenOn = true
                    isFocusable = false
                    isFocusableInTouchMode = false
                    player = exo
                }
            },
            update = { playerView ->
                playerView.resizeMode = if (stretchImage) {
                    AspectRatioFrameLayout.RESIZE_MODE_FILL
                } else {
                    AspectRatioFrameLayout.RESIZE_MODE_FIT
                }
            },
        )

        // Затемнение видео — только ТВ. Это СОСЕДНИЙ слой над PlayerView (не родитель),
        // поэтому SurfaceView остаётся без offscreen-слоя и корректно смешивается с ним.
        // Нет pointerInput/focusable/clickable — фокус и касания проходят сквозь слой.
        if (isTv) {
            VideoDim(
                active = dimRequested || (DIM_WHEN_MENU_OPEN && menuOpen),
            )
        }

        if (buffering && !failedNow) {
            CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(48.dp),
                color = Cyan,
            )
        }

        if (failedNow) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "Не удалось воспроизвести канал",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                TvButton(
                    text = "Назад",
                    onClick = { exit() },
                    modifier = Modifier.focusRequester(errorFocus),
                    primary = true,
                )
            }
        }

        if (!isTv && adjustmentType != null) {
            Column(
                modifier = Modifier
                    .align(if (adjustmentType == "Яркость") Alignment.CenterStart else Alignment.CenterEnd)
                    .padding(horizontal = 22.dp)
                    .background(Color(0xCC101820), RoundedCornerShape(18.dp))
                    .padding(horizontal = 16.dp, vertical = 14.dp)
                    .width(54.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                Text(
                    text = if (adjustmentType == "Яркость") "☀" else "♫",
                    color = Color.White,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                )
                Box(
                    modifier = Modifier
                        .height(112.dp)
                        .width(6.dp)
                        .background(Color(0x44FFFFFF), RoundedCornerShape(50)),
                    contentAlignment = Alignment.BottomCenter,
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .fillMaxHeight(adjustmentValue.coerceIn(0f, 1f))
                            .background(Cyan, RoundedCornerShape(50)),
                    )
                }
                Text(
                    text = "${(adjustmentValue * 100).toInt()}%",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.SemiBold,
                )
            }
        }

        AnimatedVisibility(
            visible = overlay || failedNow || menuOpen,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)),
                    )
                    .padding(horizontal = 24.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // На TV «Назад» — кнопка пульта; кнопка на экране нужна для касания.
                TvButton(
                    text = "← Назад",
                    onClick = { exit() },
                    focusable = false,
                )
                Spacer(Modifier.width(18.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = channel.name,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${index + 1} / ${channels.size}",
                        color = Color(0xB3FFFFFF),
                        fontSize = 13.sp,
                    )
                }
                if (!isTv) {
                    Spacer(Modifier.width(10.dp))
                    TvButton(
                        text = if (stretchImage) "↔ Растянуть: Вкл" else "↔ Растянуть: Выкл",
                        onClick = {
                            stretchImage = !stretchImage
                            playerPrefs.edit().putBoolean("stretch_fullscreen", stretchImage).apply()
                            showOverlay()
                        },
                        focusable = false,
                    )
                }
                Spacer(Modifier.width(18.dp))
                TvButton(
                    text = "☰ Каналы",
                    onClick = {
                        menuOpen = !menuOpen
                        showOverlay()
                    },
                    focusable = false,
                )
            }
        }

        // Полупрозрачное боковое меню: каналы той категории, из которой запущен плеер.
        AnimatedVisibility(
            visible = menuOpen,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
            modifier = Modifier.align(Alignment.CenterEnd),
        ) {
            ChannelMenu(
                title = session.title,
                channels = channels,
                current = index,
                focusRequester = menuFocus,
                onPick = onPick,
            )
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ChannelMenu(
    title: String,
    channels: List<Channel>,
    current: Int,
    focusRequester: FocusRequester,
    onPick: (Int) -> Unit,
) {
    val isTv = LocalIsTv.current
    // Позиция при открытии выставляется сразу (без анимации). Прежний animateScrollToItem на смену
    // `current` убран: при выборе канала он дрался с прокруткой за фокусом и давал рывок.
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = (current - 3).coerceAtLeast(0))
    // Короткая прокрутка по якорю для D-pad; на телефоне — стандартная.
    val spec = remember { TvBringIntoViewSpec(anchor = 0.4f, durationMs = 90) }

    Column(
        modifier = Modifier
            .fillMaxHeight()
            .width(300.dp)
            .background(Color(0xCC070C12))
            // Касания по меню не должны закрывать его и переключать overlay.
            .pointerInput(Unit) { detectTapGestures { } }
            .padding(top = 16.dp, bottom = 8.dp),
    ) {
        Text(
            text = title,
            color = Color(0xB3FFFFFF),
            fontSize = 14.sp,
            fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 20.dp),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
        )
        CompositionLocalProvider(
            LocalBringIntoViewSpec provides (if (isTv) spec else LocalBringIntoViewSpec.current),
        ) {
            LazyColumn(
                state = listState,
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                itemsIndexed(
                    channels,
                    key = { _, ch -> ch.key },
                    contentType = { _, _ -> "menuItem" },
                ) { i, ch ->
                    ChannelMenuItem(
                        channel = ch,
                        index = i,
                        isCurrent = i == current,
                        focusRequester = focusRequester,
                        onPick = onPick,
                    )
                }
            }
        }
    }
}

/** Пункт меню — отдельная функция со стабильными параметрами: при смене current пересобираются только 2 пункта. */
@Composable
private fun ChannelMenuItem(
    channel: Channel,
    index: Int,
    isCurrent: Boolean,
    focusRequester: FocusRequester,
    onPick: (Int) -> Unit,
) {
    FocusSurface(
        onClick = { onPick(index) },
        modifier = if (isCurrent) Modifier.focusRequester(focusRequester) else Modifier,
        shape = RoundedCornerShape(12.dp),
        containerColor = if (isCurrent) Color(0x4422D3FF) else Color(0x14FFFFFF),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(
                text = channel.name,
                modifier = Modifier.weight(1f),
                color = if (isCurrent) Cyan else Color.White,
                fontSize = 15.sp,
                fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Medium,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        StateDot(channel)
    }
}

/**
 * Чёрная плёнка поверх видео с плавным появлением/исчезновением (~350 мс).
 * Анимированное значение читается только в фазе рисования (drawBehind) — без рекомпозиции на каждом кадре
 * и без отдельного GPU-слоя. При alpha == 0 ничего не рисуется.
 */
@Composable
private fun VideoDim(active: Boolean) {
    val alpha by animateFloatAsState(
        targetValue = if (active) DIM_ALPHA else 0f,
        animationSpec = tween(DIM_ANIM_MS, easing = FastOutSlowInEasing),
        label = "videoDim",
    )
    Box(
        Modifier
            .fillMaxSize()
            .drawBehind { if (alpha > 0f) drawRect(Color.Black, alpha = alpha) },
    )
}

/** PlayerView на SurfaceView (по умолчанию) или TextureView (запасной вариант, см. [USE_TEXTURE_VIEW]). */
private fun gesturePrefsForPlayer(context: Context) =
    context.getSharedPreferences("player_settings", Context.MODE_PRIVATE)

private fun createPlayerView(ctx: Context): PlayerView =
    if (USE_TEXTURE_VIEW) {
        LayoutInflater.from(ctx).inflate(R.layout.player_view_texture, null, false) as PlayerView
    } else {
        PlayerView(ctx)
    }

private fun Context.findActivity(): Activity? {
    var ctx: Context? = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
