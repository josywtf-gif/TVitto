package com.tvitto.app.ui

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.focusable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.Immutable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.Key
import androidx.compose.ui.input.key.KeyEventType
import androidx.compose.ui.input.key.key
import androidx.compose.ui.input.key.onKeyEvent
import androidx.compose.ui.input.key.type
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.tvitto.app.Config
import com.tvitto.app.data.Channel
import com.tvitto.app.data.StreamSource
import kotlinx.coroutines.delay

/** Снимок списка каналов на момент открытия плеера (на время просмотра он не меняется). */
@Immutable
class PlaySession(val channels: List<Channel>, val startKey: String)

@Composable
fun PlayerScreen(
    session: PlaySession,
    onExit: (watched: Set<String>, failed: Set<String>, lastKey: String) -> Unit,
) {
    val context = LocalContext.current
    val view = LocalView.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val channels = session.channels

    var index by remember {
        mutableIntStateOf(channels.indexOfFirst { it.key == session.startKey }.coerceAtLeast(0))
    }
    var attempt by remember { mutableIntStateOf(0) }
    var buffering by remember { mutableStateOf(true) }
    var failedNow by remember { mutableStateOf(false) }
    var overlay by remember { mutableStateOf(true) }
    var tick by remember { mutableIntStateOf(0) }

    val watched = remember { LinkedHashSet<String>() }
    val failed = remember { HashSet<String>() }
    val channel = channels[index]

    fun showOverlay() {
        overlay = true
        tick++
    }

    fun exit() {
        onExit(HashSet(watched), HashSet(failed), channels[index].key)
    }

    fun zap(delta: Int) {
        index = (index + delta + channels.size) % channels.size
        attempt = 0
        failedNow = false
        buffering = true
        showOverlay()
    }

    val exo = remember {
        ExoPlayer.Builder(context).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                    .build(),
                true,
            )
            setHandleAudioBecomingNoisy(true)
        }
    }

    DisposableEffect(exo) {
        val listener = object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                buffering = playbackState == Player.STATE_BUFFERING
                if (playbackState == Player.STATE_READY) {
                    val key = channels[index].key
                    watched.add(key)
                    failed.remove(key)
                    failedNow = false
                }
            }

            override fun onPlayerError(error: PlaybackException) {
                val total = channels[index].streams.size
                if (attempt + 1 < total) {
                    // пробуем следующий поток этого же канала
                    attempt += 1
                } else {
                    failedNow = true
                    buffering = false
                    failed.add(channels[index].key)
                }
            }
        }
        exo.addListener(listener)
        onDispose {
            exo.removeListener(listener)
            exo.release()
        }
    }

    // Запуск потока при смене канала или повторной попытке.
    LaunchedEffect(index, attempt) {
        val ch = channels[index]
        val stream = ch.streams[(ch.active + attempt) % ch.streams.size]
        exo.setMediaSource(buildMediaSource(context, stream))
        exo.prepare()
        exo.playWhenReady = true
    }

    // Автоскрытие оверлея через 4 секунды.
    LaunchedEffect(overlay, tick) {
        if (overlay) {
            delay(4000)
            overlay = false
        }
    }

    // Пауза, когда приложение уходит в фон.
    DisposableEffect(lifecycleOwner, exo) {
        val observer = LifecycleEventObserver { _, event ->
            when (event) {
                Lifecycle.Event.ON_STOP -> exo.pause()
                Lifecycle.Event.ON_START -> exo.play()
                else -> Unit
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    // Полноэкранный режим на время просмотра.
    DisposableEffect(Unit) {
        val window = context.findActivity()?.window
        val controller = window?.let { WindowCompat.getInsetsController(it, view) }
        controller?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        controller?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { controller?.show(WindowInsetsCompat.Type.systemBars()) }
    }

    BackHandler { exit() }

    val rootFocus = remember { FocusRequester() }
    val errorFocus = remember { FocusRequester() }
    LaunchedEffect(failedNow) {
        delay(60)
        if (failedNow) {
            runCatching { errorFocus.requestFocus() }
        } else {
            runCatching { rootFocus.requestFocus() }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onKeyEvent { event ->
                if (event.type != KeyEventType.KeyDown) {
                    false
                } else {
                    when (event.key) {
                        Key.DirectionUp, Key.ChannelUp, Key.PageUp -> {
                            zap(-1)
                            true
                        }
                        Key.DirectionDown, Key.ChannelDown, Key.PageDown -> {
                            zap(1)
                            true
                        }
                        Key.DirectionCenter, Key.Enter, Key.NumPadEnter,
                        Key.DirectionLeft, Key.DirectionRight, Key.Menu -> {
                            showOverlay()
                            true
                        }
                        else -> false
                    }
                }
            }
            .focusRequester(rootFocus)
            .focusable()
            .pointerInput(Unit) {
                detectTapGestures {
                    if (overlay) overlay = false else showOverlay()
                }
            },
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                PlayerView(ctx).apply {
                    useController = false
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    setShutterBackgroundColor(android.graphics.Color.BLACK)
                    keepScreenOn = true
                    isFocusable = false
                    player = exo
                }
            },
        )

        if (buffering && !failedNow) {
            CircularProgressIndicator(
                modifier = Modifier
                    .align(Alignment.Center)
                    .size(48.dp),
                color = Cyan,
            )
        }

        if (failedNow) {
            Column(
                modifier = Modifier.align(Alignment.Center),
                horizontalAlignment = Alignment.CenterHorizontally,
            ) {
                Text(
                    text = "Не удалось воспроизвести канал",
                    color = Color.White,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center,
                )
                Spacer(Modifier.height(16.dp))
                TvButton(
                    text = "Назад",
                    onClick = { exit() },
                    modifier = Modifier.focusRequester(errorFocus),
                    primary = true,
                )
            }
        }

        AnimatedVisibility(
            visible = overlay || failedNow,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.align(Alignment.TopStart),
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.verticalGradient(listOf(Color(0xCC000000), Color.Transparent)),
                    )
                    .padding(horizontal = 24.dp, vertical = 18.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                // На TV «Назад» — кнопка пульта; кнопка на экране нужна для касания.
                TvButton(
                    text = "← Назад",
                    onClick = { exit() },
                    focusable = false,
                )
                Spacer(Modifier.width(18.dp))
                Column {
                    Text(
                        text = channel.name,
                        color = Color.White,
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                    )
                    Text(
                        text = "${index + 1} / ${channels.size}",
                        color = Color(0xB3FFFFFF),
                        fontSize = 13.sp,
                    )
                }
            }
        }
    }
}

private fun buildMediaSource(context: Context, stream: StreamSource): MediaSource {
    val http = DefaultHttpDataSource.Factory()
        .setUserAgent(stream.userAgent ?: Config.DEFAULT_UA)
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(10_000)
        .setReadTimeoutMs(15_000)
    stream.referrer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

    val item = MediaItem.Builder()
        .setUri(stream.url)
        .apply {
            if (stream.url.contains(".m3u8", ignoreCase = true)) {
                setMimeType(MimeTypes.APPLICATION_M3U8)
            }
        }
        .build()

    return DefaultMediaSourceFactory(context)
        .setDataSourceFactory(http)
        .createMediaSource(item)
}

private fun Context.findActivity(): Activity? {
    var ctx: Context? = this
    while (ctx is ContextWrapper) {
        if (ctx is Activity) return ctx
        ctx = ctx.baseContext
    }
    return null
}
