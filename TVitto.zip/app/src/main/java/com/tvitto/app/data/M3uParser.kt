package com.tvitto.app.data

object M3uParser {

    data class Entry(
        val tvgId: String?,
        val name: String,
        val logo: String?,
        val group: String?,
        val stream: StreamSource,
    )

    private val attrRegex = Regex("""([A-Za-z0-9_-]+)="([^"]*)"""")

    fun parse(text: String): List<Entry> {
        val out = ArrayList<Entry>()

        var name: String? = null
        var tvgId: String? = null
        var logo: String? = null
        var group: String? = null
        var referrer: String? = null
        var userAgent: String? = null

        for (rawLine in text.lineSequence()) {
            val line = rawLine.trim().trimStart('﻿')
            if (line.isEmpty()) continue

            when {
                line.startsWith("#EXTINF", ignoreCase = true) -> {
                    val attrs = HashMap<String, String>()
                    for (m in attrRegex.findAll(line)) {
                        attrs[m.groupValues[1].lowercase()] = m.groupValues[2]
                    }
                    var title = extractTitle(line)
                    if (title.isBlank()) title = attrs["tvg-name"].orEmpty()
                    name = title
                    tvgId = attrs["tvg-id"]?.trim()?.takeIf { it.isNotEmpty() }
                    logo = attrs["tvg-logo"]?.trim()?.takeIf { it.startsWith("http", ignoreCase = true) }
                    group = attrs["group-title"]?.trim()?.takeIf { it.isNotEmpty() }
                    referrer = null
                    userAgent = null
                }

                line.startsWith("#EXTVLCOPT:", ignoreCase = true) -> {
                    val body = line.substringAfter(':')
                    val key = body.substringBefore('=').trim().lowercase()
                    val value = body.substringAfter('=', "").trim().trim('"')
                    when (key) {
                        "http-referrer", "http-referer" -> referrer = value.ifEmpty { null }
                        "http-user-agent" -> userAgent = value.ifEmpty { null }
                    }
                }

                line.startsWith("#") -> Unit

                else -> {
                    val title = name
                    val isHttp = line.startsWith("http://", ignoreCase = true) ||
                        line.startsWith("https://", ignoreCase = true)
                    if (title != null && isHttp) {
                        out += Entry(
                            tvgId = tvgId,
                            name = title.ifBlank { "Без названия" },
                            logo = logo,
                            group = group,
                            stream = StreamSource(line, referrer, userAgent),
                        )
                    }
                    name = null
                    tvgId = null
                    logo = null
                    group = null
                    referrer = null
                    userAgent = null
                }
            }
        }
        return out
    }

    /** Название — всё после первой запятой вне кавычек. */
    private fun extractTitle(line: String): String {
        var inQuotes = false
        for (i in line.indices) {
            val c = line[i]
            if (c == '"') {
                inQuotes = !inQuotes
            } else if (c == ',' && !inQuotes) {
                return line.substring(i + 1).trim()
            }
        }
        return ""
    }
}
