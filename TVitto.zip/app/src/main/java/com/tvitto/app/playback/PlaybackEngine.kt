package com.tvitto.app.playback

import android.content.Context
import android.content.Intent
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/** Один экземпляр ExoPlayer на процесс: UI и MediaSessionService управляют одним проигрывателем. */
object PlaybackEngine {
    @Volatile private var instance: ExoPlayer? = null

    @Synchronized
    fun get(context: Context): ExoPlayer {
        instance?.let { return it }
        val app = context.applicationContext
        val selector = DefaultTrackSelector(app).apply {
            setParameters(buildUponParameters().setTunnelingEnabled(true))
        }
        return ExoPlayer.Builder(app).setTrackSelector(selector).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            setHandleAudioBecomingNoisy(true)
            instance = this
        }
    }

    @Synchronized
    fun release(player: ExoPlayer?) {
        if (player != null && instance === player) {
            instance = null
            player.release()
        }
    }

    /** Полностью завершает просмотр: очищает очередь, освобождает ExoPlayer и останавливает сервис. */
    @Synchronized
    fun stopAndRelease(context: Context) {
        val player = instance
        if (player != null) {
            runCatching {
                player.playWhenReady = false
                player.pause()
                player.stop()
                player.clearMediaItems()
            }
        }
        // Сначала останавливаем сервис: он завершит MediaSession и освободит общий ExoPlayer.
        // Если сервис ещё не успел запуститься, освобождаем экземпляр здесь.
        val stopped = runCatching {
            context.applicationContext.stopService(
                Intent(context.applicationContext, TVittoPlaybackService::class.java),
            )
        }.getOrDefault(false)
        if (!stopped && player != null) release(player)
    }
}
