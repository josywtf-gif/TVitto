package com.tvitto.app.playback

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/** Один экземпляр ExoPlayer на процесс: UI и MediaSessionService управляют одним проигрывателем. */
object PlaybackEngine {
    @Volatile private var instance: ExoPlayer? = null

    @Synchronized
    fun get(context: Context): ExoPlayer {
        instance?.let { return it }
        val app = context.applicationContext
        val selector = DefaultTrackSelector(app).apply {
            setParameters(buildUponParameters().setTunnelingEnabled(true))
        }
        return ExoPlayer.Builder(app).setTrackSelector(selector).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            setHandleAudioBecomingNoisy(true)
            @Suppress("DEPRECATION")
            experimentalSetVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS)
            instance = this
        }
    }

    @Synchronized
    fun release(player: ExoPlayer?) {
        if (player != null && instance === player) {
            instance = null
            player.release()
        }
    }
}
