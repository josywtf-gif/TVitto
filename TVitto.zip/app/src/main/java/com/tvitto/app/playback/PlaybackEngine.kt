package com.tvitto.app.playback

import android.content.Context
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector

/** Проигрыватель существует только пока открыт экран просмотра. */
object PlaybackEngine {
    @Volatile private var instance: ExoPlayer? = null

    @Synchronized
    fun get(context: Context): ExoPlayer {
        instance?.let { return it }
        val app = context.applicationContext
        val selector = DefaultTrackSelector(app).apply {
            setParameters(buildUponParameters().setTunnelingEnabled(true))
        }
        return ExoPlayer.Builder(app).setTrackSelector(selector).build().apply {
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(), true
            )
            setHandleAudioBecomingNoisy(true)
            instance = this
        }
    }

    @Synchronized
    fun stopAndRelease() {
        val player = instance ?: return
        instance = null
        runCatching {
            player.playWhenReady = false
            player.pause()
            player.stop()
            player.clearMediaItems()
            player.release()
        }
    }
}
