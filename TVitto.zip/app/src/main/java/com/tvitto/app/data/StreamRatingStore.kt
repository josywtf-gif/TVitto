package com.tvitto.app.data

import android.content.Context
import java.security.MessageDigest
import kotlin.math.ln

/** Локальная статистика потоков. Храним только хеш URL, без токенов и query-параметров в ключах. */
object StreamRatingStore {
    private const val PREFS = "stream_quality_v1"
    private const val PLAY_MS = "play_ms_"
    private const val BUFFER_MS = "buffer_ms_"
    private const val BUFFER_COUNT = "buffer_count_"
    private const val FAILURES = "failures_"

    private fun id(stream: StreamSource): String = MessageDigest.getInstance("SHA-256")
        .digest((stream.url + "\u0000" + (stream.referrer ?: "") + "\u0000" + (stream.userAgent ?: "")).toByteArray())
        .take(16).joinToString("") { "%02x".format(it) }

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    @Synchronized fun addPlayback(context: Context, stream: StreamSource, durationMs: Long) {
        if (durationMs <= 0) return
        val p = prefs(context); val key = id(stream)
        p.edit().putLong(PLAY_MS + key, p.getLong(PLAY_MS + key, 0L) + durationMs).apply()
    }

    @Synchronized fun addBuffering(context: Context, stream: StreamSource, durationMs: Long) {
        if (durationMs < 0) return
        val p = prefs(context); val key = id(stream)
        p.edit().putLong(BUFFER_MS + key, p.getLong(BUFFER_MS + key, 0L) + durationMs)
            .putInt(BUFFER_COUNT + key, p.getInt(BUFFER_COUNT + key, 0) + 1).apply()
    }

    @Synchronized fun addFailure(context: Context, stream: StreamSource) {
        val p = prefs(context); val key = id(stream)
        p.edit().putInt(FAILURES + key, p.getInt(FAILURES + key, 0) + 1).apply()
    }

    /** Сначала лучший измеренный поток; при равной оценке сохраняем исходный порядок плейлиста. */
    fun rankedIndices(context: Context, channel: Channel): List<Int> {
        if (channel.streams.size < 2) return channel.streams.indices.toList()
        val p = prefs(context)
        fun score(stream: StreamSource): Double {
            val key = id(stream)
            val play = p.getLong(PLAY_MS + key, 0L).toDouble()
            val buffer = p.getLong(BUFFER_MS + key, 0L).toDouble()
            val bufferCount = p.getInt(BUFFER_COUNT + key, 0)
            val failures = p.getInt(FAILURES + key, 0)
            if (play == 0.0 && bufferCount == 0 && failures == 0) return 0.0
            val reliability = (play / (play + buffer + 30_000.0)).coerceIn(0.0, 1.0)
            return ln(1.0 + play / 60_000.0) * (0.25 + 0.75 * reliability) -
                bufferCount * 0.35 - failures * 1.5 - (buffer / 60_000.0) * 0.8
        }
        val base = channel.streams.indices.toMutableList()
        // Сохранить приоритет проверенного активного потока при равной статистике.
        if (channel.active in base) { base.remove(channel.active); base.add(0, channel.active) }
        return base.sortedWith(compareByDescending<Int> { score(channel.streams[it]) }.thenBy { base.indexOf(it) })
    }
}
