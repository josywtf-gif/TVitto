package com.tvitto.app.data

import android.content.Context
import android.content.SharedPreferences
import java.security.MessageDigest
import kotlin.math.ln

/** Локальная статистика потоков. Храним только хеш URL, без токенов и query-параметров в ключах. */
object StreamRatingStore {
    // v2: в v1 каждый запуск канала считался «буферизацией», и часто смотримые каналы уходили в минус.
    private const val PREFS = "stream_quality_v2"
    private const val LEGACY_PREFS = "stream_quality_v1"
    private const val PLAY_MS = "play_ms_"
    private const val BUFFER_MS = "buffer_ms_"
    private const val BUFFER_COUNT = "buffer_count_"
    private const val FAILURES = "failures_"

    private val HEX = "0123456789abcdef".toCharArray()

    private fun id(stream: StreamSource): String {
        val md = MessageDigest.getInstance("SHA-256")
        md.update(stream.url.toByteArray())
        md.update(0)
        md.update((stream.referrer ?: "").toByteArray())
        md.update(0)
        md.update((stream.userAgent ?: "").toByteArray())
        val d = md.digest()
        val out = CharArray(32)
        for (i in 0 until 16) {
            val b = d[i].toInt()
            out[i * 2] = HEX[(b shr 4) and 0xF]
            out[i * 2 + 1] = HEX[b and 0xF]
        }
        return String(out)
    }

    @Volatile private var cached: SharedPreferences? = null

    private fun prefs(context: Context): SharedPreferences = cached ?: synchronized(this) {
        cached ?: context.applicationContext.let { app ->
            // Устаревшая (искажённая) статистика больше не нужна.
            app.deleteSharedPreferences(LEGACY_PREFS)
            app.getSharedPreferences(PREFS, Context.MODE_PRIVATE).also { cached = it }
        }
    }

    @Synchronized fun addPlayback(context: Context, stream: StreamSource, durationMs: Long) {
        if (durationMs <= 0) return
        val p = prefs(context); val key = id(stream)
        p.edit().putLong(PLAY_MS + key, p.getLong(PLAY_MS + key, 0L) + durationMs).apply()
    }

    /** Остановка воспроизведения посреди просмотра (не стартовая буферизация). */
    @Synchronized fun addBuffering(context: Context, stream: StreamSource, durationMs: Long) {
        if (durationMs < 0) return
        val p = prefs(context); val key = id(stream)
        p.edit().putLong(BUFFER_MS + key, p.getLong(BUFFER_MS + key, 0L) + durationMs)
            .putInt(BUFFER_COUNT + key, p.getInt(BUFFER_COUNT + key, 0) + 1).apply()
    }

    @Synchronized fun addFailure(context: Context, stream: StreamSource) {
        val p = prefs(context); val key = id(stream)
        p.edit().putInt(FAILURES + key, p.getInt(FAILURES + key, 0) + 1).apply()
    }

    /**
     * Оценка стабильности потока: 0 — нет статистики, больше — лучше, отрицательная — в основном сбои.
     * Оценка растёт с временем просмотра и качеством (доля времени без остановок, частота остановок
     * в пересчёте на час) — поэтому хорошо работающий канал никогда не уходит ниже «неизвестных».
     * Сбои ослабевают по мере накопления просмотра.
     */
    private fun score(p: SharedPreferences, stream: StreamSource): Double {
        val key = id(stream)
        val play = p.getLong(PLAY_MS + key, 0L).toDouble()
        val buffer = p.getLong(BUFFER_MS + key, 0L).toDouble()
        val stalls = p.getInt(BUFFER_COUNT + key, 0)
        val failures = p.getInt(FAILURES + key, 0)
        if (play == 0.0 && stalls == 0 && failures == 0) return 0.0
        val minutes = play / 60_000.0
        val reliability = play / (play + buffer + 30_000.0)
        val stallsPerHour = stalls / (minutes / 60.0 + 0.25)
        val quality = reliability / (1.0 + 0.5 * stallsPerHour)
        val failPenalty = 1.5 * failures / (1.0 + minutes / 30.0)
        return ln(1.0 + minutes) * quality - failPenalty
    }

    /**
     * Оценки каналов (ключ → балл) за один проход: настройки читаются один раз.
     * Каналы без статистики в карту не попадают. Дорого — вызывать не в UI-потоке.
     */
    fun channelScores(context: Context, channels: List<Channel>): Map<String, Double> {
        val p = prefs(context)
        if (p.all.isEmpty()) return emptyMap()
        val out = HashMap<String, Double>()
        for (ch in channels) {
            var best = Double.NEGATIVE_INFINITY
            for (st in ch.streams) best = maxOf(best, score(p, st))
            if (best != Double.NEGATIVE_INFINITY && best != 0.0) out[ch.key] = best
        }
        return out
    }

    /** Сначала лучший измеренный поток; при равной оценке сохраняем исходный порядок плейлиста. */
    fun rankedIndices(context: Context, channel: Channel): List<Int> {
        if (channel.streams.size < 2) return channel.streams.indices.toList()
        val p = prefs(context)
        val base = channel.streams.indices.toMutableList()
        // Сохранить приоритет проверенного активного потока при равной статистике.
        if (channel.active in base) { base.remove(channel.active); base.add(0, channel.active) }
        val scores = channel.streams.map { score(p, it) }
        return base.sortedWith(compareByDescending<Int> { scores[it] }.thenBy { base.indexOf(it) })
    }
}
