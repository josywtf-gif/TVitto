package com.tvitto.app.data

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters

/** Обновляет кеш встроенных плейлистов только по ограничениям WorkManager. */
class PlaylistRefreshWorker(
    context: Context,
    params: WorkerParameters,
) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result = try {
        val channels = PlaylistRepository().load()
        if (channels.isEmpty()) Result.retry()
        else {
            ChannelListCache(applicationContext).save(channels)
            Result.success()
        }
    } catch (_: Exception) {
        Result.retry()
    }
}
