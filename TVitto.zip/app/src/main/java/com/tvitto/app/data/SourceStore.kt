package com.tvitto.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import java.io.File

private val Context.sourceDataStore by preferencesDataStore(name = "tvitto_source")

/**
 * Выбранный источник и свой плейлист.
 * Текст плейлиста лежит в файле (он может быть большим), выбор источника и исходная ссылка — в DataStore.
 */
class SourceStore(context: Context) {

    private val app = context.applicationContext
    private val store = app.sourceDataStore
    private val sourceKey = stringPreferencesKey("source_v1")
    private val urlKey = stringPreferencesKey("custom_url_v1")
    private val file = File(app.filesDir, "custom_playlist.m3u")

    suspend fun loadSource(): Source = try {
        Source.valueOf(store.data.first()[sourceKey] ?: Source.BUILTIN.name)
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        Source.BUILTIN
    }

    suspend fun saveSource(source: Source) {
        try {
            store.edit { it[sourceKey] = source.name }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // best effort
        }
    }

    /** Ссылка, с которой добавлен плейлист (null — вставлено содержимое). */
    suspend fun loadUrl(): String? = try {
        store.data.first()[urlKey]?.takeIf { it.isNotBlank() }
    } catch (e: CancellationException) {
        throw e
    } catch (e: Exception) {
        null
    }

    suspend fun hasCustom(): Boolean = withContext(Dispatchers.IO) { file.exists() && file.length() > 0L }

    suspend fun loadCustomText(): String? = withContext(Dispatchers.IO) {
        try {
            if (file.exists()) file.readText(Charsets.UTF_8).takeIf { it.isNotBlank() } else null
        } catch (e: Exception) {
            null
        }
    }

    /** Атомарно сохраняет текст плейлиста и ссылку (если есть). */
    suspend fun saveCustom(text: String, url: String?) {
        withContext(Dispatchers.IO) {
            val tmp = File(file.parentFile, file.name + ".tmp")
            tmp.writeText(text, Charsets.UTF_8)
            if (!tmp.renameTo(file)) {
                file.delete()
                tmp.renameTo(file)
            }
        }
        try {
            store.edit { prefs ->
                if (url != null) prefs[urlKey] = url else prefs.remove(urlKey)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // best effort
        }
    }
}
