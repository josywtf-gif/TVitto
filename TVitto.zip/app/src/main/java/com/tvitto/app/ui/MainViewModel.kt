package com.tvitto.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvitto.app.Config
import com.tvitto.app.data.Categories
import com.tvitto.app.data.Channel
import com.tvitto.app.data.ChannelListCache
import com.tvitto.app.data.CheckCache
import com.tvitto.app.data.CheckResult
import com.tvitto.app.data.Net
import com.tvitto.app.data.Phase
import com.tvitto.app.data.PlaylistRepository
import com.tvitto.app.data.RecentEntry
import com.tvitto.app.data.RecentStore
import com.tvitto.app.data.StreamChecker
import com.tvitto.app.data.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = PlaylistRepository()
    private val checker = StreamChecker(app, Net.client)
    private val cache = CheckCache(app)
    private val listCache = ChannelListCache(app)

    private val phase = MutableStateFlow(Phase.Loading)
    private val all = MutableStateFlow<List<Channel>>(emptyList())
    private val results = MutableStateFlow<Map<String, CheckResult>>(emptyMap())
    private val checking = MutableStateFlow(false)
    private val selected = MutableStateFlow(Categories.ALL)
    private val recentStore = RecentStore(app)
    private val recent = MutableStateFlow<List<RecentEntry>>(emptyList())
    private val selection = combine(selected, recent) { s, r -> Pair(s, r) }

    private var loadJob: Job? = null
    private var checkJob: Job? = null
    private var recheckJob: Job? = null

    /** true, пока открыт плеер: фоновые проверки не запускаются. */
    private var paused = false

    /**
     * В списке только рабочие каналы (прошли сетевую проверку и реально играют),
     * отфильтрованные по категории. Обновляется по мере поступления результатов.
     */
    val state: StateFlow<UiState> =
        combine(phase, all, results, checking, selection) { p, list, res, chk, selectionPair ->
            val (sel, rec) = selectionPair
            val working = ArrayList<Channel>()
            var checked = 0
            for (ch in list) {
                val r = res[ch.key] ?: continue
                checked++
                if (r.idx >= 0 && r.idx < ch.streams.size) {
                    working.add(ch.copy(active = r.idx))
                }
            }
            // Категории без рабочих каналов скрываются.
            val present = Categories.ORDER.filter { cat -> working.any { it.category == cat } }
            val effective = when {
                sel == Categories.ALL || sel == Categories.RECENT -> sel
                sel in present -> sel
                else -> Categories.ALL
            }
            val shown = when (effective) {
                Categories.ALL -> working
                // «Недавние»: порядок по свежести; недоступные сейчас каналы скрыты,
                // но из хранилища не удаляются.
                Categories.RECENT -> {
                    val byKey = working.associateBy { it.key }
                    rec.mapNotNull { byKey[it.key] }
                }
                else -> working.filter { it.category == effective }
            }
            UiState(
                phase = p,
                channels = shown,
                categories = present,
                selected = effective,
                recentTotal = rec.size,
                checked = checked,
                total = list.size,
                checking = chk,
            )
        }
            .sample(200)
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        viewModelScope.launch {
            val stored = recentStore.load()
            recent.update { current ->
                (current + stored.filter { e -> current.none { it.key == e.key } })
                    .take(Config.RECENT_LIMIT)
            }
        }
        load()
    }

    fun selectCategory(name: String) {
        selected.value = name
    }

    /** Новый канал — в начало, дубликат переносится, хранится максимум 10 последних. */
    fun addRecent(channel: Channel) {
        val entry = RecentEntry(channel.key, channel.name, channel.logo)
        val next = (listOf(entry) + recent.value.filter { it.key != channel.key })
            .take(Config.RECENT_LIMIT)
        recent.value = next
        viewModelScope.launch { recentStore.save(next) }
    }

    fun retry() = load(fresh = true)

    private fun load(fresh: Boolean = false) {
        val prevLoad = loadJob
        val prevCheck = checkJob
        val prevRecheck = recheckJob
        loadJob = viewModelScope.launch {
            prevLoad?.cancelAndJoin()
            prevCheck?.cancelAndJoin()
            prevRecheck?.cancelAndJoin()

            if (fresh) {
                phase.value = Phase.Loading
                results.value = emptyMap()
                all.value = emptyList()
                cache.clear()
                listCache.clear()
            }

            // 1) Есть кэш после предыдущего запуска — показываем сразу, без сети.
            val cachedList = if (fresh) emptyList() else listCache.load()
            if (cachedList.isNotEmpty()) {
                val byKey = cachedList.associateBy { it.key }
                val valid = HashMap<String, CheckResult>()
                for ((key, r) in cache.load()) {
                    val ch = byKey[key] ?: continue
                    if (r.idx < ch.streams.size) valid[key] = r
                }
                all.value = cachedList
                results.value = valid
                phase.value = Phase.Ready
                startChecks() // догружаем только каналы без результата
                startRecheck()
                syncPlaylist() // в фоне подтягиваем новые каналы из плейлистов
                return@launch
            }

            // 2) Первый запуск: загрузка плейлистов и полная проверка.
            phase.value = Phase.Loading
            val list = try {
                repository.load()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            if (list.isEmpty()) {
                phase.value = Phase.Error
                return@launch
            }

            all.value = list
            results.value = emptyMap()
            phase.value = Phase.Ready
            listCache.save(list)
            startChecks() // результаты уходят в кэш по завершении проверки
            startRecheck()
        }
    }

    /**
     * Тихо перечитывает плейлисты. Новые каналы добавляются и проверяются,
     * пропавшие из плейлиста — удаляются, у изменившихся потоков результат сбрасывается.
     */
    private suspend fun syncPlaylist() {
        val fresh = try {
            repository.load()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            return
        }
        if (fresh.isEmpty()) return

        // Пока обновляем список, проверки стоят — иначе результат ляжет на устаревшие потоки.
        checkJob?.cancelAndJoin()
        recheckJob?.cancelAndJoin()

        val old = all.value.associateBy { it.key }
        val known = results.value
        val kept = HashMap<String, CheckResult>()
        for (ch in fresh) {
            val r = known[ch.key] ?: continue
            if (old[ch.key]?.streams == ch.streams && r.idx < ch.streams.size) kept[ch.key] = r
        }
        all.value = fresh
        results.value = kept
        listCache.save(fresh)
        withContext(NonCancellable) { cache.save(kept) }

        startChecks()
        startRecheck()
    }

    /**
     * Раз в [Config.RECHECK_INTERVAL_MS] перепроверяет один канал — самый давно проверенный.
     * Перестал играть — пропадает из списка, снова заиграл — появляется. Работает, пока открыто приложение.
     */
    private fun startRecheck() {
        if (paused) return
        val prev = recheckJob
        recheckJob = viewModelScope.launch {
            prev?.cancelAndJoin()
            while (true) {
                delay(Config.RECHECK_INTERVAL_MS)
                if (checking.value) continue // идёт основная проверка — пропускаем такт
                val known = results.value
                val target = all.value
                    .filter { known.containsKey(it.key) }
                    .minByOrNull { known.getValue(it.key).ts }
                    ?: continue
                val idx = checker.firstWorking(target)
                results.update { it + (target.key to CheckResult(idx, System.currentTimeMillis())) }
                withContext(NonCancellable) { cache.save(results.value) }
            }
        }
    }

    /**
     * Фоновая двухуровневая проверка (лимиты параллелизма — внутри StreamChecker).
     * Проверяются только каналы без результата (остальные берутся из кэша); список обновляется на лету.
     */
    private fun startChecks(exclude: Set<String> = emptySet()) {
        if (paused) return
        val prev = checkJob
        checkJob = viewModelScope.launch {
            prev?.cancelAndJoin()

            val known = results.value
            // Каналы из «Недавних» проверяются первыми.
            val recentKeys = recent.value.map { it.key }.toSet()
            val todo = all.value.filter { ch ->
                ch.key !in exclude && !known.containsKey(ch.key)
            }.sortedBy { it.key !in recentKeys }
            if (todo.isEmpty()) return@launch

            checking.value = true
            try {
                coroutineScope {
                    for (ch in todo) {
                        launch {
                            val idx = checker.firstWorking(ch)
                            val result = CheckResult(idx, System.currentTimeMillis())
                            results.update { it + (ch.key to result) }
                        }
                    }
                }
            } finally {
                checking.value = false
                withContext(NonCancellable) { cache.save(results.value) }
            }
        }
    }

    /** Пока идёт воспроизведение, фоновая проверка не должна занимать сеть и декодеры. */
    fun pauseChecks() {
        paused = true
        checkJob?.cancel()
        recheckJob?.cancel()
    }

    /**
     * Возврат из плеера: просмотренные каналы считаются свежепроверенными
     * и повторно не проверяются, остальные догружаются в фоне.
     */
    fun resumeChecks(watched: Set<String>, failed: Set<String>) {
        paused = false
        val now = System.currentTimeMillis()
        results.update { current ->
            val next = current.toMutableMap()
            for (key in watched) {
                val r = next[key]
                if (r != null && r.idx >= 0) next[key] = r.copy(ts = now)
            }
            for (key in failed) next[key] = CheckResult(-1, now)
            next
        }
        startChecks(exclude = watched)
        startRecheck()
    }
}
