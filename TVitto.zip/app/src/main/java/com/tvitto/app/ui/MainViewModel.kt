package com.tvitto.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvitto.app.Config
import com.tvitto.app.data.Channel
import com.tvitto.app.data.CheckCache
import com.tvitto.app.data.CheckResult
import com.tvitto.app.data.Net
import com.tvitto.app.data.Phase
import com.tvitto.app.data.PlaylistRepository
import com.tvitto.app.data.StreamChecker
import com.tvitto.app.data.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = PlaylistRepository()
    private val checker = StreamChecker(Net.client)
    private val cache = CheckCache(app)

    private val phase = MutableStateFlow(Phase.Loading)
    private val all = MutableStateFlow<List<Channel>>(emptyList())
    private val results = MutableStateFlow<Map<String, CheckResult>>(emptyMap())
    private val checking = MutableStateFlow(false)

    private var loadJob: Job? = null
    private var checkJob: Job? = null

    /** В списке только рабочие каналы; он обновляется по мере поступления результатов проверки. */
    val state: StateFlow<UiState> =
        combine(phase, all, results, checking) { p, list, res, chk ->
            val visible = ArrayList<Channel>()
            var checked = 0
            for (ch in list) {
                val r = res[ch.key] ?: continue
                checked++
                if (r.idx >= 0 && r.idx < ch.streams.size) {
                    visible.add(ch.copy(active = r.idx))
                }
            }
            UiState(
                phase = p,
                channels = visible,
                checked = checked,
                total = list.size,
                checking = chk,
            )
        }
            .sample(200)
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        load()
    }

    fun retry() = load(fresh = true)

    private fun load(fresh: Boolean = false) {
        val prevLoad = loadJob
        val prevCheck = checkJob
        loadJob = viewModelScope.launch {
            prevLoad?.cancelAndJoin()
            prevCheck?.cancelAndJoin()

            phase.value = Phase.Loading
            if (fresh) {
                results.value = emptyMap()
                cache.clear()
            }

            val list = try {
                repository.load()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            if (list.isEmpty()) {
                phase.value = Phase.Error
                return@launch
            }

            // Берём из кэша свежие результаты предыдущих проверок.
            val now = System.currentTimeMillis()
            val byKey = list.associateBy { it.key }
            val cached = if (fresh) emptyMap() else cache.load()
            val valid = HashMap<String, CheckResult>()
            for ((key, r) in cached) {
                val ch = byKey[key] ?: continue
                if (now - r.ts <= Config.CACHE_TTL_MS && r.idx < ch.streams.size) valid[key] = r
            }

            all.value = list
            results.value = valid
            phase.value = Phase.Ready
            startChecks()
        }
    }

    /** Фоновая проверка: только каналы без свежего результата. Список обновляется на лету. */
    private fun startChecks(exclude: Set<String> = emptySet()) {
        val prev = checkJob
        checkJob = viewModelScope.launch {
            prev?.cancelAndJoin()

            val now = System.currentTimeMillis()
            val known = results.value
            val todo = all.value.filter { ch ->
                ch.key !in exclude && (known[ch.key]?.let { now - it.ts > Config.CACHE_TTL_MS } ?: true)
            }
            if (todo.isEmpty()) return@launch

            checking.value = true
            try {
                val semaphore = Semaphore(Config.CHECK_CONCURRENCY)
                coroutineScope {
                    for (ch in todo) {
                        launch {
                            semaphore.withPermit {
                                val idx = checker.firstWorking(ch)
                                val result = CheckResult(idx, System.currentTimeMillis())
                                results.update { it + (ch.key to result) }
                            }
                        }
                    }
                }
            } finally {
                checking.value = false
                withContext(NonCancellable) { cache.save(results.value) }
            }
        }
    }

    /** Пока идёт воспроизведение, фоновая проверка не должна занимать канал. */
    fun pauseChecks() {
        checkJob?.cancel()
    }

    /**
     * Возврат из плеера: просмотренные каналы считаются свежепроверенными
     * и повторно не проверяются, остальные догружаются в фоне.
     */
    fun resumeChecks(watched: Set<String>, failed: Set<String>) {
        val now = System.currentTimeMillis()
        results.update { current ->
            val next = current.toMutableMap()
            for (key in watched) {
                val r = next[key]
                if (r != null && r.idx >= 0) next[key] = r.copy(ts = now)
            }
            for (key in failed) next[key] = CheckResult(-1, now)
            next
        }
        startChecks(exclude = watched)
    }
}
