package com.tvitto.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvitto.app.Config
import com.tvitto.app.data.Categories
import com.tvitto.app.data.Channel
import com.tvitto.app.data.ChannelListCache
import com.tvitto.app.data.CheckCache
import com.tvitto.app.data.CheckScheduler
import com.tvitto.app.data.CheckState
import com.tvitto.app.data.LoadGovernor
import com.tvitto.app.data.Net
import com.tvitto.app.data.Phase
import com.tvitto.app.data.PlaybackEvent
import com.tvitto.app.data.PlaylistRepository
import com.tvitto.app.data.RecentEntry
import com.tvitto.app.data.RecentStore
import com.tvitto.app.data.StreamChecker
import com.tvitto.app.data.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val repository = PlaylistRepository()
    private val governor = LoadGovernor(app)
    private val scheduler = CheckScheduler(
        scope = viewModelScope,
        checker = StreamChecker(app, Net.client, governor),
        store = CheckCache(app),
        governor = governor,
    )
    private val listCache = ChannelListCache(app)
    private val recentStore = RecentStore(app)

    private val phase = MutableStateFlow(Phase.Loading)
    private val all = MutableStateFlow<List<Channel>>(emptyList())
    private val selected = MutableStateFlow(Categories.ALL)
    private val recent = MutableStateFlow<List<RecentEntry>>(emptyList())
    private val selection = combine(selected, recent) { s, r -> Pair(s, r) }

    private data class Meta(val initialDone: Boolean, val bgDone: Int, val bgTotal: Int, val online: Boolean)

    private val meta = combine(scheduler.initialDone, scheduler.backlog, governor.online) { done, backlog, online ->
        Meta(done, backlog.first, backlog.second, online)
    }

    private var loadJob: Job? = null
    private var refreshJob: Job? = null
    private val syncLock = Mutex()

    /** Не удалось обновить плейлисты в фоне — повторим при возвращении сети. */
    @Volatile
    private var syncPending = false

    /**
     * Видимые каналы: alive, suspect (с серым индикатором) и ещё не проверенные; dead скрыты, но остаются в кеше.
     * Обновляется по мере поступления результатов, вне главного потока.
     */
    val state: StateFlow<UiState> =
        combine(phase, all, scheduler.results, selection, meta) { p, list, res, selectionPair, m ->
            val (sel, rec) = selectionPair
            val visible = ArrayList<Channel>(list.size)
            var checked = 0
            for (ch in list) {
                val r = res[ch.key]
                val st = r?.state ?: CheckState.UNKNOWN
                if (st != CheckState.UNKNOWN) checked++
                when (st) {
                    CheckState.DEAD -> Unit
                    CheckState.UNKNOWN -> visible.add(ch)
                    else -> {
                        val active = if (r != null && r.idx in ch.streams.indices) r.idx else 0
                        visible.add(if (ch.state == st && ch.active == active) ch else ch.copy(active = active, state = st))
                    }
                }
            }
            val byKey = visible.associateBy { it.key }
            val recentVisible = rec.mapNotNull { byKey[it.key] }

            // Категории без видимых каналов скрываются.
            val present = Categories.ORDER.filter { cat -> visible.any { it.category == cat } }
            val effective = when {
                sel == Categories.ALL || sel == Categories.RECENT -> sel
                sel in present -> sel
                else -> Categories.ALL
            }
            val shown = when (effective) {
                Categories.ALL -> visible
                // «Недавнее»: порядок по свежести; недоступные сейчас каналы скрыты, но из хранилища не удаляются.
                Categories.RECENT -> recentVisible
                else -> visible.filter { it.category == effective }
            }
            val counts = HashMap<String, Int>()
            counts[Categories.ALL] = visible.size
            counts[Categories.RECENT] = recentVisible.size
            for (cat in present) counts[cat] = visible.count { it.category == cat }

            UiState(
                phase = p,
                channels = shown,
                categories = present,
                counts = counts,
                selected = effective,
                recentTotal = rec.size,
                checked = checked,
                total = list.size,
                initialDone = m.initialDone,
                bgDone = m.bgDone,
                bgTotal = m.bgTotal,
                offline = !m.online,
            )
        }
            .sample(200)
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        viewModelScope.launch {
            val stored = recentStore.load()
            recent.update { current ->
                (current + stored.filter { e -> current.none { it.key == e.key } })
                    .take(Config.RECENT_LIMIT)
            }
            scheduler.setRecent(recent.value.map { it.key })
        }
        // Сеть вернулась: догружаем плейлисты, если не получилось раньше.
        viewModelScope.launch {
            governor.online.collect { online ->
                if (!online) return@collect
                if (phase.value == Phase.Error) {
                    load()
                } else if (syncPending && phase.value == Phase.Ready) {
                    syncPlaylist()
                }
            }
        }
        load()
    }

    override fun onCleared() {
        scheduler.stop()
        governor.close()
        super.onCleared()
    }

    fun selectCategory(name: String) {
        selected.value = name
    }

    /** Новый канал — в начало, дубликат переносится, хранится максимум 10 последних. */
    fun addRecent(channel: Channel) {
        val entry = RecentEntry(channel.key, channel.name, channel.logo)
        val next = (listOf(entry) + recent.value.filter { it.key != channel.key })
            .take(Config.RECENT_LIMIT)
        recent.value = next
        scheduler.setRecent(next.map { it.key })
        viewModelScope.launch { recentStore.save(next) }
    }

    /** «Повторить»: без списка — заново загрузить плейлисты, иначе поставить все каналы в очередь. */
    fun retry() {
        if (all.value.isEmpty()) load(fresh = true) else scheduler.retryAll()
    }

    /** Long-press → «Повторить проверку». */
    fun retryChannel(key: String) = scheduler.forceCheck(key)

    /** Настройки → «Перезапустить проверку каналов»: сброс результатов и очереди, плейлисты и данные остаются. */
    fun restartChecks() {
        viewModelScope.launch { scheduler.resetAll() }
    }

    // ---------- плеер ----------

    fun onPlayerOpened(key: String) {
        scheduler.playbackOpened()
        val st = scheduler.results.value[key]?.state
        if (st != CheckState.ALIVE) scheduler.forceCheck(key)
    }

    fun onPlaybackEvent(event: PlaybackEvent) = scheduler.onPlayback(event)

    fun onPlayerClosed() = scheduler.playbackClosed()

    // ---------- загрузка ----------

    private fun load(fresh: Boolean = false) {
        val prev = loadJob
        loadJob = viewModelScope.launch {
            prev?.cancelAndJoin()

            if (fresh) {
                phase.value = Phase.Loading
                all.value = emptyList()
                scheduler.resetAll()
                listCache.clear()
            }

            // 1) Есть кеш после предыдущего запуска — показываем сразу, без сети.
            val cachedList = if (fresh) emptyList() else listCache.load()
            if (cachedList.isNotEmpty()) {
                scheduler.restore(cachedList)
                all.value = cachedList
                phase.value = Phase.Ready
                scheduler.start()
                startRefreshLoop()
                syncPlaylist() // в фоне подтягиваем новые каналы из плейлистов
                return@launch
            }

            // 2) Первый запуск: загружаем плейлисты, сразу показываем полный список и запускаем проверку.
            phase.value = Phase.Loading
            val list = try {
                repository.load()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            if (list.isEmpty()) {
                phase.value = Phase.Error
                return@launch
            }

            scheduler.restore(list)
            all.value = list
            phase.value = Phase.Ready
            listCache.save(list)
            scheduler.start()
            startRefreshLoop()
        }
    }

    /** Периодически перечитывает плейлисты, пока приложение запущено. */
    private fun startRefreshLoop() {
        if (refreshJob?.isActive == true) return
        refreshJob = viewModelScope.launch {
            while (true) {
                delay(Config.PLAYLIST_REFRESH_MS)
                syncPlaylist()
            }
        }
    }

    /**
     * Тихо перечитывает плейлисты. Новые каналы добавляются и проверяются, пропавшие удаляются,
     * у изменившихся потоков результат отправляется на перепроверку. Интерфейс не блокируется.
     */
    private suspend fun syncPlaylist() {
        syncLock.withLock {
            val fresh = try {
                repository.load()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            if (fresh.isEmpty()) {
                syncPending = true
                return
            }
            syncPending = false
            scheduler.submitChannels(fresh)
            all.value = fresh
            listCache.save(fresh)
        }
    }
}
