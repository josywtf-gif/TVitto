package com.tvitto.app.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.tvitto.app.Config
import com.tvitto.app.data.AddResult
import com.tvitto.app.data.Categories
import com.tvitto.app.data.Channel
import com.tvitto.app.data.ChannelListCache
import com.tvitto.app.data.CheckCache
import com.tvitto.app.data.CheckResult
import com.tvitto.app.data.CheckScheduler
import com.tvitto.app.data.CheckState
import com.tvitto.app.data.FavoriteStore
import com.tvitto.app.data.LoadGovernor
import com.tvitto.app.data.Net
import com.tvitto.app.data.Phase
import com.tvitto.app.data.PlaybackEvent
import com.tvitto.app.data.PlaylistRepository
import com.tvitto.app.data.RecentEntry
import com.tvitto.app.data.RecentStore
import com.tvitto.app.data.Source
import com.tvitto.app.data.SourceStore
import com.tvitto.app.data.StreamChecker
import com.tvitto.app.data.StreamRatingStore
import com.tvitto.app.data.UiState
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.sample
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

class MainViewModel(app: Application) : AndroidViewModel(app) {

    private val appContext: Application = app
    private val repository = PlaylistRepository()
    private val governor = LoadGovernor(app)
    private val sourceStore = SourceStore(app)

    /**
     * Всё, что принадлежит одному источнику: свой планировщик проверок, свой кеш списка и проверок.
     * При смене источника сессия целиком заменяется (старая останавливается и сбрасывает кеш на диск).
     */
    private class Session(
        val source: Source,
        val scope: CoroutineScope,
        val scheduler: CheckScheduler,
        val listCache: ChannelListCache,
    ) {
        /** Результаты с диска уже загружены: только после этого безопасно писать кеш обратно. */
        @Volatile
        var restored = false
    }

    private val session = MutableStateFlow<Session?>(null)
    private val scheduler: CheckScheduler? get() = session.value?.scheduler

    private var recentStore = RecentStore(app)
    private var favoriteStore = FavoriteStore(app)
    private val favorites = MutableStateFlow<List<RecentEntry>>(emptyList())

    private val phase = MutableStateFlow(Phase.Loading)
    private val all = MutableStateFlow<List<Channel>>(emptyList())
    private val selected = MutableStateFlow(Categories.ALL)
    private val recent = MutableStateFlow<List<RecentEntry>>(emptyList())
    private val source = MutableStateFlow(Source.BUILTIN)
    private val selection = combine(selected, recent, favorites, source) { s, r, f, src -> QuadSelection(s, r, f, src) }

    private data class QuadSelection(val selected: String, val recent: List<RecentEntry>, val favorites: List<RecentEntry>, val source: Source)

    private val _hasCustom = MutableStateFlow(false)

    /** Есть ли сохранённый свой плейлист. */
    val hasCustom: StateFlow<Boolean> = _hasCustom.asStateFlow()

    private val results = session.flatMapLatest { s ->
        s?.scheduler?.results ?: flowOf(emptyMap<String, CheckResult>())
    }

    /** Оценка стабильности каналов (key → балл); пусто — статистики нет, порядок алфавитный. */
    private val stability = MutableStateFlow<Map<String, Double>>(emptyMap())
    private val statsTick = MutableStateFlow(0)

    private data class Meta(
        val initialDone: Boolean,
        val bgDone: Int,
        val bgTotal: Int,
        val online: Boolean,
        val stability: Map<String, Double>,
    )

    private val meta = session.flatMapLatest { sess ->
        if (sess == null) {
            flowOf(Meta(false, 0, 0, true, emptyMap()))
        } else {
            combine(sess.scheduler.initialDone, sess.scheduler.backlog, governor.online, stability) { done, backlog, online, stab ->
                Meta(done, backlog.first, backlog.second, online, stab)
            }
        }
    }

    /**
     * События плеера приходят из главного потока (в т.ч. на каждое переключение канала).
     * Планировщик берёт общий lock и копирует карту результатов — делаем это не в UI-потоке.
     * Один потребитель из очереди сохраняет порядок событий.
     */
    // Объявлено выше init: потребитель стартует в init.
    private val playbackEvents = kotlinx.coroutines.channels.Channel<PlaybackEvent>(kotlinx.coroutines.channels.Channel.UNLIMITED)

    private var loadJob: Job? = null
    private var refreshJob: Job? = null
    private var syncJob: Job? = null
    private val syncLock = Mutex()

    /** Не удалось обновить плейлисты в фоне — повторим при возвращении сети. */
    @Volatile
    private var syncPending = false

    /**
     * Видимые каналы.
     * Встроенный источник: подтверждённые alive и suspect, который раньше играл (серый индикатор);
     * непроверенные, никогда не игравшие suspect и dead скрыты, но остаются в кеше.
     * Свой источник: проверки нет — видны все каналы плейлиста, они запускаются сразу.
     * Обновляется по мере поступления результатов, вне главного потока.
     */
    val state: StateFlow<UiState> =
        combine(phase, all, results, selection, meta) { p, list, res, selectionTriple, m ->
            val sel = selectionTriple.selected
            val rec = selectionTriple.recent
            val fav = selectionTriple.favorites
            val src = selectionTriple.source
            val collected = ArrayList<Channel>(list.size)
            var checked = 0
            for (ch in list) {
                val r = res[ch.key]
                if (src == Source.CUSTOM) {
                    // Свой плейлист: ничего не скрываем; из результатов берём только рабочий поток.
                    val active = if (r != null && r.idx in ch.streams.indices) r.idx else 0
                    collected.add(
                        if (ch.state == CheckState.ALIVE && ch.active == active) ch
                        else ch.copy(active = active, state = CheckState.ALIVE),
                    )
                    checked++
                    continue
                }
                val st = r?.state ?: CheckState.UNKNOWN
                if (st != CheckState.UNKNOWN) checked++
                when (st) {
                    // В списке только подтверждённые каналы; сомнительным остаётся тот, что раньше играл.
                    CheckState.DEAD, CheckState.UNKNOWN -> Unit
                    CheckState.SUSPECT -> if (r?.wasAlive == true) {
                        val ri = r?.idx ?: -1
                        val active = if (ri in ch.streams.indices) ri else 0
                        collected.add(if (ch.state == st && ch.active == active) ch else ch.copy(active = active, state = st))
                    }
                    else -> {
                        val active = if (r != null && r.idx in ch.streams.indices) r.idx else 0
                        collected.add(if (ch.state == st && ch.active == active) ch else ch.copy(active = active, state = st))
                    }
                }
            }
            // Самые стабильные каналы — в самом верху; без статистики (0) — ниже них, с одними сбоями (<0) — в конце.
            // При равной оценке сохраняется алфавитный порядок (сортировка устойчива).
            val visible = if (m.stability.isEmpty()) collected else collected.sortedByDescending { m.stability[it.key] ?: 0.0 }

            // Один проход по видимым каналам вместо отдельных any/count/filter на каждую категорию.
            val counts = HashMap<String, Int>()
            for (ch in visible) counts[ch.category] = (counts[ch.category] ?: 0) + 1

            // Карту по ключам строим только если есть «Недавнее»/«Избранное».
            val byKey = if (rec.isEmpty() && fav.isEmpty()) emptyMap() else visible.associateBy { it.key }
            val recentVisible = rec.mapNotNull { byKey[it.key] }
            val favoriteVisible = fav.mapNotNull { byKey[it.key] }

            // Категории без видимых каналов скрываются.
            val present = Categories.ORDER.filter { (counts[it] ?: 0) > 0 }
            val effective = when {
                sel == Categories.ALL || sel == Categories.RECENT || sel == Categories.FAVORITES -> sel
                sel in present -> sel
                else -> Categories.ALL
            }
            val shown = when (effective) {
                Categories.ALL -> visible
                // «Недавнее»: порядок по свежести; недоступные сейчас каналы скрыты, но из хранилища не удаляются.
                Categories.RECENT -> recentVisible
                Categories.FAVORITES -> favoriteVisible
                else -> visible.filter { it.category == effective }
            }
            counts[Categories.ALL] = visible.size
            counts[Categories.RECENT] = recentVisible.size
            counts[Categories.FAVORITES] = favoriteVisible.size

            UiState(
                phase = p,
                channels = shown,
                categories = present,
                counts = counts,
                selected = effective,
                checked = checked,
                total = list.size,
                initialDone = m.initialDone,
                bgDone = m.bgDone,
                bgTotal = m.bgTotal,
                offline = !m.online,
                source = src,
            )
        }
            .sample(200)
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, UiState())

    init {
        viewModelScope.launch(Dispatchers.Default) {
            for (event in playbackEvents) scheduler?.onPlayback(event)
        }
        // Пересчёт оценок стабильности: при смене списка и после просмотра (статистика изменилась).
        viewModelScope.launch {
            combine(all, statsTick) { list, _ -> list }.collectLatest { list ->
                stability.value = if (list.isEmpty()) emptyMap() else withContext(Dispatchers.Default) {
                    StreamRatingStore.channelScores(appContext, list)
                }
            }
        }
        viewModelScope.launch {
            _hasCustom.value = sourceStore.hasCustom()
            activate(sourceStore.loadSource())
        }
        // Сеть вернулась: догружаем плейлисты, если не получилось раньше.
        viewModelScope.launch {
            governor.online.collect { online ->
                if (!online) return@collect
                if (phase.value == Phase.Error) {
                    activate(source.value)
                } else if (syncPending && phase.value == Phase.Ready) {
                    launchSync()
                }
            }
        }
    }

    /**
     * Дописывает результаты проверок на диск (уход приложения в фон): прогресс первой проверки
     * не теряется, даже если систему убьёт процесс, и после запуска проверка продолжится с того же места.
     */
    fun saveProgress() {
        val s = session.value ?: return
        if (!s.restored) return
        viewModelScope.launch(Dispatchers.IO) { s.scheduler.flush() }
    }

    override fun onCleared() {
        // viewModelScope к этому моменту уже отменён — сохраняем в отдельной корутине.
        session.value?.let { s ->
            if (s.restored) kotlinx.coroutines.CoroutineScope(Dispatchers.IO).launch { s.scheduler.flush() }
        }
        session.value?.scheduler?.stop()
        governor.close()
        super.onCleared()
    }

    fun selectCategory(name: String) {
        selected.value = name
    }

    /** Новый канал — в начало, дубликат переносится, хранится максимум 10 последних (отдельно для каждого источника). */
    fun addRecent(channel: Channel) {
        val entry = RecentEntry(channel.key, channel.name, channel.logo)
        val next = (listOf(entry) + recent.value.filter { it.key != channel.key })
            .take(Config.RECENT_LIMIT)
        recent.value = next
        scheduler?.setRecent(next.map { it.key })
        val store = recentStore
        viewModelScope.launch { store.save(next) }
    }

    fun toggleFavorite(channel: Channel) {
        val current = favorites.value
        val next = if (current.any { it.key == channel.key }) current.filterNot { it.key == channel.key }
        else listOf(RecentEntry(channel.key, channel.name, channel.logo)) + current
        favorites.value = next
        val store = favoriteStore
        viewModelScope.launch { store.save(next) }
    }

    fun isFavorite(key: String): Boolean = favorites.value.any { it.key == key }

    /** «Повторить»: без списка — заново загрузить плейлисты, иначе поставить все каналы в очередь. */
    fun retry() {
        if (all.value.isEmpty()) activate(source.value, fresh = true) else scheduler?.retryAll()
    }

    /** Long-press → «Повторить проверку». */
    fun retryChannel(key: String) {
        scheduler?.forceCheck(key)
    }

    /** Настройки → «Перезапустить проверку каналов»: сброс результатов и очереди, плейлисты и данные остаются. */
    fun restartChecks() {
        viewModelScope.launch { scheduler?.resetAll() }
    }

    // ---------- выбор источника ----------

    /** «Встроенный»: переключение в фоне, интерфейс не блокируется (пока грузится — скелетон). */
    fun selectBuiltin() {
        if (source.value == Source.BUILTIN && session.value != null) return
        viewModelScope.launch {
            sourceStore.saveSource(Source.BUILTIN)
            activate(Source.BUILTIN)
        }
    }

    /** Вернуться к уже сохранённому своему плейлисту без повторного добавления. */
    fun useSavedCustom() {
        if (source.value == Source.CUSTOM && session.value != null) return
        viewModelScope.launch {
            if (!sourceStore.hasCustom()) return@launch
            sourceStore.saveSource(Source.CUSTOM)
            activate(Source.CUSTOM)
        }
    }

    /**
     * «Добавить свой»: [raw] — ссылка на M3U или само содержимое. Плейлист проверяется на разбор,
     * сохраняется, кеш своего источника сбрасывается, и источник переключается на свой.
     * Вызывается и с экрана телефона, и с потока локального HTTP-сервера на ТВ.
     */
    suspend fun addCustomPlaylist(raw: String): AddResult = withContext(Dispatchers.IO) {
        val input = raw.trim()
        if (input.isEmpty()) return@withContext AddResult.Error("Введите ссылку или содержимое плейлиста")

        val isUrl = !input.contains('\n') &&
            (input.startsWith("http://", ignoreCase = true) || input.startsWith("https://", ignoreCase = true))
        val text: String = if (isUrl) {
            repository.fetchText(input)
                ?: return@withContext AddResult.Error("Не удалось загрузить плейлист по ссылке")
        } else {
            input
        }

        val list = try {
            repository.parseText(text)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
        if (list.isEmpty()) {
            return@withContext AddResult.Error("В плейлисте не найдено каналов (нужен формат M3U с #EXTINF)")
        }

        sourceStore.saveCustom(text, if (isUrl) input else null)
        sourceStore.saveSource(Source.CUSTOM)
        _hasCustom.value = true
        // invalidate = true: кеш списка и проверок своего источника сбрасывается — плейлист изменился.
        activate(Source.CUSTOM, invalidate = true)
        AddResult.Ok(list.size)
    }

    // ---------- плеер ----------

    fun onPlayerOpened(key: String) {
        val sch = scheduler ?: return
        sch.playbackOpened()
        val st = sch.results.value[key]?.state
        if (st != CheckState.ALIVE) sch.forceCheck(key)
    }

    fun onPlaybackEvent(event: PlaybackEvent) {
        playbackEvents.trySend(event)
    }

    fun onPlayerClosed() {
        scheduler?.playbackClosed()
        // Статистика сегмента дописывается при закрытии плеера — пересчитываем порядок чуть позже.
        viewModelScope.launch {
            delay(1000)
            statsTick.value++
        }
    }

    // ---------- загрузка и смена источника ----------

    /**
     * Активирует источник: останавливает прежнюю сессию, поднимает новую со своими кешами и грузит список.
     * Всё выполняется в корутинах — главный поток не блокируется, пока идёт загрузка, показывается скелетон.
     *
     * @param fresh      заново загрузить плейлист и сбросить результаты (кнопка «Повторить» при пустом списке)
     * @param invalidate сбросить кеш списка и проверок источника (плейлист изменился)
     */
    @Synchronized
    private fun activate(requested: Source, fresh: Boolean = false, invalidate: Boolean = false) {
        val prev = loadJob
        loadJob = viewModelScope.launch {
            prev?.cancelAndJoin()

            // Сразу очищаем экран: старые каналы другого источника не должны мелькать.
            phase.value = Phase.Loading
            all.value = emptyList()
            retireSession()

            // Своего плейлиста нет (например, файл удалён) — остаёмся на встроенном.
            val src = if (requested == Source.CUSTOM && !sourceStore.hasCustom()) Source.BUILTIN else requested
            if (src != requested) sourceStore.saveSource(src)
            _hasCustom.value = sourceStore.hasCustom()

            selected.value = Categories.ALL
            source.value = src
            syncPending = false

            val s = newSession(src)
            if (invalidate) {
                CheckCache(appContext, src.cacheTag).clear()
                s.listCache.clear()
            }

            // «Недавнее» у каждого источника своё.
            recentStore = RecentStore(appContext, src.cacheTag)
            favoriteStore = FavoriteStore(appContext, src.cacheTag)
            recent.value = recentStore.load().take(Config.RECENT_LIMIT)
            favorites.value = favoriteStore.load()

            session.value = s
            s.scheduler.setRecent(recent.value.map { it.key })

            when (src) {
                Source.BUILTIN -> loadBuiltin(s, fresh)
                Source.CUSTOM -> loadCustom(s)
            }
        }
    }

    private fun newSession(src: Source): Session {
        val scope = CoroutineScope(SupervisorJob(viewModelScope.coroutineContext[Job]) + Dispatchers.Default)
        val scheduler = CheckScheduler(
            scope = scope,
            checker = StreamChecker(appContext, Net.client, governor),
            store = CheckCache(appContext, src.cacheTag),
            governor = governor,
            // Свой плейлист не проверяется: каналы запускаются сразу.
            passive = src == Source.CUSTOM,
        )
        return Session(src, scope, scheduler, ChannelListCache(appContext, src.cacheTag))
    }

    /** Останавливает текущую сессию: фоновые задачи отменяются, результаты проверок дописываются на диск. */
    private suspend fun retireSession() {
        refreshJob?.cancel()
        refreshJob = null
        syncJob?.cancel()
        syncJob = null
        val old = session.value ?: return
        session.value = null
        old.scheduler.stop()
        if (old.restored) withContext(NonCancellable) { old.scheduler.flush() }
        old.scope.cancel()
        governor.playing = false
        governor.buffering = false
    }

    /** Встроенный: кеш списка и проверок показывается мгновенно, синхронизация и проверка идут в фоне. */
    private suspend fun loadBuiltin(s: Session, fresh: Boolean) {
        if (fresh) {
            s.scheduler.resetAll()
            s.listCache.clear()
        }

        // 1) Есть кеш после предыдущего запуска — показываем сразу, без сети.
        val cachedList = if (fresh) emptyList() else s.listCache.load()
        if (cachedList.isNotEmpty()) {
            s.scheduler.restore(cachedList)
            s.restored = true
            all.value = cachedList
            phase.value = Phase.Ready
            s.scheduler.start()
            startRefreshLoop(s)
            syncPlaylist(s) // в фоне подтягиваем новые каналы из плейлистов
            return
        }

        // 2) Первый запуск: загружаем плейлисты, сразу показываем полный список и запускаем проверку.
        val list = try {
            repository.load()
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyList()
        }
        if (list.isEmpty()) {
            phase.value = Phase.Error
            return
        }

        s.scheduler.restore(list)
        s.restored = true
        all.value = list
        phase.value = Phase.Ready
        s.listCache.save(list)
        s.scheduler.start()
        startRefreshLoop(s)
    }

    /** Свой: список из сохранённого текста (или кеша), без проверки каналов; ссылка, если была, обновляется в фоне. */
    private suspend fun loadCustom(s: Session) {
        var list = s.listCache.load()
        if (list.isEmpty()) {
            val text = sourceStore.loadCustomText()
            list = if (text == null) {
                emptyList()
            } else {
                try {
                    repository.parseText(text)
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    emptyList()
                }
            }
            if (list.isNotEmpty()) s.listCache.save(list)
        }
        if (list.isEmpty()) {
            phase.value = Phase.Error
            return
        }

        s.scheduler.restore(list)
        s.restored = true
        all.value = list
        phase.value = Phase.Ready
        s.scheduler.start()
        if (sourceStore.loadUrl() != null) {
            startRefreshLoop(s)
            syncPlaylist(s)
        }
    }

    /** Периодически перечитывает плейлисты, пока приложение запущено. */
    private fun startRefreshLoop(s: Session) {
        refreshJob?.cancel()
        refreshJob = viewModelScope.launch {
            while (true) {
                delay(Config.PLAYLIST_REFRESH_MS)
                if (session.value !== s) return@launch
                syncPlaylist(s)
            }
        }
    }

    private fun launchSync() {
        syncJob?.cancel()
        syncJob = viewModelScope.launch {
            session.value?.let { syncPlaylist(it) }
        }
    }

    private suspend fun syncPlaylist(s: Session) {
        when (s.source) {
            Source.BUILTIN -> syncBuiltin(s)
            Source.CUSTOM -> syncCustom(s)
        }
    }

    /**
     * Тихо перечитывает встроенные плейлисты. Новые каналы добавляются и проверяются, пропавшие удаляются,
     * у изменившихся потоков результат отправляется на перепроверку. Интерфейс не блокируется.
     */
    private suspend fun syncBuiltin(s: Session) {
        syncLock.withLock {
            val fresh = try {
                repository.load()
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                emptyList()
            }
            // Пока грузили, источник могли сменить — результат тогда не нужен.
            if (session.value !== s) return
            if (fresh.isEmpty()) {
                syncPending = true
                return
            }
            syncPending = false
            s.scheduler.submitChannels(fresh)
            all.value = fresh
            s.listCache.save(fresh)
        }
    }

    /** Свой плейлист, добавленный ссылкой: если содержимое изменилось — кеш источника сбрасывается и список обновляется. */
    private suspend fun syncCustom(s: Session) {
        val url = sourceStore.loadUrl() ?: return
        syncLock.withLock {
            val text = repository.fetchText(url)
            if (session.value !== s) return
            if (text == null) {
                syncPending = true
                return
            }
            syncPending = false
            if (text == sourceStore.loadCustomText()) return
            val fresh = repository.parseText(text)
            if (fresh.isEmpty()) return
            sourceStore.saveCustom(text, url)
            s.scheduler.resetAll() // кеш проверок/рабочих потоков устарел вместе с плейлистом
            s.scheduler.submitChannels(fresh)
            all.value = fresh
            s.listCache.save(fresh)
        }
    }
}
