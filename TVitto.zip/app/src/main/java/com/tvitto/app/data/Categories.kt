package com.tvitto.app.data

/** Русские категории каналов и маппинг `group-title` (и названия канала) → категория. */
object Categories {

    const val ALL = "Все"

    /** Виртуальная категория: последние просмотренные каналы. */
    const val RECENT = "Недавние"
    const val MOVIES = "Кино"
    const val MUSIC = "Музыка"
    const val NEWS = "Новости"
    const val SPORT = "Спорт"
    const val KIDS = "Дети"
    const val KNOWLEDGE = "Познавательное"
    const val ENTERTAINMENT = "Развлечения"
    const val OTHER = "Другое"

    /** Порядок вкладок. */
    val ORDER = listOf(MOVIES, MUSIC, NEWS, SPORT, KIDS, KNOWLEDGE, ENTERTAINMENT, OTHER)

    /** Порядок важен: первое совпадение побеждает. */
    private val RULES: List<Pair<String, List<String>>> = listOf(
        KIDS to listOf(
            "kids", "children", "child", "animation", "cartoon", "family",
            "детск", "дети", "детей", "мульт", "малыш",
        ),
        MUSIC to listOf(
            "music", "mtv", "музык", "муз-тв", "муз тв", "музтв",
        ),
        NEWS to listOf(
            "news", "business", "legislative", "weather",
            "новост", "вести", "рбк", "погода",
        ),
        SPORT to listOf(
            "sport", "football", "hockey", "soccer", "boxing", "ufc",
            "спорт", "матч", "футбол", "хоккей", "бокс",
        ),
        MOVIES to listOf(
            "movie", "film", "cinema", "series", "classic", "serial",
            "кино", "фильм", "сериал", "детектив", "боевик", "мелодрам", "комеди",
        ),
        KNOWLEDGE to listOf(
            "documentary", "education", "science", "culture", "travel", "cooking",
            "nature", "history", "discovery", "geographic", "animal", "viasat",
            "документ", "познават", "наука", "образован", "истори", "путешеств",
            "планета", "кулинар", "природ",
        ),
        ENTERTAINMENT to listOf(
            "entertainment", "comedy", "lifestyle", "general", "shop", "interactive",
            "relax", "show",
            "развлек", "юмор", "шоу", "досуг",
        ),
    )

    fun map(group: String?, name: String): String {
        val g = group?.lowercase()?.trim().orEmpty()
        if (g.isNotEmpty() && g != "undefined") {
            for ((category, keys) in RULES) {
                if (keys.any { g.contains(it) }) return category
            }
        }
        // group-title часто пустой или Undefined — пробуем по названию канала.
        val n = name.lowercase()
        for ((category, keys) in RULES) {
            if (keys.any { n.contains(it) }) return category
        }
        return OTHER
    }
}
