package com.tvitto.app.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.tvitto.app.data.AddResult
import com.tvitto.app.data.LocalNet
import com.tvitto.app.data.PlaylistServer
import com.tvitto.app.data.Source
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import java.io.IOException

@Composable
private fun ScreenHeader(title: String, onBack: () -> Unit, backFocus: FocusRequester? = null) {
    val isTv = LocalIsTv.current
    Row(verticalAlignment = Alignment.CenterVertically) {
        TvButton(
            text = "← Назад",
            onClick = onBack,
            modifier = if (backFocus != null) Modifier.focusRequester(backFocus) else Modifier,
        )
        Spacer(Modifier.width(18.dp))
        Text(
            text = title,
            color = Color.White,
            fontSize = if (isTv) 30.sp else 22.sp,
            fontWeight = FontWeight.ExtraBold,
        )
    }
}

/** Настройки → «Выбор источника»: «Встроенный» или «Добавить свой». */
@Composable
fun SourceScreen(
    current: Source,
    hasCustom: Boolean,
    onBack: () -> Unit,
    onBuiltin: () -> Unit,
    onAddCustom: () -> Unit,
) {
    val isTv = LocalIsTv.current
    val firstFocus = remember { FocusRequester() }

    BackHandler(onBack = onBack)
    LaunchedEffect(Unit) {
        if (isTv) {
            delay(150)
            runCatching { firstFocus.requestFocus() }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = if (isTv) 48.dp else 20.dp, vertical = 20.dp),
    ) {
        ScreenHeader(title = "Выбор источника", onBack = onBack)
        Spacer(Modifier.height(28.dp))

        SourceOption(
            title = "Встроенный",
            subtitle = "Плейлист из приложения. Каналы проверяются, недоступные скрываются.",
            selected = current == Source.BUILTIN,
            onClick = onBuiltin,
            modifier = Modifier.focusRequester(firstFocus),
        )
        Spacer(Modifier.height(12.dp))
        SourceOption(
            title = "Добавить свой",
            subtitle = when {
                current == Source.CUSTOM -> "Сейчас используется свой плейлист. Нажмите, чтобы заменить."
                hasCustom -> "Есть сохранённый плейлист. Нажмите, чтобы добавить другой или вернуться к нему."
                else -> "Ссылка на M3U или его содержимое. Каналы запускаются сразу, без проверки."
            },
            selected = current == Source.CUSTOM,
            onClick = onAddCustom,
        )
    }
}

@Composable
private fun SourceOption(
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
    FocusSurface(
        onClick = onClick,
        modifier = modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        containerColor = if (selected) Color(0x3322D3FF) else Color(0x14FFFFFF),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text(
                    text = title,
                    color = if (selected) Cyan else Color.White,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    text = subtitle,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 14.sp,
                )
            }
            if (selected) {
                Spacer(Modifier.width(12.dp))
                Text("✓", color = Cyan, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * Экран добавления своего плейлиста.
 * ТВ: поднимается локальный HTTP-сервер, на экране — адрес для телефона.
 * Телефон: поле «Добавить плейлист» прямо в приложении, без сервера.
 */
@Composable
fun AddPlaylistScreen(
    hasCustom: Boolean,
    onBack: () -> Unit,
    onSubmit: suspend (String) -> AddResult,
    onUseSaved: () -> Unit,
    onDone: () -> Unit,
) {
    BackHandler(onBack = onBack)
    if (LocalIsTv.current) {
        TvAddContent(hasCustom, onBack, onSubmit, onUseSaved, onDone)
    } else {
        PhoneAddContent(hasCustom, onBack, onSubmit, onUseSaved, onDone)
    }
}

@Composable
private fun TvAddContent(
    hasCustom: Boolean,
    onBack: () -> Unit,
    onSubmit: suspend (String) -> AddResult,
    onUseSaved: () -> Unit,
    onDone: () -> Unit,
) {
    val currentSubmit by rememberUpdatedState(onSubmit)
    var address by remember { mutableStateOf<String?>(null) }
    var failure by remember { mutableStateOf<String?>(null) }
    var result by remember { mutableStateOf<AddResult?>(null) }
    val backFocus = remember { FocusRequester() }

    // Сервер живёт только пока открыт этот экран.
    val server = remember {
        PlaylistServer { text ->
            // Вызывается на потоке сервера, не на главном.
            val r = runBlocking { currentSubmit(text) }
            result = r
            when (r) {
                is AddResult.Ok -> PlaylistServer.Reply(true, "Готово! Каналов добавлено: ${r.channels}. Смотрите на телевизор.")
                is AddResult.Error -> PlaylistServer.Reply(false, r.message)
            }
        }
    }
    DisposableEffect(Unit) { onDispose { server.close() } }

    LaunchedEffect(Unit) {
        val port = withContext(Dispatchers.IO) {
            try {
                server.start()
            } catch (e: IOException) {
                null
            }
        }
        if (port == null) {
            failure = "Не удалось запустить сервер на телевизоре"
        } else {
            val ip = withContext(Dispatchers.IO) { LocalNet.localIpv4() }
            if (ip == null) failure = "Телевизор не подключён к локальной сети" else address = "http://$ip:$port"
        }
    }
    LaunchedEffect(Unit) {
        delay(150)
        runCatching { backFocus.requestFocus() }
    }
    // Плейлист пришёл с телефона: показываем результат и возвращаемся к списку каналов.
    LaunchedEffect(result) {
        if (result is AddResult.Ok) {
            delay(1500)
            onDone()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 48.dp, vertical = 20.dp),
    ) {
        ScreenHeader(title = "Добавить свой плейлист", onBack = onBack, backFocus = backFocus)
        Spacer(Modifier.height(36.dp))

        Text(
            text = "Открой на телефоне",
            color = Color.White,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
        )
        Spacer(Modifier.height(10.dp))
        val shownFailure = failure
        Text(
            text = address ?: shownFailure ?: "Запускаем сервер…",
            color = if (shownFailure != null && address == null) MaterialTheme.colorScheme.error else Cyan,
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold,
        )
        Spacer(Modifier.height(14.dp))
        Text(
            text = "Телефон и телевизор должны быть в одной сети Wi-Fi. На открывшейся странице " +
                "вставьте ссылку на плейлист (.m3u) или его содержимое в поле «Добавить плейлист» и нажмите «Добавить».",
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            fontSize = 17.sp,
        )

        val r = result
        if (r != null) {
            Spacer(Modifier.height(20.dp))
            when (r) {
                is AddResult.Ok -> Text(
                    "Плейлист добавлен, каналов: ${r.channels}",
                    color = Cyan,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                )
                is AddResult.Error -> Text(
                    r.message,
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 18.sp,
                )
            }
        }

        if (hasCustom) {
            Spacer(Modifier.height(28.dp))
            TvButton(text = "Использовать сохранённый плейлист", onClick = onUseSaved)
        }
    }
}

@Composable
private fun PhoneAddContent(
    hasCustom: Boolean,
    onBack: () -> Unit,
    onSubmit: suspend (String) -> AddResult,
    onUseSaved: () -> Unit,
    onDone: () -> Unit,
) {
    val scope = rememberCoroutineScope()
    val clipboard = LocalClipboardManager.current
    var text by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun submit() {
        if (busy) return
        busy = true
        error = null
        scope.launch {
            when (val r = onSubmit(text)) {
                is AddResult.Ok -> {
                    busy = false
                    onDone()
                }
                is AddResult.Error -> {
                    busy = false
                    error = r.message
                }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
        ScreenHeader(title = "Свой плейлист", onBack = onBack)
        Spacer(Modifier.height(20.dp))

        OutlinedTextField(
            value = text,
            onValueChange = {
                text = it
                error = null
            },
            modifier = Modifier.fillMaxWidth(),
            label = { Text("Добавить плейлист") },
            placeholder = { Text("Ссылка на .m3u или содержимое плейлиста") },
            minLines = 6,
            maxLines = 12,
            enabled = !busy,
            isError = error != null,
        )

        error?.let {
            Spacer(Modifier.height(8.dp))
            Text(it, color = MaterialTheme.colorScheme.error, fontSize = 14.sp)
        }
        if (busy) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(modifier = Modifier.fillMaxWidth(), color = Cyan)
        }

        Spacer(Modifier.height(16.dp))
        Row {
            TvButton(
                text = "Вставить",
                onClick = {
                    clipboard.getText()?.text?.let {
                        text = it
                        error = null
                    }
                },
            )
            Spacer(Modifier.width(12.dp))
            TvButton(
                text = if (busy) "Добавляем…" else "Добавить",
                onClick = { submit() },
                primary = true,
            )
        }

        if (hasCustom) {
            Spacer(Modifier.height(16.dp))
            TvButton(text = "Использовать сохранённый", onClick = onUseSaved)
        }
    }
}
