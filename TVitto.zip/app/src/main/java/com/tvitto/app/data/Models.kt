package com.tvitto.app.data

import androidx.compose.runtime.Immutable

@Immutable
data class StreamSource(
    val url: String,
    val referrer: String? = null,
    val userAgent: String? = null,
)

/**
 * Канал. [streams] — все найденные потоки (после объединения плейлистов),
 * [active] — индекс потока, который прошёл проверку, [category] — русская категория.
 */
@Immutable
data class Channel(
    val key: String,
    val name: String,
    val logo: String?,
    val group: String?,
    val category: String,
    val streams: List<StreamSource>,
    val active: Int = 0,
)

/** Результат проверки: [idx] — индекс рабочего потока или -1, [ts] — время проверки. */
@Immutable
data class CheckResult(val idx: Int, val ts: Long)

enum class Phase { Loading, Error, Ready }

@Immutable
data class UiState(
    val phase: Phase = Phase.Loading,
    /** Рабочие каналы выбранной категории (по алфавиту). */
    val channels: List<Channel> = emptyList(),
    /** Категории, в которых есть рабочие каналы (без «Все»). */
    val categories: List<String> = emptyList(),
    val selected: String = Categories.ALL,
    val checked: Int = 0,
    val total: Int = 0,
    val checking: Boolean = false,
) {
    val settled: Boolean get() = !checking && checked >= total
}
