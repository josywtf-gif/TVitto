package com.tvitto.app.data

import androidx.compose.runtime.Immutable
import java.security.MessageDigest

@Immutable
data class StreamSource(
    val url: String,
    val referrer: String? = null,
    val userAgent: String? = null,
)

/** Состояние проверки канала. */
enum class CheckState { UNKNOWN, ALIVE, SUSPECT, DEAD }

/**
 * Канал. [streams] — все найденные потоки (после объединения плейлистов),
 * [active] — индекс рабочего потока, [state] — результат проверки, [category] — русская категория.
 */
@Immutable
data class Channel(
    val key: String,
    val name: String,
    val logo: String?,
    val group: String?,
    val category: String,
    val streams: List<StreamSource>,
    val active: Int = 0,
    val state: CheckState = CheckState.UNKNOWN,
)

/** Подпись потоков канала: меняется, если изменились URL или заголовки. */
fun Channel.signature(): String {
    val md = MessageDigest.getInstance("MD5")
    for (s in streams) {
        md.update(s.url.toByteArray())
        md.update(0.toByte())
        md.update((s.referrer ?: "").toByteArray())
        md.update(0.toByte())
        md.update((s.userAgent ?: "").toByteArray())
        md.update(1.toByte())
    }
    return md.digest().joinToString("") { "%02x".format(it) }
}

/** Запись «Недавних»: ключ канала + имя и логотип на момент просмотра (запасные данные). */
@Immutable
data class RecentEntry(val key: String, val name: String, val logo: String?)

/**
 * Результат проверки. [idx] — индекс рабочего потока или -1, [checkedAt]/[nextCheckAt] — время проверки
 * и следующей проверки, [failStreak] — неудач подряд, [firstFailAt] — время первой из них,
 * [sig] — подпись потоков, для которых получен результат.
 */
@Immutable
data class CheckResult(
    val state: CheckState,
    val idx: Int,
    val checkedAt: Long,
    val nextCheckAt: Long,
    val failStreak: Int,
    val firstFailAt: Long = 0L,
    val sig: String = "",
    /** Канал хотя бы раз подтверждался рабочим: единичный сбой не прячет его из списка. */
    val wasAlive: Boolean = false,
)

/** События плеера для планировщика проверок. */
sealed interface PlaybackEvent {
    /** Открыт/переключён канал; [neighbors] — ключи соседей (i-1, i+1, i+2). */
    data class Opened(val key: String, val neighbors: List<String>) : PlaybackEvent

    /** Активный поток начал/закончил буферизацию. */
    data class Buffering(val on: Boolean) : PlaybackEvent

    /** Поток реально заиграл ([streamIndex] — индекс потока в канале). */
    data class Ready(val key: String, val streamIndex: Int) : PlaybackEvent

    /** Таймаут запуска или длительный обрыв. */
    data class Timeout(val key: String) : PlaybackEvent

    /** Ошибка воспроизведения всех потоков канала. */
    data class Failed(val key: String) : PlaybackEvent
}

enum class Phase { Loading, Error, Ready }

@Immutable
data class UiState(
    val phase: Phase = Phase.Loading,
    /** Видимые каналы выбранной категории (alive/suspect/unknown, по алфавиту). dead скрыты. */
    val channels: List<Channel> = emptyList(),
    /** Категории, в которых есть видимые каналы (без «Все» и «Недавнее»). */
    val categories: List<String> = emptyList(),
    /** Количество видимых каналов: по категориям, «Все» и «Недавнее». */
    val counts: Map<String, Int> = emptyMap(),
    val selected: String = Categories.ALL,
    /** Сколько каналов хранится в «Недавнем» (включая скрытые dead). */
    val recentTotal: Int = 0,
    /** Сколько каналов уже проверено хотя бы раз / всего. */
    val checked: Int = 0,
    val total: Int = 0,
    /** Первоначальная проверка завершена (баннер прогресса больше не нужен). */
    val initialDone: Boolean = false,
    /** Прогресс явной перепроверки («Повторить»); bgTotal = 0 — перепроверки нет. */
    val bgDone: Int = 0,
    val bgTotal: Int = 0,
    val offline: Boolean = false,
    /** Активный источник плейлиста. */
    val source: Source = Source.BUILTIN,
)
