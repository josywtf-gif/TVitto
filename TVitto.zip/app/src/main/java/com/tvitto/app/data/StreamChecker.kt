package com.tvitto.app.data

import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException

class StreamChecker(private val client: OkHttpClient) {

    /** Индекс первого рабочего потока канала или -1, если не отвечает ни один. */
    suspend fun firstWorking(channel: Channel): Int {
        for (i in channel.streams.indices) {
            if (probe(channel.streams[i])) return i
        }
        return -1
    }

    private suspend fun probe(stream: StreamSource): Boolean =
        try {
            runInterruptible(Dispatchers.IO) { probeBlocking(stream) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }

    /** HEAD; если сервер его не поддерживает — GET с Range: bytes=0-0. */
    private fun probeBlocking(stream: StreamSource): Boolean {
        val head: Boolean? = try {
            client.newCall(request(stream, head = true)).execute().use { r ->
                if (r.isSuccessful) !r.isHtml() else null
            }
        } catch (e: InterruptedIOException) {
            return false // таймаут или отмена
        } catch (e: IOException) {
            null
        }
        if (head != null) return head

        return client.newCall(request(stream, head = false)).execute().use { r ->
            (r.code == 200 || r.code == 206) && !r.isHtml()
        }
    }

    private fun request(stream: StreamSource, head: Boolean): Request {
        val builder = Request.Builder()
            .url(stream.url)
            .header("User-Agent", stream.userAgent ?: Config.DEFAULT_UA)
            .header("Accept", "*/*")
        stream.referrer?.let { builder.header("Referer", it) }
        return if (head) {
            builder.head().build()
        } else {
            builder.header("Range", "bytes=0-0").get().build()
        }
    }

    private fun Response.isHtml(): Boolean =
        header("Content-Type")?.contains("text/html", ignoreCase = true) == true
}
