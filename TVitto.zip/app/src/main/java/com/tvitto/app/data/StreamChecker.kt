package com.tvitto.app.data

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.android.asCoroutineDispatcher
import kotlinx.coroutines.delay
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.net.ConnectException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/**
 * Двухуровневая проверка канала.
 * Уровень 1 (сеть): HEAD, при неподдержке или ошибке — GET с Range: bytes=0-0; с User-Agent и Referer потока.
 * Уровень 2 (поток): фоновый ExoPlayer без экрана и звука должен дойти до STATE_READY.
 * ExoPlayer запускается только после сетевой проверки и только если [LoadGovernor] разрешает;
 * иначе канал оценивается по сети. Планирование, очередь и параллельность — в [CheckScheduler].
 */
class StreamChecker(
    context: Context,
    private val client: OkHttpClient,
    private val governor: LoadGovernor,
) {
    private enum class Probe { OK, HARD, SOFT }

    private val appContext = context.applicationContext

    private val probeThread: HandlerThread by lazy {
        HandlerThread("tvitto-probe", Process.THREAD_PRIORITY_BACKGROUND).apply { start() }
    }
    private val probeDispatcher by lazy {
        Handler(probeThread.looper).asCoroutineDispatcher("tvitto-probe")
    }

    /** Индекс первого реально рабочего потока канала (из первых двух), -1 или [INCONCLUSIVE]. */
    suspend fun check(channel: Channel): Int {
        val limit = minOf(channel.streams.size, Config.MAX_STREAMS_PER_CHANNEL)
        var inconclusive = false
        for (i in 0 until limit) {
            val stream = channel.streams[i]
            val net = probeNetwork(stream)
            if (net == Probe.HARD) continue
            when (probeStream(stream)) {
                true -> return i
                false -> continue
                null -> if (net == Probe.OK) return i else inconclusive = true
            }
        }
        // Без ExoPlayer неоднозначный ответ сети (403, 405, таймаут) не доказывает неработоспособность.
        return if (inconclusive) INCONCLUSIVE else -1
    }

    // ---------- уровень 1: сеть ----------

    private suspend fun probeNetwork(stream: StreamSource): Probe =
        try {
            runInterruptible(Dispatchers.IO) { probeNetworkBlocking(stream) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Probe.SOFT
        }

    private fun probeNetworkBlocking(stream: StreamSource): Probe {
        val head: Probe? = try {
            client.newCall(request(stream, head = true)).execute().use { r -> classify(r, sniff = false) }
        } catch (e: IOException) {
            null
        }
        if (head == Probe.OK) return Probe.OK

        // HEAD не поддерживается или завершился ошибкой — уточняем GET с Range.
        return try {
            client.newCall(request(stream, head = false)).execute().use { r -> classify(r, sniff = true) }
        } catch (e: IOException) {
            classifyError(e)
        }
    }

    private fun request(stream: StreamSource, head: Boolean): Request {
        val builder = Request.Builder()
            .url(stream.url)
            .header("User-Agent", stream.userAgent ?: Config.DEFAULT_UA)
            .header("Accept", "*/*")
        stream.referrer?.let { builder.header("Referer", it) }
        return if (head) {
            builder.head().build()
        } else {
            builder.header("Range", "bytes=0-0").get().build()
        }
    }

    /**
     * HTTP-код, Content-Type и (для GET) начало тела.
     * 404/410 и HTML вместо потока — явные признаки проблемы (HARD); 403, 405, 429, 5xx и прочее —
     * неоднозначно (SOFT): такой поток ещё может играть, это решает уровень 2.
     */
    private fun classify(r: Response, sniff: Boolean): Probe {
        val code = r.code
        if (code == 416) return Probe.OK // Range не поддержан, но ресурс есть
        if (code !in 200..299) {
            return if (code == 404 || code == 410) Probe.HARD else Probe.SOFT
        }
        val ct = r.header("Content-Type")?.lowercase()
        if (ct != null && BAD_TYPES.any { ct.contains(it) }) return Probe.HARD
        if (sniff && looksLikeHtml(r)) return Probe.HARD
        return Probe.OK
    }

    private fun looksLikeHtml(r: Response): Boolean {
        return try {
            val src = r.body?.source() ?: return false
            src.request(16)
            val n = minOf(src.buffer.size, 64L).toInt()
            if (n == 0) return false
            val head = src.buffer.snapshot(n).utf8().trimStart().lowercase()
            head.startsWith("<!doctype html") || head.startsWith("<html")
        } catch (e: IOException) {
            false
        }
    }

    private fun classifyError(e: IOException): Probe = when (e) {
        is UnknownHostException, is ConnectException, is SSLException -> Probe.HARD
        else -> Probe.SOFT
    }

    // ---------- уровень 2: реальный поток ----------

    /** true/false — результат ExoPlayer, null — ExoPlayer сейчас недопустим (оценка только по сети). */
    private suspend fun probeStream(stream: StreamSource): Boolean? {
        while (true) {
            if (!governor.exoAllowed()) return null
            if (governor.tryAcquireExo()) break
            delay(200)
        }
        try {
            if (!governor.exoAllowed()) return null
            return runProbe(stream)
        } finally {
            governor.releaseExo()
        }
    }

    /**
     * Headless ExoPlayer на отдельном потоке: без поверхности и звука (volume 0, playWhenReady=false).
     * READY означает, что плеер реально прочитал и разобрал первые данные потока. Всегда освобождается.
     */
    private suspend fun runProbe(stream: StreamSource): Boolean =
        withContext(probeDispatcher) {
            val player = ExoPlayer.Builder(appContext)
                .setLooper(probeThread.looper)
                .setLoadControl(
                    DefaultLoadControl.Builder()
                        .setBufferDurationsMs(1500, 4000, 800, 800)
                        .build(),
                )
                .build()
            val result = CompletableDeferred<Boolean>()
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) result.complete(true)
                }

                override fun onPlayerError(error: PlaybackException) {
                    result.complete(false)
                }
            }
            try {
                player.addListener(listener)
                player.volume = 0f
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setForceLowestBitrate(true)
                    .build()
                player.setMediaSource(buildMediaSource(appContext, stream))
                player.playWhenReady = false
                player.prepare()
                withTimeoutOrNull(Config.STREAM_PROBE_TIMEOUT_MS) { result.await() } == true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            } finally {
                player.removeListener(listener)
                player.release()
            }
        }

    companion object {
        /** Ответ неоднозначен, а уровень 2 сейчас недоступен: состояние канала менять нельзя. */
        const val INCONCLUSIVE = -2

        private val BAD_TYPES = listOf("text/html", "application/json", "image/", "javascript", "text/css")
    }
}
