package com.tvitto.app.data

import android.content.Context
import android.graphics.ImageFormat
import android.media.Image
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.audio.AudioCapabilities
import androidx.media3.exoplayer.audio.AudioSink
import androidx.media3.exoplayer.audio.DefaultAudioSink
import androidx.media3.exoplayer.audio.TeeAudioProcessor
import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.android.asCoroutineDispatcher
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.Buffer
import okio.BufferedSource
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.UnknownHostException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import javax.net.ssl.SSLException
import kotlin.math.abs

/**
 * Проверка канала в два уровня.
 *
 * Уровень 1 (сеть, основной): реально скачиваем то, что скачал бы плеер.
 *  - HLS: плейлист → (мастер → вариант с наименьшим битрейтом) → свежий сегмент, первые байты которого
 *    должны быть настоящим видео/аудио (MPEG-TS, fMP4, шифрованный блок), а не HTML/JSON/текстом ошибки.
 *  - Прямой поток (ts/mp4/radio): читаем первые килобайты и проверяем, что это медиаданные.
 *  Так канал подтверждается как рабочий без запуска ExoPlayer — быстро и параллельно.
 *  Однозначно мёртвым считается: 404/410/451, нет DNS, два таймаута подряд, пустой плейлист, HTML вместо потока.
 *
 * Уровень 2 (ExoPlayer, только для неоднозначных случаев: 401/403/429/5xx, TLS, странный ответ):
 * фоновый плеер без экрана и звука должен дойти до STATE_READY; один повтор при сетевой ошибке.
 * Если ExoPlayer сейчас запрещён [LoadGovernor], проверка откладывается, а не считается провалом.
 * Уровень 3 (содержимое, [checkContent]): канал реально воспроизводится в фоне без звука в динамиках
 * ~10 секунд; по декодированным кадрам и PCM-звуку определяется, что картинка движется и звук есть.
 * Заглушки платных каналов, «технический перерыв», канал с застывшим кадром или без звука не проходят.
 *
 * Планирование, очередь и параллельность — в [CheckScheduler].
 */
class StreamChecker(
    context: Context,
    private val client: OkHttpClient,
    private val governor: LoadGovernor,
) {
    private enum class Probe { ALIVE, DEAD, UNSURE }

    private enum class Outcome { READY, FAILED, TRANSIENT }

    private sealed interface Fetch {
        class Verdict(val probe: Probe) : Fetch
        class Playlist(val text: String, val base: HttpUrl) : Fetch
        class Data(val bytes: ByteArray) : Fetch
    }

    private val appContext = context.applicationContext

    private val probeThread: HandlerThread by lazy {
        HandlerThread("tvitto-probe", Process.THREAD_PRIORITY_BACKGROUND).apply { start() }
    }
    private val probeDispatcher by lazy {
        Handler(probeThread.looper).asCoroutineDispatcher("tvitto-probe")
    }

    /**
     * Индекс первого реально рабочего потока канала, -1 или [INCONCLUSIVE].
     * [preferred] — поток, ранее подтверждённый по содержимому: его проверяем первым, чтобы не «перескочить» на заглушку.
     */
    suspend fun check(channel: Channel, preferred: Int = -1): Int {
        val limit = minOf(channel.streams.size, Config.MAX_STREAMS_PER_CHANNEL)
        val order = ArrayList<Int>(limit)
        if (preferred in 0 until limit) order += preferred
        for (i in 0 until limit) if (i != preferred) order += i
        var inconclusive = false
        for (i in order) {
            val stream = channel.streams[i]
            when (verifyNetwork(stream)) {
                Probe.ALIVE -> return i
                Probe.DEAD -> continue
                Probe.UNSURE -> when (probeStream(stream)) {
                    true -> return i
                    false -> continue
                    // ExoPlayer сейчас нельзя запускать — неоднозначный ответ не доказывает неработоспособность.
                    null -> inconclusive = true
                }
            }
        }
        return if (inconclusive) INCONCLUSIVE else -1
    }

    // ---------- уровень 1: сеть ----------

    private suspend fun verifyNetwork(stream: StreamSource): Probe {
        val result = try {
            runInterruptible(Dispatchers.IO) { verifyBlocking(stream) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Probe.UNSURE
        }
        currentCoroutineContext().ensureActive()
        return result
    }

    private fun verifyBlocking(stream: StreamSource): Probe {
        var url: HttpUrl = stream.url.toHttpUrlOrNull() ?: return Probe.DEAD
        // Мастер-плейлист → медиаплейлист → сегмент: глубже трёх уровней не ходим.
        repeat(3) {
            when (val f = fetchRetry(url, stream, playlistAware = true)) {
                is Fetch.Verdict -> return f.probe
                is Fetch.Data -> return judgeData(f.bytes)
                is Fetch.Playlist -> {
                    val lines = f.text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
                    if (lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) {
                        val variants = variants(lines, f.base)
                        if (variants.isEmpty()) return Probe.UNSURE
                        // Наименьший битрейт — быстрее всего; при 404 пробуем следующий.
                        var last = Probe.UNSURE
                        for (v in variants.take(2)) {
                            val r = verifyMedia(v, stream)
                            if (r == Probe.ALIVE) return Probe.ALIVE
                            last = r
                        }
                        return last
                    }
                    return verifyMediaLines(lines, f.base, stream)
                }
            }
        }
        return Probe.UNSURE
    }

    private fun verifyMedia(url: HttpUrl, stream: StreamSource): Probe =
        when (val f = fetchRetry(url, stream, playlistAware = true)) {
            is Fetch.Verdict -> f.probe
            is Fetch.Data -> judgeData(f.bytes)
            is Fetch.Playlist -> {
                val lines = f.text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
                if (lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) Probe.UNSURE
                else verifyMediaLines(lines, f.base, stream)
            }
        }

    private fun verifyMediaLines(lines: List<String>, base: HttpUrl, stream: StreamSource): Probe {
        val segments = lines.filter { !it.startsWith("#") }
        if (segments.isEmpty()) return Probe.DEAD // пустой плейлист: эфира нет
        // Берём не самый последний сегмент: он может быть ещё не дописан.
        val ref = segments[(segments.size - 2).coerceAtLeast(0)]
        val seg = base.resolve(ref) ?: return Probe.UNSURE
        return when (val f = fetchRetry(seg, stream, playlistAware = false)) {
            is Fetch.Verdict -> f.probe
            is Fetch.Data -> judgeData(f.bytes)
            is Fetch.Playlist -> Probe.DEAD // вместо сегмента пришёл плейлист/текст
        }
    }

    private fun variants(lines: List<String>, base: HttpUrl): List<HttpUrl> {
        val out = ArrayList<Pair<Long, HttpUrl>>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                val bw = BANDWIDTH.find(l)?.groupValues?.get(1)?.toLongOrNull() ?: Long.MAX_VALUE
                var j = i + 1
                while (j < lines.size && lines[j].startsWith("#")) j++
                if (j < lines.size) base.resolve(lines[j])?.let { out += bw to it }
                i = j
            }
            i++
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    /** Один повтор при сетевой ошибке: единичный сбой не должен убивать канал. */
    private fun fetchRetry(url: HttpUrl, stream: StreamSource, playlistAware: Boolean): Fetch {
        var failure: IOException? = null
        for (attempt in 0..1) {
            try {
                return fetch(url, stream, playlistAware)
            } catch (e: IOException) {
                failure = e
                if (attempt == 0) {
                    try {
                        Thread.sleep(700)
                    } catch (ie: InterruptedException) {
                        throw InterruptedIOException("interrupted")
                    }
                }
            }
        }
        return Fetch.Verdict(classifyError(failure!!))
    }

    private fun fetch(url: HttpUrl, stream: StreamSource, playlistAware: Boolean): Fetch {
        val b = Request.Builder()
            .url(url)
            .header("User-Agent", stream.userAgent ?: Config.DEFAULT_UA)
            .header("Accept", "*/*")
        stream.referrer?.let { ref ->
            b.header("Referer", ref)
            ref.toHttpUrlOrNull()?.let { b.header("Origin", "${it.scheme}://${it.host}") }
        }
        if (!playlistAware) b.header("Range", "bytes=0-${DATA_BYTES - 1}")
        client.newCall(b.get().build()).execute().use { r ->
            val code = r.code
            if (code !in 200..299) {
                return Fetch.Verdict(if (code == 404 || code == 410 || code == 451) Probe.DEAD else Probe.UNSURE)
            }
            val ct = r.header("Content-Type")?.lowercase()
            if (ct != null && (ct.contains("text/html") || ct.contains("application/json"))) {
                return Fetch.Verdict(Probe.DEAD)
            }
            val src = r.body?.source() ?: return Fetch.Verdict(Probe.UNSURE)
            val buf = Buffer()
            readUpTo(src, buf, DATA_BYTES)
            if (playlistAware && startsWithPlaylist(buf)) {
                readUpTo(src, buf, PLAYLIST_BYTES)
                return Fetch.Playlist(buf.readUtf8(), r.request.url)
            }
            return Fetch.Data(buf.readByteArray())
        }
    }

    /** Читает до [limit] байт; частичный результат при обрыве/таймауте сохраняется. */
    private fun readUpTo(src: BufferedSource, buf: Buffer, limit: Int) {
        try {
            while (buf.size < limit) {
                val n = src.read(buf, limit - buf.size)
                if (n < 0) break
            }
        } catch (e: IOException) {
            if (buf.size == 0L) throw e
        }
    }

    private fun startsWithPlaylist(buf: Buffer): Boolean {
        val n = minOf(buf.size, 16L).toInt()
        if (n == 0) return false
        val head = buf.snapshot(n).utf8().trimStart('\uFEFF', ' ', '\n', '\r')
        return head.startsWith("#EXTM3U", ignoreCase = true)
    }

    /** Похоже ли начало ответа на настоящие медиаданные. */
    private fun judgeData(b: ByteArray): Probe {
        if (b.isEmpty()) return Probe.UNSURE
        if (looksLikeText(b)) return Probe.DEAD // HTML, JSON, текст ошибки
        if (b.size >= 1024) return Probe.ALIVE
        if (b.size >= 188 && b[0] == 0x47.toByte()) return Probe.ALIVE
        return Probe.UNSURE
    }

    private fun looksLikeText(b: ByteArray): Boolean {
        val n = minOf(b.size, 256)
        if (n < 8) return false
        var printable = 0
        for (i in 0 until n) {
            val c = b[i].toInt() and 0xFF
            if (c == 0) return false
            if (c == 9 || c == 10 || c == 13 || c in 32..126) printable++
        }
        return printable * 100 >= n * 97
    }

    private fun classifyError(e: IOException): Probe = when (e) {
        is UnknownHostException -> Probe.DEAD
        // TLS-ошибка может зависеть от стека — решает ExoPlayer.
        is SSLException -> Probe.UNSURE
        // Два таймаута/отказа подряд: сервер не отвечает, ExoPlayer не справится лучше.
        is InterruptedIOException, is ConnectException -> Probe.DEAD
        else -> Probe.UNSURE
    }

    // ---------- уровень 2: ExoPlayer ----------

    /** true/false — результат ExoPlayer, null — проверку нужно отложить до разрешения ExoPlayer. */
    private suspend fun probeStream(stream: StreamSource): Boolean? {
        repeat(2) { attempt ->
            while (true) {
                if (!governor.exoAllowed()) return null
                if (governor.tryAcquireExo()) break
                delay(200)
            }
            val outcome = try {
                if (!governor.exoAllowed()) return null
                runProbe(stream)
            } finally {
                governor.releaseExo()
            }
            when (outcome) {
                Outcome.READY -> return true
                Outcome.FAILED -> return false
                Outcome.TRANSIENT -> if (attempt == 1) return false else delay(1_000)
            }
        }
        return false
    }

    /**
     * Headless ExoPlayer на отдельном потоке: без поверхности и звука (volume 0, playWhenReady=false).
     * READY означает, что плеер реально прочитал и разобрал первые данные потока. Всегда освобождается.
     */
    private suspend fun runProbe(stream: StreamSource): Outcome =
        withContext(probeDispatcher) {
            val player = ExoPlayer.Builder(appContext)
                .setLooper(probeThread.looper)
                .setLoadControl(
                    DefaultLoadControl.Builder()
                        .setBufferDurationsMs(1500, 4000, 800, 800)
                        .build(),
                )
                .build()
            val result = CompletableDeferred<Outcome>()
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) result.complete(Outcome.READY)
                }

                override fun onPlayerError(error: PlaybackException) {
                    val transient = error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                    result.complete(if (transient) Outcome.TRANSIENT else Outcome.FAILED)
                }
            }
            try {
                player.addListener(listener)
                player.volume = 0f
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setForceLowestBitrate(true)
                    .build()
                player.setMediaSource(buildMediaSource(appContext, stream))
                player.playWhenReady = false
                player.prepare()
                // Тишина до таймаута — скорее медленная сеть, чем доказательство: один повтор.
                withTimeoutOrNull(Config.STREAM_PROBE_TIMEOUT_MS) { result.await() } ?: Outcome.TRANSIENT
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Outcome.FAILED
            } finally {
                player.removeListener(listener)
                player.release()
            }
        }

    // ---------- уровень 3: содержимое (картинка и звук) ----------

    @Volatile
    private var videoAnalysis = !com.tvitto.app.CrashLog.videoSafeMode

    @Volatile
    private var unanalyzableStreak = 0

    /**
     * Проверяет, что канал показывает живую картинку и играет звук. Сначала поток [startIdx]; при [allStreams]
     * (повторная проверка) — и остальные потоки канала: заглушкой может быть только один из них.
     * Возвращает рабочий поток или причину отказа.
     */
    suspend fun checkContent(channel: Channel, startIdx: Int, allStreams: Boolean): ContentVerdict {
        val limit = minOf(channel.streams.size, Config.MAX_STREAMS_PER_CHANNEL)
        val order = ArrayList<Int>(limit)
        val first = if (startIdx in 0 until limit) startIdx else 0
        if (limit > 0) order += first
        if (allStreams) for (i in 0 until limit) if (i != first) order += i

        var firstBad: ContentKind? = null
        var inconclusive = false
        for (i in order) {
            val stream = channel.streams[i]
            // Запасные потоки сначала быстро проверяем по сети: мёртвые не стоит гонять через плеер.
            if (i != first && verifyNetwork(stream) == Probe.DEAD) continue
            when (val kind = probeContent(stream)) {
                ContentKind.OK -> return ContentVerdict(ContentKind.OK, i)
                ContentKind.INCONCLUSIVE -> {
                    inconclusive = true
                    if (!governor.exoAllowed()) break
                }
                else -> if (firstBad == null) firstBad = kind
            }
        }
        return when {
            inconclusive -> ContentVerdict(ContentKind.INCONCLUSIVE, first)
            firstBad != null -> ContentVerdict(firstBad, first)
            else -> ContentVerdict(ContentKind.FAILED, first)
        }
    }

    private suspend fun probeContent(stream: StreamSource): ContentKind {
        while (true) {
            if (!governor.exoAllowed()) return ContentKind.INCONCLUSIVE
            if (governor.tryAcquireContent()) break
            delay(300)
        }
        try {
            var kind = runContentProbe(stream, videoEnabled = videoAnalysis)
            if (kind == ContentKind.VIDEO_BROKEN) {
                // Устройство не смогло отдать кадры для анализа: судим по звуку.
                noteUnanalyzable()
                if (!governor.exoAllowed()) return ContentKind.INCONCLUSIVE
                kind = runContentProbe(stream, videoEnabled = false)
            }
            return kind
        } finally {
            governor.releaseContent()
        }
    }

    /** Если кадры не удаётся получить много раз подряд, считаем, что устройство не умеет, и анализируем только звук. */
    private fun noteUnanalyzable() {
        unanalyzableStreak++
        if (unanalyzableStreak >= 6) videoAnalysis = false
    }

    /**
     * Фоновый ExoPlayer без экрана: видео выводится в [ImageReader] (кадры анализируются), звук идёт через
     * [TeeAudioProcessor] (громкость плеера 0, в динамиках тишина, аудиофокус не берётся).
     * Окно анализа — [Config.CONTENT_WINDOW_MS] реального воспроизведения; хороший канал заканчивается раньше:
     * как только замечено движение и звук.
     */
    private suspend fun runContentProbe(stream: StreamSource, videoEnabled: Boolean): ContentKind =
        withContext(probeDispatcher) {
            val audio = AudioStats()
            val player = ExoPlayer.Builder(appContext, ProbeRenderersFactory(appContext, audio))
                .setLooper(probeThread.looper)
                .setLoadControl(
                    DefaultLoadControl.Builder()
                        .setBufferDurationsMs(2000, 4000, 700, 1200)
                        .build(),
                )
                .build()
            val ready = CompletableDeferred<Boolean>()
            var error: PlaybackException? = null
            var playedMs = 0L
            var playingSince = -1L
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) ready.complete(true)
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    val now = SystemClock.elapsedRealtime()
                    if (isPlaying) {
                        if (playingSince < 0L) playingSince = now
                    } else if (playingSince >= 0L) {
                        playedMs += now - playingSince
                        playingSince = -1L
                    }
                }

                override fun onPlayerError(e: PlaybackException) {
                    error = e
                    ready.complete(false)
                }
            }
            var reader: ImageReader? = null
            var sampler: FrameSampler? = null
            try {
                player.addListener(listener)
                player.volume = 0f
                val params = player.trackSelectionParameters.buildUpon()
                    .setForceLowestBitrate(true)
                    // Для анализа достаточно малого разрешения: меньше нагрузка на декодер и память.
                    .setMaxVideoSize(Config.CONTENT_MAX_VIDEO_W, Config.CONTENT_MAX_VIDEO_H)
                if (!videoEnabled) params.setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                player.trackSelectionParameters = params.build()
                player.setMediaSource(buildMediaSource(appContext, stream))
                player.playWhenReady = false
                player.prepare()

                val started = withTimeoutOrNull(Config.STREAM_PROBE_TIMEOUT_MS) { ready.await() }
                if (started == null) return@withContext ContentKind.FAILED
                if (!started) return@withContext classifyPlayerError(error, videoAttached = false)

                val hasVideo = videoEnabled && player.currentTracks.isTypeSupported(C.TRACK_TYPE_VIDEO)
                if (hasVideo) {
                    val size = awaitVideoSize(player)
                    try {
                        val r = ImageReader.newInstance(size.first, size.second, ImageFormat.YUV_420_888, 3)
                        reader = r
                        val smp = FrameSampler(
                            if (governor.weakDevice) Config.CONTENT_FRAME_INTERVAL_WEAK_MS else Config.CONTENT_FRAME_INTERVAL_MS,
                        )
                        sampler = smp
                        r.setOnImageAvailableListener(smp, Handler(probeThread.looper))
                        player.setVideoSurface(r.surface)
                    } catch (e: Exception) {
                        try {
                            reader?.close()
                        } catch (ignored: Exception) {
                        }
                        reader = null
                        sampler = null
                    }
                }
                player.playWhenReady = true

                val smp = sampler
                val start = SystemClock.elapsedRealtime()
                while (true) {
                    delay(250)
                    currentCoroutineContext().ensureActive()
                    val err = error
                    if (err != null) return@withContext classifyPlayerError(err, videoAttached = smp != null)
                    // Пользователь открыл плеер или сеть пропала: проверку бросаем без штрафа каналу.
                    if (!governor.exoAllowed()) return@withContext ContentKind.INCONCLUSIVE
                    val now = SystemClock.elapsedRealtime()
                    val played = playedMs + if (playingSince >= 0L) now - playingSince else 0L
                    if (audio.hasSound() && (smp == null || smp.moving)) return@withContext ContentKind.OK
                    if (played >= Config.CONTENT_WINDOW_MS || now - start >= Config.CONTENT_MAX_WALL_MS) break
                }

                val now = SystemClock.elapsedRealtime()
                val played = playedMs + if (playingSince >= 0L) now - playingSince else 0L
                // Почти не играло (медленная сеть): вердикт был бы случайным.
                if (played < Config.CONTENT_MIN_PLAYED_MS) return@withContext ContentKind.INCONCLUSIVE

                val silent = !audio.hasSound()
                var static = false
                if (smp != null) {
                    if (smp.frames >= Config.CONTENT_MIN_FRAMES) {
                        static = !smp.moving
                        unanalyzableStreak = 0
                    } else {
                        noteUnanalyzable() // кадры не пришли — по картинке не судим
                    }
                }
                when {
                    silent && static -> ContentKind.STATIC_SILENT
                    silent -> ContentKind.SILENT
                    static -> ContentKind.STATIC
                    else -> ContentKind.OK
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                ContentKind.FAILED
            } catch (e: Throwable) {
                // Error (например, нехватка памяти или отсутствующий метод): проверка провалена, приложение живёт.
                com.tvitto.app.CrashLog.record(e)
                ContentKind.FAILED
            } finally {
                player.removeListener(listener)
                player.release()
                try {
                    reader?.setOnImageAvailableListener(null, null)
                    reader?.close()
                } catch (e: Exception) {
                    // ignore
                }
            }
        }

    /** Размер видео для ImageReader: из формата дорожки, иначе запасной. */
    private suspend fun awaitVideoSize(player: ExoPlayer): Pair<Int, Int> {
        repeat(10) {
            val f = player.videoFormat
                ?: player.currentTracks.groups
                    .firstOrNull { it.type == C.TRACK_TYPE_VIDEO && it.isSelected }
                    ?.getTrackFormat(0)
            if (f != null && f.width > 0 && f.height > 0) return Pair(f.width, f.height)
            delay(100)
        }
        return Pair(640, 360)
    }

    private fun classifyPlayerError(e: PlaybackException?, videoAttached: Boolean): ContentKind = when (e?.errorCode) {
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
        PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
        -> ContentKind.INCONCLUSIVE

        PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
        PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FAILED,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
        PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
        -> if (videoAttached) ContentKind.VIDEO_BROKEN else ContentKind.FAILED

        else -> ContentKind.FAILED
    }

    /** Рендереры плеера-проверяльщика: PCM-звук проходит через [TeeAudioProcessor] (без passthrough). */
    private class ProbeRenderersFactory(
        context: Context,
        private val sink: TeeAudioProcessor.AudioBufferSink,
    ) : DefaultRenderersFactory(context) {
        override fun buildAudioSink(
            context: Context,
            enableFloatOutput: Boolean,
            enableAudioTrackPlaybackParams: Boolean,
        ): AudioSink =
            DefaultAudioSink.Builder(context)
                // Только PCM: AC3/E-AC3 по HDMI минуют аудиопроцессоры, и звук нельзя было бы измерить.
                .setAudioCapabilities(AudioCapabilities.DEFAULT_AUDIO_CAPABILITIES)
                .setEnableFloatOutput(false)
                .setEnableAudioTrackPlaybackParams(false)
                .setAudioProcessors(arrayOf<AudioProcessor>(TeeAudioProcessor(sink)))
                .build()
    }

    /** Измеряет, сколько кадров PCM-звука громче порога. Пишет поток воспроизведения, читает поток проверки. */
    private class AudioStats : TeeAudioProcessor.AudioBufferSink {
        @Volatile private var sampleRate = 0

        @Volatile private var channels = 0

        @Volatile private var encoding = C.ENCODING_INVALID

        @Volatile private var loudFrames = 0L

        @Volatile private var unknownEncoding = false

        override fun flush(sampleRateHz: Int, channelCount: Int, encoding: Int) {
            sampleRate = sampleRateHz
            channels = channelCount.coerceAtLeast(1)
            this.encoding = encoding
        }

        override fun handleBuffer(buffer: ByteBuffer) {
            val ch = channels
            if (ch <= 0) return
            val b = buffer.asReadOnlyBuffer().order(ByteOrder.LITTLE_ENDIAN)
            var loud = 0L
            when (encoding) {
                C.ENCODING_PCM_16BIT -> {
                    val threshold = (Config.SOUND_PEAK * 32768f).toInt()
                    while (b.remaining() >= 2 * ch) {
                        var m = 0
                        for (c in 0 until ch) {
                            val v = abs(b.getShort().toInt())
                            if (v > m) m = v
                        }
                        if (m >= threshold) loud++
                    }
                }
                C.ENCODING_PCM_FLOAT -> {
                    while (b.remaining() >= 4 * ch) {
                        var m = 0f
                        for (c in 0 until ch) {
                            val v = abs(b.getFloat())
                            if (v > m) m = v
                        }
                        if (m >= Config.SOUND_PEAK) loud++
                    }
                }
                // Незнакомая кодировка: измерить нечем — звук не оспариваем.
                else -> unknownEncoding = true
            }
            if (loud > 0L) loudFrames += loud
        }

        fun hasSound(): Boolean {
            if (unknownEncoding) return true
            val rate = sampleRate
            return rate > 0 && loudFrames * 1000L >= Config.SOUND_MIN_LOUD_MS * rate
        }
    }

    /** Берёт кадры из ImageReader, сводит яркость к сетке точек и сравнивает с предыдущим и первым кадром. */
    private class FrameSampler(private val intervalMs: Long) : ImageReader.OnImageAvailableListener {
        @Volatile var frames = 0

        @Volatile var moving = false

        private var first: ByteArray? = null
        private var prev: ByteArray? = null
        private var lastAt = 0L
        private val gx = Config.STATIC_GRID_X
        private val gy = Config.STATIC_GRID_Y

        override fun onImageAvailable(reader: ImageReader) {
            var img: Image? = null
            try {
                img = reader.acquireLatestImage()
                if (img == null) return
                val now = SystemClock.elapsedRealtime()
                if (now - lastAt < intervalMs) return
                lastAt = now
                val plane = img.planes[0]
                val buf = plane.buffer
                val rowStride = plane.rowStride
                val pixelStride = plane.pixelStride
                val w = img.width
                val h = img.height
                if (w <= 0 || h <= 0) return
                val limit = buf.limit()
                val grid = ByteArray(gx * gy)
                for (j in 0 until gy) {
                    val y = (((j + 0.5f) * h) / gy).toInt().coerceIn(0, h - 1)
                    for (i in 0 until gx) {
                        val x = (((i + 0.5f) * w) / gx).toInt().coerceIn(0, w - 1)
                        val p = y * rowStride + x * pixelStride
                        grid[j * gx + i] = if (p in 0 until limit) buf.get(p) else 0
                    }
                }
                val f = first
                val p0 = prev
                if (f == null || p0 == null) {
                    first = grid
                } else if (!moving) {
                    if (changed(grid, p0) >= Config.STATIC_CHANGED_FRACTION ||
                        changed(grid, f) >= Config.STATIC_CHANGED_FRACTION
                    ) {
                        moving = true
                    }
                }
                prev = grid
                frames++
            } catch (e: Exception) {
                // кадр пропущен
            } finally {
                try {
                    img?.close()
                } catch (e: Exception) {
                    // ignore
                }
            }
        }

        private fun changed(a: ByteArray, b: ByteArray): Float {
            var n = 0
            for (k in a.indices) {
                val d = (a[k].toInt() and 0xFF) - (b[k].toInt() and 0xFF)
                if (abs(d) > Config.STATIC_PIXEL_DELTA) n++
            }
            return n.toFloat() / a.size
        }
    }

    companion object {
        /** ExoPlayer сейчас недоступен: сетевой проверки недостаточно, состояние канала менять нельзя. */
        const val INCONCLUSIVE = -2

        private const val DATA_BYTES = 4096
        private const val PLAYLIST_BYTES = 512 * 1024
        private val BANDWIDTH = Regex("""BANDWIDTH=(\d+)""", RegexOption.IGNORE_CASE)
    }
}

/** Итог проверки содержимого канала. */
enum class ContentKind {
    /** Картинка движется, звук есть. */
    OK,

    /** Картинка не меняется всё окно анализа. */
    STATIC,

    /** Звука нет (или он тише порога). */
    SILENT,
    STATIC_SILENT,

    /** Поток не запустился или оборвался. */
    FAILED,

    /** Вердикта нет (плеер занят, плохая сеть): канал не штрафуется. */
    INCONCLUSIVE,

    /** Внутреннее: декодер не смог вывести кадры в ImageReader, анализ повторяется только по звуку. */
    VIDEO_BROKEN,
}

class ContentVerdict(val kind: ContentKind, val idx: Int)
