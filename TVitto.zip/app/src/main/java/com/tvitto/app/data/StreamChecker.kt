package com.tvitto.app.data

import android.content.Context
import android.os.Handler
import android.os.HandlerThread
import android.os.Process
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.android.asCoroutineDispatcher
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.Buffer
import okio.BufferedSource
import java.io.IOException
import java.io.InterruptedIOException
import java.net.ConnectException
import java.net.UnknownHostException
import javax.net.ssl.SSLException

/**
 * Проверка канала в два уровня.
 *
 * Уровень 1 (сеть, основной): реально скачиваем то, что скачал бы плеер.
 *  - HLS: плейлист → (мастер → вариант с наименьшим битрейтом) → свежий сегмент, первые байты которого
 *    должны быть настоящим видео/аудио (MPEG-TS, fMP4, шифрованный блок), а не HTML/JSON/текстом ошибки.
 *  - Прямой поток (ts/mp4/radio): читаем первые килобайты и проверяем, что это медиаданные.
 *  Так канал подтверждается как рабочий без запуска ExoPlayer — быстро и параллельно.
 *  Однозначно мёртвым считается: 404/410/451, нет DNS, два таймаута подряд, пустой плейлист, HTML вместо потока.
 *
 * Уровень 2 (ExoPlayer, только для неоднозначных случаев: 401/403/429/5xx, TLS, странный ответ):
 * фоновый плеер без экрана и звука должен дойти до STATE_READY; один повтор при сетевой ошибке.
 * Если ExoPlayer сейчас запрещён [LoadGovernor], проверка откладывается, а не считается провалом.
 * Планирование, очередь и параллельность — в [CheckScheduler].
 */
class StreamChecker(
    context: Context,
    private val client: OkHttpClient,
    private val governor: LoadGovernor,
) {
    private enum class Probe { ALIVE, DEAD, UNSURE }

    private enum class Outcome { READY, FAILED, TRANSIENT }

    private sealed interface Fetch {
        class Verdict(val probe: Probe) : Fetch
        class Playlist(val text: String, val base: HttpUrl) : Fetch
        class Data(val bytes: ByteArray) : Fetch
    }

    private val appContext = context.applicationContext

    private val probeThread: HandlerThread by lazy {
        HandlerThread("tvitto-probe", Process.THREAD_PRIORITY_BACKGROUND).apply { start() }
    }
    private val probeDispatcher by lazy {
        Handler(probeThread.looper).asCoroutineDispatcher("tvitto-probe")
    }

    /** Индекс (в исходном списке) первого реально рабочего потока в порядке стабильности, -1 или [INCONCLUSIVE]. */
    suspend fun check(channel: Channel): Int {
        // Порядок проверки — по накопленной статистике (самый стабильный поток первым),
        // а не по порядку в плейлисте. Без статистики сохраняется порядок плейлиста.
        val order = StreamRatingStore.rankedIndices(appContext, channel)
            .take(Config.MAX_STREAMS_PER_CHANNEL)
        var inconclusive = false
        for (i in order) {
            val stream = channel.streams[i]
            when (verifyNetwork(stream)) {
                Probe.ALIVE -> return i
                Probe.DEAD -> continue
                Probe.UNSURE -> when (probeStream(stream)) {
                    true -> return i
                    false -> continue
                    // ExoPlayer сейчас нельзя запускать — неоднозначный ответ не доказывает неработоспособность.
                    null -> inconclusive = true
                }
            }
        }
        return if (inconclusive) INCONCLUSIVE else -1
    }

    // ---------- уровень 1: сеть ----------

    private suspend fun verifyNetwork(stream: StreamSource): Probe {
        val result = try {
            runInterruptible(Dispatchers.IO) { verifyBlocking(stream) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Probe.UNSURE
        }
        currentCoroutineContext().ensureActive()
        return result
    }

    private fun verifyBlocking(stream: StreamSource): Probe {
        var url: HttpUrl = stream.url.toHttpUrlOrNull() ?: return Probe.DEAD
        // Мастер-плейлист → медиаплейлист → сегмент: глубже трёх уровней не ходим.
        repeat(3) {
            when (val f = fetchRetry(url, stream, playlistAware = true)) {
                is Fetch.Verdict -> return f.probe
                is Fetch.Data -> return judgeData(f.bytes)
                is Fetch.Playlist -> {
                    val lines = f.text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
                    if (lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) {
                        val variants = variants(lines, f.base)
                        if (variants.isEmpty()) return Probe.UNSURE
                        // Наименьший битрейт — быстрее всего; при 404 пробуем следующий.
                        var last = Probe.UNSURE
                        for (v in variants.take(2)) {
                            val r = verifyMedia(v, stream)
                            if (r == Probe.ALIVE) return Probe.ALIVE
                            last = r
                        }
                        return last
                    }
                    return verifyMediaLines(lines, f.base, stream)
                }
            }
        }
        return Probe.UNSURE
    }

    private fun verifyMedia(url: HttpUrl, stream: StreamSource): Probe =
        when (val f = fetchRetry(url, stream, playlistAware = true)) {
            is Fetch.Verdict -> f.probe
            is Fetch.Data -> judgeData(f.bytes)
            is Fetch.Playlist -> {
                val lines = f.text.lineSequence().map { it.trim() }.filter { it.isNotEmpty() }.toList()
                if (lines.any { it.startsWith("#EXT-X-STREAM-INF", ignoreCase = true) }) Probe.UNSURE
                else verifyMediaLines(lines, f.base, stream)
            }
        }

    private fun verifyMediaLines(lines: List<String>, base: HttpUrl, stream: StreamSource): Probe {
        val segments = lines.filter { !it.startsWith("#") }
        if (segments.isEmpty()) return Probe.DEAD // пустой плейлист: эфира нет
        // Берём не самый последний сегмент: он может быть ещё не дописан.
        val ref = segments[(segments.size - 2).coerceAtLeast(0)]
        val seg = base.resolve(ref) ?: return Probe.UNSURE
        return when (val f = fetchRetry(seg, stream, playlistAware = false)) {
            is Fetch.Verdict -> f.probe
            is Fetch.Data -> judgeData(f.bytes)
            is Fetch.Playlist -> Probe.DEAD // вместо сегмента пришёл плейлист/текст
        }
    }

    private fun variants(lines: List<String>, base: HttpUrl): List<HttpUrl> {
        val out = ArrayList<Pair<Long, HttpUrl>>()
        var i = 0
        while (i < lines.size) {
            val l = lines[i]
            if (l.startsWith("#EXT-X-STREAM-INF", ignoreCase = true)) {
                val bw = BANDWIDTH.find(l)?.groupValues?.get(1)?.toLongOrNull() ?: Long.MAX_VALUE
                var j = i + 1
                while (j < lines.size && lines[j].startsWith("#")) j++
                if (j < lines.size) base.resolve(lines[j])?.let { out += bw to it }
                i = j
            }
            i++
        }
        return out.sortedBy { it.first }.map { it.second }
    }

    /** Один повтор при сетевой ошибке: единичный сбой не должен убивать канал. */
    private fun fetchRetry(url: HttpUrl, stream: StreamSource, playlistAware: Boolean): Fetch {
        var failure: IOException? = null
        for (attempt in 0..1) {
            try {
                return fetch(url, stream, playlistAware)
            } catch (e: IOException) {
                failure = e
                if (attempt == 0) {
                    try {
                        Thread.sleep(700)
                    } catch (ie: InterruptedException) {
                        throw InterruptedIOException("interrupted")
                    }
                }
            }
        }
        return Fetch.Verdict(classifyError(failure!!))
    }

    private fun fetch(url: HttpUrl, stream: StreamSource, playlistAware: Boolean): Fetch {
        val b = Request.Builder()
            .url(url)
            .header("User-Agent", stream.userAgent ?: Config.DEFAULT_UA)
            .header("Accept", "*/*")
        stream.referrer?.let { ref ->
            b.header("Referer", ref)
            ref.toHttpUrlOrNull()?.let { b.header("Origin", "${it.scheme}://${it.host}") }
        }
        if (!playlistAware) b.header("Range", "bytes=0-${DATA_BYTES - 1}")
        client.newCall(b.get().build()).execute().use { r ->
            val code = r.code
            if (code !in 200..299) {
                return Fetch.Verdict(if (code == 404 || code == 410 || code == 451) Probe.DEAD else Probe.UNSURE)
            }
            val ct = r.header("Content-Type")?.lowercase()
            if (ct != null && (ct.contains("text/html") || ct.contains("application/json"))) {
                return Fetch.Verdict(Probe.DEAD)
            }
            val src = r.body?.source() ?: return Fetch.Verdict(Probe.UNSURE)
            val buf = Buffer()
            readUpTo(src, buf, DATA_BYTES)
            if (playlistAware && startsWithPlaylist(buf)) {
                readUpTo(src, buf, PLAYLIST_BYTES)
                return Fetch.Playlist(buf.readUtf8(), r.request.url)
            }
            return Fetch.Data(buf.readByteArray())
        }
    }

    /** Читает до [limit] байт; частичный результат при обрыве/таймауте сохраняется. */
    private fun readUpTo(src: BufferedSource, buf: Buffer, limit: Int) {
        try {
            while (buf.size < limit) {
                val n = src.read(buf, limit - buf.size)
                if (n < 0) break
            }
        } catch (e: IOException) {
            if (buf.size == 0L) throw e
        }
    }

    private fun startsWithPlaylist(buf: Buffer): Boolean {
        val n = minOf(buf.size, 16L).toInt()
        if (n == 0) return false
        val head = buf.snapshot(n).utf8().trimStart('\uFEFF', ' ', '\n', '\r')
        return head.startsWith("#EXTM3U", ignoreCase = true)
    }

    /** Похоже ли начало ответа на настоящие медиаданные. */
    private fun judgeData(b: ByteArray): Probe {
        if (b.isEmpty()) return Probe.UNSURE
        if (looksLikeText(b)) return Probe.DEAD // HTML, JSON, текст ошибки
        if (b.size >= 1024) return Probe.ALIVE
        if (b.size >= 188 && b[0] == 0x47.toByte()) return Probe.ALIVE
        return Probe.UNSURE
    }

    private fun looksLikeText(b: ByteArray): Boolean {
        val n = minOf(b.size, 256)
        if (n < 8) return false
        var printable = 0
        for (i in 0 until n) {
            val c = b[i].toInt() and 0xFF
            if (c == 0) return false
            if (c == 9 || c == 10 || c == 13 || c in 32..126) printable++
        }
        return printable * 100 >= n * 97
    }

    private fun classifyError(e: IOException): Probe = when (e) {
        is UnknownHostException -> Probe.DEAD
        // TLS-ошибка может зависеть от стека — решает ExoPlayer.
        is SSLException -> Probe.UNSURE
        // Два таймаута/отказа подряд: сервер не отвечает, ExoPlayer не справится лучше.
        is InterruptedIOException, is ConnectException -> Probe.DEAD
        else -> Probe.UNSURE
    }

    // ---------- уровень 2: ExoPlayer ----------

    /** true/false — результат ExoPlayer, null — проверку нужно отложить до разрешения ExoPlayer. */
    private suspend fun probeStream(stream: StreamSource): Boolean? {
        repeat(2) { attempt ->
            while (true) {
                if (!governor.exoAllowed()) return null
                if (governor.tryAcquireExo()) break
                delay(200)
            }
            val outcome = try {
                if (!governor.exoAllowed()) return null
                runProbe(stream)
            } finally {
                governor.releaseExo()
            }
            when (outcome) {
                Outcome.READY -> return true
                Outcome.FAILED -> return false
                Outcome.TRANSIENT -> if (attempt == 1) return false else delay(1_000)
            }
        }
        return false
    }

    /**
     * Headless ExoPlayer на отдельном потоке: без поверхности и звука (volume 0, playWhenReady=false).
     * READY означает, что плеер реально прочитал и разобрал первые данные потока. Всегда освобождается.
     */
    private suspend fun runProbe(stream: StreamSource): Outcome =
        withContext(probeDispatcher) {
            val player = ExoPlayer.Builder(appContext)
                .setLooper(probeThread.looper)
                .setLoadControl(
                    DefaultLoadControl.Builder()
                        .setBufferDurationsMs(1500, 4000, 800, 800)
                        .build(),
                )
                .build()
            val result = CompletableDeferred<Outcome>()
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) result.complete(Outcome.READY)
                }

                override fun onPlayerError(error: PlaybackException) {
                    val transient = error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED ||
                        error.errorCode == PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT
                    result.complete(if (transient) Outcome.TRANSIENT else Outcome.FAILED)
                }
            }
            try {
                player.addListener(listener)
                player.volume = 0f
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setForceLowestBitrate(true)
                    .build()
                player.setMediaSource(buildMediaSource(appContext, stream))
                player.playWhenReady = false
                player.prepare()
                // Тишина до таймаута — скорее медленная сеть, чем доказательство: один повтор.
                withTimeoutOrNull(Config.STREAM_PROBE_TIMEOUT_MS) { result.await() } ?: Outcome.TRANSIENT
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Outcome.FAILED
            } finally {
                player.removeListener(listener)
                player.release()
            }
        }

    companion object {
        /** ExoPlayer сейчас недоступен: сетевой проверки недостаточно, состояние канала менять нельзя. */
        const val INCONCLUSIVE = -2

        private const val DATA_BYTES = 4096
        private const val PLAYLIST_BYTES = 512 * 1024
        private val BANDWIDTH = Regex("""BANDWIDTH=(\d+)""", RegexOption.IGNORE_CASE)
    }
}
