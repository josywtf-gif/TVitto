package com.tvitto.app.data

import android.content.Context
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import java.io.IOException
import java.io.InterruptedIOException

/**
 * Двухуровневая проверка канала:
 * 1) сеть: HEAD (fallback GET Range 0-0), код 200–399, Content-Type похож на медиа;
 * 2) поток: фоновый ExoPlayer без UI и без звука должен дойти до STATE_READY за 9 с.
 */
class StreamChecker(
    context: Context,
    private val client: OkHttpClient,
) {
    private val appContext = context.applicationContext

    private val netGate = Semaphore(Config.CHECK_CONCURRENCY)
    private val streamGate = Semaphore(Config.STREAM_CHECK_CONCURRENCY)

    /** Индекс первого реально играющего потока канала или -1. */
    suspend fun firstWorking(channel: Channel): Int {
        val limit = minOf(channel.streams.size, Config.MAX_STREAMS_PER_CHANNEL)
        for (i in 0 until limit) {
            val stream = channel.streams[i]
            if (!netGate.withPermit { probeNetwork(stream) }) continue
            if (streamGate.withPermit { probeStream(stream) }) return i
        }
        return -1
    }

    // ---------- уровень 1: сеть ----------

    private suspend fun probeNetwork(stream: StreamSource): Boolean =
        try {
            runInterruptible(Dispatchers.IO) { probeNetworkBlocking(stream) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            false
        }

    private fun probeNetworkBlocking(stream: StreamSource): Boolean {
        val head: Boolean? = try {
            client.newCall(request(stream, head = true)).execute().use { r ->
                if (r.code in 200..399) r.looksLikeMedia() else null
            }
        } catch (e: InterruptedIOException) {
            return false // таймаут или отмена
        } catch (e: IOException) {
            null
        }
        if (head != null) return head

        return client.newCall(request(stream, head = false)).execute().use { r ->
            r.code in 200..399 && r.looksLikeMedia()
        }
    }

    private fun request(stream: StreamSource, head: Boolean): Request {
        val builder = Request.Builder()
            .url(stream.url)
            .header("User-Agent", stream.userAgent ?: Config.DEFAULT_UA)
            .header("Accept", "*/*")
        stream.referrer?.let { builder.header("Referer", it) }
        return if (head) {
            builder.head().build()
        } else {
            builder.header("Range", "bytes=0-0").get().build()
        }
    }

    /** Не HTML, не JSON, не картинка/скрипт. Отсутствие Content-Type допустимо. */
    private fun Response.looksLikeMedia(): Boolean {
        val ct = header("Content-Type")?.lowercase() ?: return true
        val bad = listOf("text/html", "application/json", "image/", "javascript", "text/css")
        return bad.none { ct.contains(it) }
    }

    // ---------- уровень 2: реальный поток ----------

    /**
     * Headless ExoPlayer: без поверхности и звука (volume 0, playWhenReady=false).
     * READY означает, что плеер реально прочитал и разобрал первые данные потока.
     * ExoPlayer живёт на главном потоке, после проверки всегда освобождается.
     */
    private suspend fun probeStream(stream: StreamSource): Boolean =
        withContext(Dispatchers.Main) {
            val player = ExoPlayer.Builder(appContext)
                .setLoadControl(
                    DefaultLoadControl.Builder()
                        .setBufferDurationsMs(1500, 4000, 800, 800)
                        .build(),
                )
                .build()
            val result = CompletableDeferred<Boolean>()
            val listener = object : Player.Listener {
                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_READY) result.complete(true)
                }

                override fun onPlayerError(error: PlaybackException) {
                    result.complete(false)
                }
            }
            try {
                player.addListener(listener)
                player.volume = 0f
                player.trackSelectionParameters = player.trackSelectionParameters
                    .buildUpon()
                    .setForceLowestBitrate(true)
                    .build()
                player.setMediaSource(buildMediaSource(appContext, stream))
                player.playWhenReady = false
                player.prepare()
                withTimeoutOrNull(Config.STREAM_PROBE_TIMEOUT_MS) { result.await() } == true
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                false
            } finally {
                player.removeListener(listener)
                player.release()
            }
        }
}
