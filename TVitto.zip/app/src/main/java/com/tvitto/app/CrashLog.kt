package com.tvitto.app

import android.content.Context
import java.io.File
import java.io.PrintWriter
import java.io.StringWriter

/**
 * Журнал падений. Фатальная ошибка записывается в файл и показывается окном при следующем запуске
 * (чтобы причину можно было прочитать без компьютера). Нефатальные ошибки фоновых задач пишутся в errors.txt
 * и приложение не роняют.
 *
 * Если падение связано с проверкой картинки/звука (ImageReader, MediaCodec, StreamChecker), в этой версии
 * приложения анализ картинки отключается и остаётся проверка по звуку ([videoSafeMode]).
 */
object CrashLog {
    private var crashFile: File? = null
    private var errorsFile: File? = null

    @Volatile
    var videoSafeMode = false
        private set

    fun init(context: Context) {
        val dir = context.applicationContext.filesDir
        val crash = File(dir, "crash.txt")
        val errors = File(dir, "errors.txt")
        crashFile = crash
        errorsFile = errors
        try {
            val marker = File(dir, "no_video_analysis")
            val version = BuildConfig.VERSION_CODE.toString()
            if (crash.exists() && Regex("ImageReader|FrameSampler|MediaCodec|StreamChecker|AudioStats")
                    .containsMatchIn(crash.readText())
            ) {
                marker.writeText(version)
            }
            videoSafeMode = marker.exists() && marker.readText().trim() == version
        } catch (e: Exception) {
            // best effort
        }
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                crash.writeText(format(thread, error))
            } catch (e: Exception) {
                // ignore
            }
            previous?.uncaughtException(thread, error)
        }
    }

    /** Нефатальная ошибка (например, в фоновой проверке): записываем и продолжаем. */
    fun record(error: Throwable) {
        try {
            val f = errorsFile ?: return
            val text = format(Thread.currentThread(), error)
            val old = if (f.exists()) f.readText() else ""
            f.writeText((text + "\n" + old).take(20_000))
        } catch (e: Exception) {
            // ignore
        }
    }

    /** Текст последнего падения, если оно было и ещё не показано. */
    fun pending(): String? = try {
        crashFile?.takeIf { it.exists() }?.readText()?.takeIf { it.isNotBlank() }
    } catch (e: Exception) {
        null
    }

    fun dismiss() {
        try {
            crashFile?.delete()
        } catch (e: Exception) {
            // ignore
        }
    }

    private fun format(thread: Thread, error: Throwable): String {
        val sw = StringWriter()
        error.printStackTrace(PrintWriter(sw))
        return "TVitto ${BuildConfig.VERSION_NAME}, поток ${thread.name}\n$sw"
    }
}
