package com.tvitto.app.data

import android.app.ActivityManager
import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.os.Build
import android.os.PowerManager
import com.tvitto.app.Config
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.concurrent.atomic.AtomicInteger

/**
 * Решает, сколько фоновых проверок можно выполнять сейчас: учитывает сеть, RAM, CPU/энергосбережение,
 * перегрев, воспроизведение и буферизацию активного потока.
 */
class LoadGovernor(context: Context) {

    private class MemSnap(val low: Boolean, val avail: Long, val at: Long)

    private val app = context.applicationContext
    private val cm = app.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val am = app.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
    private val pm = app.getSystemService(Context.POWER_SERVICE) as PowerManager
    private val cores = Runtime.getRuntime().availableProcessors()

    private val _online = MutableStateFlow(true)
    val online: StateFlow<Boolean> = _online.asStateFlow()

    /** Счётчик потерь сети: если он изменился за время проверки, неудачу засчитывать нельзя. */
    @Volatile
    var offlineEpoch: Int = 0
        private set

    /** Открыт плеер. */
    @Volatile
    var playing: Boolean = false

    /** Активный поток буферизуется. */
    @Volatile
    var buffering: Boolean = false

    private val exoActive = AtomicInteger(0)
    private val contentActive = AtomicInteger(0)

    @Volatile
    private var mem = MemSnap(low = false, avail = Long.MAX_VALUE, at = 0L)

    private val callback = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) = refresh()
        override fun onLost(network: Network) = refresh()
        override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) = refresh()
    }

    init {
        refresh()
        try {
            cm.registerNetworkCallback(
                NetworkRequest.Builder()
                    .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
                    .build(),
                callback,
            )
        } catch (e: Exception) {
            // без колбэка работаем по последнему известному состоянию
        }
    }

    fun close() {
        try {
            cm.unregisterNetworkCallback(callback)
        } catch (e: Exception) {
            // ignore
        }
    }

    fun isOnline(): Boolean = _online.value

    private fun refresh() {
        val on = computeOnline()
        if (_online.value && !on) offlineEpoch++
        _online.value = on
    }

    private fun computeOnline(): Boolean {
        return try {
            val net = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(net) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) &&
                caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED)
        } catch (e: Exception) {
            true
        }
    }

    private fun memory(): MemSnap {
        val now = System.currentTimeMillis()
        val cur = mem
        if (now - cur.at < 2_000L) return cur
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)
        val snap = MemSnap(info.lowMemory, info.availMem, now)
        mem = snap
        return snap
    }

    private fun thermalSevere(): Boolean =
        Build.VERSION.SDK_INT >= 29 && pm.currentThermalStatus >= PowerManager.THERMAL_STATUS_SEVERE

    /** Сколько сетевых проверок можно вести одновременно. 0 — пауза (нет сети). */
    fun parallelism(): Int {
        if (!_online.value) return 0
        if (buffering) return 1
        var p = cores.coerceIn(2, Config.MAX_NET_PARALLEL)
        if (am.isLowRamDevice) p = maxOf(1, p / 2)
        val m = memory()
        if (m.low) {
            p = 1
        } else if (m.avail < 250L * 1024 * 1024) {
            p = minOf(p, 2)
        }
        if (pm.isPowerSaveMode) p = minOf(p, 2)
        if (thermalSevere()) p = 1
        try {
            val caps = cm.getNetworkCapabilities(cm.activeNetwork)
            if (caps != null && caps.linkDownstreamBandwidthKbps in 1..1500) p = minOf(p, 2)
            if (cm.isActiveNetworkMetered) p = minOf(p, 3)
        } catch (e: Exception) {
            // ignore
        }
        if (playing) p = minOf(p, 2)
        return p
    }

    /** Ориентир: проверок канала в минуту. 0 — пауза. */
    fun ratePerMin(initial: Boolean): Int {
        if (!_online.value || buffering) return 0
        var rate = when {
            playing -> Config.RATE_PLAYING
            initial -> Config.RATE_INITIAL
            else -> Config.RATE_NORMAL
        }
        if (am.isLowRamDevice || memory().low || thermalSevere()) rate = maxOf(1, rate / 2)
        return rate
    }

    /** Сколько фоновых ExoPlayer можно держать одновременно. */
    private fun exoParallelism(): Int {
        if (thermalSevere() || memory().low) return 0
        var p = (cores / 3).coerceIn(1, Config.MAX_EXO_PARALLEL)
        if (am.isLowRamDevice || pm.isPowerSaveMode) p = 1
        return p
    }

    /** Фоновый ExoPlayer допустим: нет воспроизведения/буферизации, есть сеть и ресурсы. */
    fun exoAllowed(): Boolean = _online.value && !playing && !buffering && exoParallelism() > 0

    fun tryAcquireExo(): Boolean {
        val limit = exoParallelism()
        if (exoActive.incrementAndGet() <= limit) return true
        exoActive.decrementAndGet()
        return false
    }

    fun releaseExo() {
        exoActive.decrementAndGet()
    }

    /** Сколько проверок содержимого (ExoPlayer + декодирование кадров и звука) можно вести одновременно. */
    fun contentParallelism(): Int {
        if (thermalSevere() || memory().low) return 0
        var p = (cores / 2).coerceIn(1, Config.MAX_CONTENT_PARALLEL)
        if (am.isLowRamDevice || pm.isPowerSaveMode) p = 1
        return p
    }

    fun tryAcquireContent(): Boolean {
        val limit = contentParallelism()
        if (contentActive.incrementAndGet() <= limit) return true
        contentActive.decrementAndGet()
        return false
    }

    fun releaseContent() {
        contentActive.decrementAndGet()
    }
}
