package com.tvitto.app.update

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import androidx.core.content.FileProvider
import com.tvitto.app.BuildConfig
import com.tvitto.app.data.Net
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.runInterruptible
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.concurrent.TimeUnit

data class ReleaseInfo(
    val tag: String,
    val version: String,
    val apkUrl: String,
    val size: Long,
)

sealed interface UpdateCheck {
    data object UpToDate : UpdateCheck
    data object Failed : UpdateCheck
    data class Available(val release: ReleaseInfo) : UpdateCheck
}

/** Обновление через последний релиз GitHub: проверка версии, загрузка APK, установка. */
object Updater {

    const val REPO = "josywtf-gif/TVitto"
    private const val LATEST_URL = "https://api.github.com/repos/$REPO/releases/latest"
    private const val APK_MIME = "application/vnd.android.package-archive"
    private const val UA = "TVitto-Android"
    private const val DELETE_DELAY_MS = 10_000L
    private const val ORPHAN_AGE_MS = 60L * 60L * 1000L

    private val downloadClient: OkHttpClient by lazy {
        Net.playlistClient.newBuilder()
            .readTimeout(60, TimeUnit.SECONDS)
            .callTimeout(0, TimeUnit.SECONDS)
            .build()
    }

    private class Latest(val tag: String, val apkUrl: String?, val size: Long)

    suspend fun check(): UpdateCheck {
        val latest: Latest? = try {
            runInterruptible(Dispatchers.IO) { fetchLatest() }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
        if (latest == null) return UpdateCheck.Failed

        if (!isNewer(latest.tag, BuildConfig.VERSION_NAME)) return UpdateCheck.UpToDate

        val url = latest.apkUrl ?: return UpdateCheck.Failed
        return UpdateCheck.Available(
            ReleaseInfo(
                tag = latest.tag,
                version = latest.tag.trim().trimStart('v', 'V'),
                apkUrl = url,
                size = latest.size,
            ),
        )
    }

    private fun fetchLatest(): Latest? {
        val request = Request.Builder()
            .url(LATEST_URL)
            .header("Accept", "application/vnd.github+json")
            .header("User-Agent", UA)
            .build()
        val body = Net.playlistClient.newCall(request).execute().use { r ->
            if (r.isSuccessful) r.body?.string() else null
        } ?: return null

        val json = JSONObject(body)
        val tag = json.optString("tag_name").trim()
        if (tag.isEmpty()) return null

        var apkUrl: String? = null
        var size = -1L
        val assets = json.optJSONArray("assets")
        if (assets != null) {
            for (i in 0 until assets.length()) {
                val asset = assets.getJSONObject(i)
                if (asset.optString("name").endsWith(".apk", ignoreCase = true)) {
                    apkUrl = asset.optString("browser_download_url").takeIf { it.isNotEmpty() }
                    size = asset.optLong("size", -1L)
                    if (apkUrl != null) break
                }
            }
        }
        return Latest(tag, apkUrl, size)
    }

    /** Сравнение версий вида v1.0.12 и 1.0.11 по числовым частям. */
    fun isNewer(remote: String, local: String): Boolean {
        val a = parts(remote)
        val b = parts(local)
        for (i in 0 until maxOf(a.size, b.size)) {
            val x = a.getOrElse(i) { 0 }
            val y = b.getOrElse(i) { 0 }
            if (x != y) return x > y
        }
        return false
    }

    private fun parts(version: String): List<Int> =
        version.trim().trimStart('v', 'V')
            .split('.', '-', '+')
            .map { part -> part.takeWhile { it.isDigit() }.toIntOrNull() ?: 0 }

    /** Скачивает APK в cacheDir/updates. [onProgress]: 0..1, либо -1, если размер неизвестен. */
    suspend fun download(
        context: Context,
        release: ReleaseInfo,
        onProgress: (Float) -> Unit,
    ): File = runInterruptible(Dispatchers.IO) {
        val dir = updatesDir(context).apply { mkdirs() }
        dir.listFiles()?.forEach { it.delete() }
        // Версия в имени файла нужна для очистки при старте (см. cleanup).
        val file = File(dir, "TVitto-${release.version}.apk")

        val request = Request.Builder()
            .url(release.apkUrl)
            .header("User-Agent", UA)
            .build()

        try {
            downloadClient.newCall(request).execute().use { r ->
                if (!r.isSuccessful) throw IOException("HTTP ${r.code}")
                val body = r.body ?: throw IOException("Пустой ответ")
                val total = body.contentLength().takeIf { it > 0 } ?: release.size
                onProgress(if (total > 0) 0f else -1f)

                body.byteStream().use { input ->
                    file.outputStream().use { out ->
                        val buffer = ByteArray(64 * 1024)
                        var read = 0L
                        var lastPercent = -1
                        while (true) {
                            val n = input.read(buffer)
                            if (n < 0) break
                            out.write(buffer, 0, n)
                            read += n
                            if (total > 0) {
                                val percent = (read * 100 / total).toInt().coerceIn(0, 100)
                                if (percent != lastPercent) {
                                    lastPercent = percent
                                    onProgress(percent / 100f)
                                }
                            }
                        }
                    }
                }
            }
        } catch (e: Throwable) {
            file.delete()
            throw e
        }
        file
    }

    fun canInstall(context: Context): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.O ||
            context.packageManager.canRequestPackageInstalls()

    /** Открывает системную настройку «Установка неизвестных приложений» для TVitto. */
    fun openInstallSettings(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val intent = Intent(
            Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
            Uri.parse("package:${context.packageName}"),
        ).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        runCatching { context.startActivity(intent) }
    }

    fun install(context: Context, file: File) {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW)
            .setDataAndType(uri, APK_MIME)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)

        // Установка уже запущена (startActivity не бросил исключение): система успела
        // забрать файл — удаляем APK через 10 с. Если процесс будет убит установкой,
        // файл подчистит cleanup() при следующем запуске.
        Handler(Looper.getMainLooper()).postDelayed(
            { runCatching { file.delete() } },
            DELETE_DELAY_MS,
        )
    }

    private fun updatesDir(context: Context): File = File(context.cacheDir, "updates")

    /**
     * Очистка «осиротевших» APK при старте приложения: удаляются файлы старше 1 часа
     * и файлы той версии, что уже установлена (или старее).
     */
    fun cleanup(context: Context) {
        val files = updatesDir(context).listFiles() ?: return
        val now = System.currentTimeMillis()
        for (f in files) {
            val tooOld = now - f.lastModified() > ORPHAN_AGE_MS
            val alreadyInstalled = !isNewer(
                f.name.removePrefix("TVitto-").removeSuffix(".apk"),
                BuildConfig.VERSION_NAME,
            )
            if (tooOld || alreadyInstalled || !f.name.endsWith(".apk", ignoreCase = true)) {
                runCatching { f.delete() }
            }
        }
    }
}
