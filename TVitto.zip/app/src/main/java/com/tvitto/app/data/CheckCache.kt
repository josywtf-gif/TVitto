package com.tvitto.app.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.tvitto.app.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.first

private val Context.checkStore by preferencesDataStore(name = "tvitto_checks")

/** Кэш результатов проверки каналов в DataStore (живёт [Config.CACHE_TTL_MS]). */
class CheckCache(context: Context) {

    private val store = context.applicationContext.checkStore
    private val resultsKey = stringPreferencesKey("results_v1")

    suspend fun load(): Map<String, CheckResult> {
        return try {
            val raw = store.data.first()[resultsKey].orEmpty()
            val out = HashMap<String, CheckResult>()
            for (line in raw.lineSequence()) {
                val p = line.split('\t')
                if (p.size != 3) continue
                val idx = p[1].toIntOrNull() ?: continue
                val ts = p[2].toLongOrNull() ?: continue
                out[p[0]] = CheckResult(idx, ts)
            }
            out
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            emptyMap()
        }
    }

    suspend fun save(results: Map<String, CheckResult>) {
        val now = System.currentTimeMillis()
        val text = results.entries
            .filter { now - it.value.ts <= Config.CACHE_TTL_MS }
            .joinToString("\n") { "${it.key}\t${it.value.idx}\t${it.value.ts}" }
        try {
            store.edit { it[resultsKey] = text }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // кэш — best effort
        }
    }

    suspend fun clear() {
        try {
            store.edit { it.remove(resultsKey) }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            // ignore
        }
    }
}
