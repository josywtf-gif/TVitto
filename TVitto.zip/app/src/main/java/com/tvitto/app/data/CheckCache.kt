package com.tvitto.app.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Дисковый кеш результатов проверки. Запись атомарная: данные пишутся во временный файл с fsync,
 * затем подменяют основной; предыдущая версия хранится как .bak до завершения подмены,
 * поэтому прерывание в любой момент не теряет кеш.
 *
 * [tag] — суффикс файлов: у каждого источника плейлиста свой кеш ("" — встроенный, "_custom" — свой).
 */
class CheckCache(context: Context, tag: String = "") {

    class Snapshot(val initialDone: Boolean, val results: Map<String, CheckResult>)

    private val dir = context.applicationContext.filesDir
    private val file = File(dir, "checks_v4$tag.json")
    private val tmp = File(dir, "checks_v4$tag.json.tmp")
    private val bak = File(dir, "checks_v4$tag.json.bak")
    private val lock = Any()

    suspend fun load(): Snapshot = withContext(Dispatchers.IO) {
        synchronized(lock) {
            // Результаты прежней, менее точной проверки не используем: всё проверяется заново.
            for (old in listOf("checks_v3.json", "checks_v3.json.tmp", "checks_v3.json.bak")) File(dir, old).delete()
            read(file) ?: read(bak) ?: read(tmp) ?: Snapshot(false, emptyMap())
        }
    }

    suspend fun save(snapshot: Snapshot) = withContext(Dispatchers.IO) {
        synchronized(lock) {
            try {
                val arr = JSONArray()
                for ((key, r) in snapshot.results) {
                    arr.put(
                        JSONObject().apply {
                            put("k", key)
                            put("s", r.state.name)
                            put("i", r.idx)
                            put("c", r.checkedAt)
                            put("n", r.nextCheckAt)
                            put("f", r.failStreak)
                            put("ff", r.firstFailAt)
                            put("g", r.sig)
                            put("w", r.wasAlive)
                            put("q", r.content.name)
                            put("qa", r.contentAt)
                            put("qn", r.contentNextAt)
                            put("qf", r.contentFails)
                            put("qr", r.contentReason)
                        },
                    )
                }
                val root = JSONObject()
                    .put("v", 4)
                    .put("initialDone", snapshot.initialDone)
                    .put("results", arr)
                val bytes = root.toString().toByteArray(Charsets.UTF_8)
                FileOutputStream(tmp).use { out ->
                    out.write(bytes)
                    out.flush()
                    out.fd.sync()
                }
                if (file.exists()) {
                    bak.delete()
                    file.renameTo(bak)
                }
                if (tmp.renameTo(file)) {
                    bak.delete()
                } else if (!file.exists() && bak.exists()) {
                    bak.renameTo(file)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                // кеш — best effort
            }
        }
    }

    suspend fun clear() = withContext(Dispatchers.IO) {
        synchronized(lock) {
            file.delete()
            tmp.delete()
            bak.delete()
        }
    }

    private fun read(f: File): Snapshot? {
        return try {
            if (!f.exists()) return null
            val root = JSONObject(f.readText(Charsets.UTF_8))
            val arr = root.getJSONArray("results")
            val out = HashMap<String, CheckResult>(arr.length())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val state = try {
                    CheckState.valueOf(o.getString("s"))
                } catch (e: Exception) {
                    continue
                }
                out[o.getString("k")] = CheckResult(
                    state = state,
                    idx = o.getInt("i"),
                    checkedAt = o.getLong("c"),
                    nextCheckAt = o.getLong("n"),
                    failStreak = o.getInt("f"),
                    firstFailAt = o.optLong("ff", 0L),
                    sig = o.optString("g", ""),
                    wasAlive = o.optBoolean("w", state == CheckState.ALIVE),
                    content = try {
                        ContentState.valueOf(o.optString("q", ContentState.UNVERIFIED.name))
                    } catch (e: Exception) {
                        ContentState.UNVERIFIED
                    },
                    contentAt = o.optLong("qa", 0L),
                    contentNextAt = o.optLong("qn", 0L),
                    contentFails = o.optInt("qf", 0),
                    contentReason = o.optString("qr", ""),
                )
            }
            Snapshot(root.optBoolean("initialDone", false), out)
        } catch (e: Exception) {
            null
        }
    }
}
