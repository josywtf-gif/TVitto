package com.tvitto.app

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.CompositionLocalProvider
import com.tvitto.app.ui.LocalIsTv
import com.tvitto.app.ui.TVittoRoot
import com.tvitto.app.ui.TVittoTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uiMode = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val isTv = uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

        setContent {
            TVittoTheme {
                CompositionLocalProvider(LocalIsTv provides isTv) {
                    TVittoRoot()
                }
            }
        }
    }
}
