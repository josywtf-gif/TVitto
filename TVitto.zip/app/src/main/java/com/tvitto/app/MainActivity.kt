package com.tvitto.app

import android.app.UiModeManager
import android.content.Context
import android.content.res.Configuration
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import com.tvitto.app.ui.LocalIsTv
import com.tvitto.app.ui.TVittoRoot
import com.tvitto.app.ui.TVittoTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val uiMode = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        val isTv = uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION

        setContent {
            TVittoTheme {
                CompositionLocalProvider(LocalIsTv provides isTv) {
                    TVittoRoot()
                    var crash by remember { mutableStateOf(CrashLog.pending()) }
                    crash?.let { text ->
                        AlertDialog(
                            onDismissRequest = {
                                CrashLog.dismiss()
                                crash = null
                            },
                            confirmButton = {
                                TextButton(
                                    onClick = {
                                        CrashLog.dismiss()
                                        crash = null
                                    },
                                ) { Text("Закрыть") }
                            },
                            title = { Text("Прошлый запуск завершился ошибкой") },
                            text = {
                                Text(
                                    text = text.take(2500),
                                    fontSize = 10.sp,
                                    fontFamily = FontFamily.Monospace,
                                    modifier = Modifier.verticalScroll(rememberScrollState()),
                                )
                            },
                        )
                    }
                }
            }
        }
    }
}
