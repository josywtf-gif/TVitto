package com.tvitto.app.data

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.MediaMetadata
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import com.tvitto.app.Config

/** Общая сборка MediaSource: для плеера и для фоновой проверки потока. */
fun buildMediaSource(context: Context, stream: StreamSource, title: String? = null): MediaSource {
    val http = DefaultHttpDataSource.Factory()
        .setUserAgent(stream.userAgent ?: Config.DEFAULT_UA)
        .setAllowCrossProtocolRedirects(true)
        .setConnectTimeoutMs(10_000)
        .setReadTimeoutMs(15_000)
    stream.referrer?.let { http.setDefaultRequestProperties(mapOf("Referer" to it)) }

    val item = MediaItem.Builder()
        .setUri(stream.url)
        .apply {
            if (stream.url.contains(".m3u8", ignoreCase = true)) {
                setMimeType(MimeTypes.APPLICATION_M3U8)
            }
            if (!title.isNullOrBlank()) {
                setMediaMetadata(MediaMetadata.Builder().setTitle(title).setArtist("TVitto").build())
            }
        }
        .build()

    return DefaultMediaSourceFactory(context)
        .setDataSourceFactory(http)
        .createMediaSource(item)
}
