package com.tvitto.app.data

/** Источник плейлиста: встроенный (Config.PLAYLISTS) или добавленный пользователем. */
enum class Source(
    /** Суффикс файлов кеша: у каждого источника свой кеш проверок/списка/недавних. */
    val cacheTag: String,
) {
    BUILTIN(""), // совпадает со старыми именами файлов — кеш прошлых версий сохраняется
    CUSTOM("_custom"),
}

/** Результат добавления своего плейлиста. */
sealed interface AddResult {
    data class Ok(val channels: Int) : AddResult
    data class Error(val message: String) : AddResult
}
