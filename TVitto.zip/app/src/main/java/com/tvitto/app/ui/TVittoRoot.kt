package com.tvitto.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import com.tvitto.app.playback.PlaybackEngine
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.runtime.DisposableEffect
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Screen { List, Settings, Source, AddPlaylist }

@Composable
fun TVittoRoot(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()

    var session by remember { mutableStateOf<PlaySession?>(null) }
    var returnKey by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf(Screen.List) }
    val hasCustom by vm.hasCustom.collectAsStateWithLifecycle()
    val listState = rememberLazyListState()

    // Источник сменился: список другой — возвращаемся к началу и забываем «последний канал».
    LaunchedEffect(state.source) {
        returnKey = null
        listState.scrollToItem(0)
    }

    // Уход в фон / закрытие: результаты проверок сразу на диск, чтобы проверка продолжилась с того же места.
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) vm.saveProgress()
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val current = session
    var playerWasOpen by remember { mutableStateOf(false) }

    // Сначала Compose удаляет PlayerView из иерархии, затем освобождаем ExoPlayer.
    LaunchedEffect(current) {
        if (current != null) {
            playerWasOpen = true
        } else if (playerWasOpen) {
            withFrameNanos { }
            delay(250)
            PlaybackEngine.stopAndRelease()
            playerWasOpen = false
        }
    }


    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        when {
            current != null -> PlayerScreen(
                session = current,
                onEvent = { vm.onPlaybackEvent(it) },
                onChannelOpened = { vm.addRecent(it) },
                isFavorite = { vm.isFavorite(it) },
                onToggleFavorite = { vm.toggleFavorite(it) },
            ) { lastKey ->
                returnKey = lastKey
                vm.onPlayerClosed()
                // Явно закрываем просмотр и возвращаемся к списку.
                // Освобождение ExoPlayer выполняется после удаления PlayerView из Compose.
                session = null
            }

            screen == Screen.Settings -> SettingsScreen(
                source = state.source,
                onBack = { screen = Screen.List },
                onRestartChecks = { vm.restartChecks() },
                onChooseSource = { screen = Screen.Source },
            )

            screen == Screen.Source -> SourceScreen(
                current = state.source,
                hasCustom = hasCustom,
                onBack = { screen = Screen.Settings },
                onBuiltin = {
                    vm.selectBuiltin()
                    screen = Screen.List
                },
                onAddCustom = { screen = Screen.AddPlaylist },
            )

            screen == Screen.AddPlaylist -> AddPlaylistScreen(
                hasCustom = hasCustom,
                onBack = { screen = Screen.Source },
                onSubmit = { vm.addCustomPlaylist(it) },
                onUseSaved = {
                    vm.useSavedCustom()
                    screen = Screen.List
                },
                onDone = { screen = Screen.List },
            )

            else -> ChannelListScreen(
                state = state,
                listState = listState,
                focusKey = returnKey,
                onOpen = { channel ->
                    vm.onPlayerOpened(channel.key)
                    session = PlaySession(state.channels, channel.key, state.selected)
                },
                onRetryChannel = { vm.retryChannel(it.key) },
                onRetry = { vm.retry() },
                onSelectCategory = { vm.selectCategory(it) },
                onOpenSettings = { screen = Screen.Settings },
            )
        }
    }
}
