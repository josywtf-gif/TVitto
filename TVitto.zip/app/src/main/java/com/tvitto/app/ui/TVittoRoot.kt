package com.tvitto.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import com.tvitto.app.MainActivity
import com.tvitto.app.playback.PlaybackEngine
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.withFrameNanos
import kotlinx.coroutines.delay
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

private enum class Screen { List, Settings, Source, AddPlaylist }

@Composable
fun TVittoRoot(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()
    val context = LocalContext.current

    var session by remember { mutableStateOf<PlaySession?>(null) }
    var returnKey by remember { mutableStateOf<String?>(null) }
    var screen by remember { mutableStateOf(Screen.List) }
    val hasCustom by vm.hasCustom.collectAsStateWithLifecycle()
    val gridState = rememberLazyGridState()

    // Источник сменился: список другой — возвращаемся к началу и забываем «последний канал».
    LaunchedEffect(state.source) {
        returnKey = null
        gridState.scrollToItem(0)
    }

    val current = session
    var playerWasOpen by remember { mutableStateOf(false) }

    // Сначала Compose удаляет PlayerScreen/PlayerView из иерархии, и только затем
    // останавливаем сервис и освобождаем общий ExoPlayer. Остановка прямо из onExit
    // могла освободить плеер, пока PlayerView ещё был прикреплён к окну, что приводило
    // к падению всего процесса вместо возврата к списку каналов.
    LaunchedEffect(current) {
        if (current != null) {
            playerWasOpen = true
        } else if (playerWasOpen) {
            withFrameNanos { }
            delay(250)
            PlaybackEngine.stopAndRelease(context)
            playerWasOpen = false
        }
    }

    DisposableEffect(current != null) {
        MainActivity.playerActive = current != null
        onDispose { MainActivity.playerActive = false }
    }

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        when {
            current != null -> PlayerScreen(
                session = current,
                onEvent = { vm.onPlaybackEvent(it) },
                onChannelOpened = { vm.addRecent(it) },
            ) { lastKey ->
                returnKey = lastKey
                vm.onPlayerClosed()
                // Явно закрываем просмотр и возвращаемся к списку.
                // Освобождение ExoPlayer выполняется после удаления PlayerView из Compose.
                session = null
            }

            screen == Screen.Settings -> SettingsScreen(
                source = state.source,
                onBack = { screen = Screen.List },
                onRestartChecks = { vm.restartChecks() },
                onChooseSource = { screen = Screen.Source },
            )

            screen == Screen.Source -> SourceScreen(
                current = state.source,
                hasCustom = hasCustom,
                onBack = { screen = Screen.Settings },
                onBuiltin = {
                    vm.selectBuiltin()
                    screen = Screen.List
                },
                onAddCustom = { screen = Screen.AddPlaylist },
            )

            screen == Screen.AddPlaylist -> AddPlaylistScreen(
                hasCustom = hasCustom,
                onBack = { screen = Screen.Source },
                onSubmit = { vm.addCustomPlaylist(it) },
                onUseSaved = {
                    vm.useSavedCustom()
                    screen = Screen.List
                },
                onDone = { screen = Screen.List },
            )

            else -> ChannelListScreen(
                state = state,
                gridState = gridState,
                focusKey = returnKey,
                onOpen = { channel ->
                    vm.onPlayerOpened(channel.key)
                    session = PlaySession(state.channels, channel.key, state.selected)
                },
                onRetryChannel = { vm.retryChannel(it.key) },
                onRetry = { vm.retry() },
                onSelectCategory = { vm.selectCategory(it) },
                onToggleFavorite = { vm.toggleFavorite(it) },
                isFavorite = { vm.isFavorite(it) },
                onOpenSettings = { screen = Screen.Settings },
            )
        }
    }
}
