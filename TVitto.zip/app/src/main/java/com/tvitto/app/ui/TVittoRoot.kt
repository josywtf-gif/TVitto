package com.tvitto.app.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel

@Composable
fun TVittoRoot(vm: MainViewModel = viewModel()) {
    val state by vm.state.collectAsStateWithLifecycle()

    var session by remember { mutableStateOf<PlaySession?>(null) }
    var returnKey by remember { mutableStateOf<String?>(null) }
    val gridState = rememberLazyGridState()

    val current = session

    Box(
        Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
    ) {
        if (current == null) {
            ChannelListScreen(
                state = state,
                gridState = gridState,
                focusKey = returnKey,
                onOpen = { channel ->
                    vm.pauseChecks()
                    session = PlaySession(state.channels, channel.key)
                },
                onRetry = { vm.retry() },
                onSelectCategory = { vm.selectCategory(it) },
            )
        } else {
            PlayerScreen(session = current) { watched, failed, lastKey ->
                returnKey = lastKey
                vm.resumeChecks(watched, failed)
                session = null
            }
        }
    }
}
