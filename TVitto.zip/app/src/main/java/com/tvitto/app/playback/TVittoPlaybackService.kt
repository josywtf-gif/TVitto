package com.tvitto.app.playback

import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Системная медиасессия и foreground-сервис для управления воспроизведением вне Activity. */
class TVittoPlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var servicePlayer: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        servicePlayer = PlaybackEngine.get(this)
        mediaSession = MediaSession.Builder(this, servicePlayer!!).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        // Сервис может быть уничтожен как после явного закрытия плеера, так и системой.
        // Освобождаем MediaSession и общий ExoPlayer ровно здесь, в одном месте.
        runCatching { servicePlayer?.pause() }
        runCatching { mediaSession?.release() }
        mediaSession = null
        servicePlayer?.let { PlaybackEngine.release(it) }
        servicePlayer = null
        super.onDestroy()
    }
}
