package com.tvitto.app.playback

import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService

/** Системная медиасессия и foreground-сервис для управления воспроизведением вне Activity. */
class TVittoPlaybackService : MediaSessionService() {
    private var mediaSession: MediaSession? = null
    private var servicePlayer: ExoPlayer? = null

    override fun onCreate() {
        super.onCreate()
        servicePlayer = PlaybackEngine.get(this)
        mediaSession = MediaSession.Builder(this, servicePlayer!!).build()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = mediaSession

    override fun onDestroy() {
        mediaSession?.run {
            player.pause()
            release()
        }
        mediaSession = null
        PlaybackEngine.release(servicePlayer)
        servicePlayer = null
        super.onDestroy()
    }
}
