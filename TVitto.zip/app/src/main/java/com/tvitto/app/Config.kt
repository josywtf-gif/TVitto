package com.tvitto.app

/** Все настройки зашиты в приложение — никаких полей ввода. */
object Config {

    /** Источники плейлистов. Для каждого: основной URL и зеркало (пробуются по порядку). */
    val PLAYLISTS: List<List<String>> = listOf(
        listOf(
            "https://iptv-org.github.io/iptv/languages/rus.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/languages/rus.m3u",
        ),
        listOf(
            "https://iptv-org.github.io/iptv/countries/ru.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/countries/ru.m3u",
        ),
    )

    /** Сколько каналов одновременно проходит сетевую проверку (HEAD/GET). */
    const val CHECK_CONCURRENCY = 32

    /** Сколько потоков одновременно проверяется фоновым ExoPlayer. */
    const val STREAM_CHECK_CONCURRENCY = 6

    /** Сколько ждать STATE_READY у фонового плеера, мс. */
    const val STREAM_PROBE_TIMEOUT_MS = 6_000L

    /** Сколько потоков одного канала пробуем максимум. */
    const val MAX_STREAMS_PER_CHANNEL = 2

    /** Таймаут сетевой проверки, секунды. */
    const val CHECK_TIMEOUT_SEC = 4L

    /**
     * Фоновая перепроверка кэша: раз в столько проверяется один канал
     * (самый давно проверенный). Работает, пока приложение запущено.
     */
    const val RECHECK_INTERVAL_MS = 5L * 60L * 1000L

    /** Сколько каналов хранится во вкладке «Недавние». */
    const val RECENT_LIMIT = 10

    const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
}
