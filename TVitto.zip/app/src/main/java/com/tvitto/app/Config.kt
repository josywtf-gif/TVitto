package com.tvitto.app

/** Все настройки зашиты в приложение — никаких полей ввода. */
object Config {

    /** Источники плейлистов. Для каждого: основной URL и зеркало (пробуются по порядку). */
    val PLAYLISTS: List<List<String>> = listOf(
        listOf(
            "https://iptv-org.github.io/iptv/languages/rus.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/languages/rus.m3u",
        ),
        listOf(
            "https://iptv-org.github.io/iptv/countries/ru.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/countries/ru.m3u",
        ),
    )

    /** Потолок параллельных сетевых проверок (реальный лимит адаптивный: LoadGovernor). */
    const val MAX_NET_PARALLEL = 10

    /** Потолок параллельных фоновых ExoPlayer (реальный лимит адаптивный). */
    const val MAX_EXO_PARALLEL = 3

    /** Сколько ждать STATE_READY у фонового плеера, мс. */
    const val STREAM_PROBE_TIMEOUT_MS = 15_000L

    /** Сколько потоков одного канала пробуем максимум. */
    const val MAX_STREAMS_PER_CHANNEL = 3

    /** Таймаут сетевой проверки, секунды. */
    const val CHECK_TIMEOUT_SEC = 6L

    /** Ориентир нагрузки, проверок канала в минуту: обычный режим. */
    const val RATE_NORMAL = 20

    /** Во время воспроизведения. */
    const val RATE_PLAYING = 8

    /** Первоначальная проверка (пока виден баннер прогресса): ускоренный режим. */
    const val RATE_INITIAL = 240

    // ---------- проверка содержимого: картинка и звук ----------

    /** Сколько секунд реального воспроизведения анализируем (картинка должна двигаться, звук — быть). */
    const val CONTENT_WINDOW_MS = 10_000L

    /** Потолок реального времени на анализ (с учётом буферизации). */
    const val CONTENT_MAX_WALL_MS = 22_000L

    /** Если проиграно меньше — вердикта нет (медленная сеть), канал не штрафуется. */
    const val CONTENT_MIN_PLAYED_MS = 6_000L

    /** Не чаще одного кадра на анализ за этот интервал, мс. */
    const val CONTENT_FRAME_INTERVAL_MS = 400L

    /** Минимум проанализированных кадров, чтобы утверждать «картинка статична». */
    const val CONTENT_MIN_FRAMES = 5

    /** Сетка опорных точек яркости по кадру. */
    const val STATIC_GRID_X = 48
    const val STATIC_GRID_Y = 27

    /** Точка «изменилась», если яркость сдвинулась больше чем на это (0..255). */
    const val STATIC_PIXEL_DELTA = 14

    /** Картинка «движется», если изменилась хотя бы такая доля точек (часы/мелкий логотип в счёт не идут). */
    const val STATIC_CHANGED_FRACTION = 0.008f

    /** Звук есть, если громче этого порога (доля от полной шкалы, ≈ −42 дБ) звучит минимум [SOUND_MIN_LOUD_MS]. */
    const val SOUND_PEAK = 0.008f
    const val SOUND_MIN_LOUD_MS = 250L

    /** Сколько фоновых проверок содержимого одновременно (реальный лимит адаптивный). */
    const val MAX_CONTENT_PARALLEL = 4

    /** Раньше этого времени повторную проверку после первого провала не начинаем. */
    const val CONTENT_RETRY_GAP_MS = 2L * 60_000L

    /** Перепроверка содержимого: у хороших каналов и у скрытых (BAD). */
    const val CONTENT_OK_INTERVAL_MS = 6L * 60L * 60_000L
    const val CONTENT_BAD_INTERVAL_MS = 2L * 60L * 60_000L

    /** Сколько раз подряд проверка может быть неубедительной, прежде чем засчитать провал. */
    const val CONTENT_MAX_INCONCLUSIVE = 3

    /** Интервалы перепроверки по состояниям. */
    const val ALIVE_INTERVAL_MS = 45L * 60_000L
    const val SUSPECT_INTERVAL_MS = 3L * 60_000L
    const val DEAD_INTERVAL_1_MS = 5L * 60_000L
    const val DEAD_INTERVAL_2_MS = 15L * 60_000L
    const val DEAD_INTERVAL_3_MS = 60L * 60_000L

    /** Для dead нужно минимум столько неудач подряд и столько времени между первой и последней. */
    const val DEAD_MIN_FAILS = 2
    const val DEAD_MIN_GAP_MS = 5L * 60_000L

    /** Как часто перечитывать плейлисты в фоне, пока приложение запущено. */
    const val PLAYLIST_REFRESH_MS = 60L * 60_000L

    /** Плеер: сколько ждать начала воспроизведения потока и сколько терпеть буферизацию. */
    const val PLAYBACK_START_TIMEOUT_MS = 15_000L
    const val PLAYBACK_STALL_TIMEOUT_MS = 20_000L

    /** Сколько каналов хранится во вкладке «Недавние». */
    const val RECENT_LIMIT = 10

    const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
}
