package com.tvitto.app

/** Все настройки зашиты в приложение — никаких полей ввода. */
object Config {

    /** Источники плейлистов. Для каждого: основной URL и зеркало (пробуются по порядку). */
    val PLAYLISTS: List<List<String>> = listOf(
        listOf(
            "https://iptv-org.github.io/iptv/languages/rus.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/languages/rus.m3u",
        ),
        listOf(
            "https://iptv-org.github.io/iptv/countries/ru.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/countries/ru.m3u",
        ),
    )

    /** Сколько каналов проверяется одновременно. */
    const val CHECK_CONCURRENCY = 12

    /** Таймаут одной проверки, секунды. */
    const val CHECK_TIMEOUT_SEC = 6L

    /** Сколько живёт результат проверки (память + DataStore). */
    const val CACHE_TTL_MS = 12L * 60L * 1000L

    const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
}
