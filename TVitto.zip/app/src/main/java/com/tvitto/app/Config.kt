package com.tvitto.app

/** Все настройки зашиты в приложение — никаких полей ввода. */
object Config {

    /** Источники плейлистов. Для каждого: основной URL и зеркало (пробуются по порядку). */
    val PLAYLISTS: List<List<String>> = listOf(
        listOf(
            "https://iptv-org.github.io/iptv/languages/rus.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/languages/rus.m3u",
        ),
        listOf(
            "https://iptv-org.github.io/iptv/countries/ru.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/countries/ru.m3u",
        ),
    )

    /** Сколько каналов одновременно проходит сетевую проверку (HEAD/GET). */
    const val CHECK_CONCURRENCY = 12

    /** Сколько потоков одновременно проверяется фоновым ExoPlayer. */
    const val STREAM_CHECK_CONCURRENCY = 4

    /** Сколько ждать STATE_READY у фонового плеера, мс. */
    const val STREAM_PROBE_TIMEOUT_MS = 9_000L

    /** Сколько потоков одного канала пробуем максимум. */
    const val MAX_STREAMS_PER_CHANNEL = 3

    /** Таймаут сетевой проверки, секунды. */
    const val CHECK_TIMEOUT_SEC = 6L

    /** Сколько живёт результат проверки (память + DataStore). */
    const val CACHE_TTL_MS = 12L * 60L * 1000L

    const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
}
