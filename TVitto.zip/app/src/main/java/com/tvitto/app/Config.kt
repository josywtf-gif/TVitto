package com.tvitto.app

/** Все настройки зашиты в приложение — никаких полей ввода. */
object Config {

    /** Источники плейлистов. Для каждого: основной URL и зеркало (пробуются по порядку). */
    val PLAYLISTS: List<List<String>> = listOf(
        listOf(
            "https://iptv-org.github.io/iptv/languages/rus.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/languages/rus.m3u",
        ),
        listOf(
            "https://iptv-org.github.io/iptv/countries/ru.m3u",
            "https://raw.githubusercontent.com/iptv-org/iptv/gh-pages/countries/ru.m3u",
        ),
    )

    /** Потолок параллельных сетевых проверок (реальный лимит адаптивный: LoadGovernor). */
    const val MAX_NET_PARALLEL = 6

    /** Потолок параллельных фоновых ExoPlayer (реальный лимит адаптивный). */
    const val MAX_EXO_PARALLEL = 3

    /** Сколько ждать STATE_READY у фонового плеера, мс. */
    const val STREAM_PROBE_TIMEOUT_MS = 9_000L

    /** Сколько потоков одного канала пробуем максимум. */
    const val MAX_STREAMS_PER_CHANNEL = 2

    /** Таймаут сетевой проверки, секунды. */
    const val CHECK_TIMEOUT_SEC = 5L

    /** Ориентир нагрузки, проверок канала в минуту: обычный режим. */
    const val RATE_NORMAL = 20

    /** Во время воспроизведения. */
    const val RATE_PLAYING = 8

    /** Первоначальная проверка (пока виден баннер прогресса): ускоренный режим. */
    const val RATE_INITIAL = 90

    /** Интервалы перепроверки по состояниям. */
    const val ALIVE_INTERVAL_MS = 45L * 60_000L
    const val SUSPECT_INTERVAL_MS = 10L * 60_000L
    const val DEAD_INTERVAL_1_MS = 5L * 60_000L
    const val DEAD_INTERVAL_2_MS = 15L * 60_000L
    const val DEAD_INTERVAL_3_MS = 60L * 60_000L

    /** Для dead нужно минимум столько неудач подряд и столько времени между первой и последней. */
    const val DEAD_MIN_FAILS = 2
    const val DEAD_MIN_GAP_MS = 10L * 60_000L

    /** Как часто перечитывать плейлисты в фоне, пока приложение запущено. */
    const val PLAYLIST_REFRESH_MS = 60L * 60_000L

    /** Плеер: сколько ждать начала воспроизведения потока и сколько терпеть буферизацию. */
    const val PLAYBACK_START_TIMEOUT_MS = 15_000L
    const val PLAYBACK_STALL_TIMEOUT_MS = 20_000L

    /** Сколько каналов хранится во вкладке «Недавние». */
    const val RECENT_LIMIT = 10

    const val DEFAULT_UA =
        "Mozilla/5.0 (Linux; Android 11) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
}
